<?php 

/** 
* Generated at: 2019-08-29T09:49:24+02:00
* IP: 125.160.112.3


Fields Summary: 
*/ 


return Pimcore\Model\DataObject\Fieldcollection\Definition::__set_state(array(
   'key' => 'EstimatedCost',
   'parentClass' => NULL,
   'title' => NULL,
   'group' => NULL,
   'layoutDefinitions' => NULL,
   'dao' => NULL,
));
