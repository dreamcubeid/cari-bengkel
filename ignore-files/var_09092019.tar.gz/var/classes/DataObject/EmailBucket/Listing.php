<?php 

namespace Pimcore\Model\DataObject\EmailBucket;

use Pimcore\Model\DataObject;

/**
 * @method DataObject\EmailBucket current()
 * @method DataObject\EmailBucket[] load()
 */

class Listing extends DataObject\Listing\Concrete {

protected $classId = "8";
protected $className = "EmailBucket";


}
