<?php 

/** 
* Generated at: 2019-08-29T17:11:47+02:00
* Inheritance: no
* Variants: no
* Changed by: admin (2)
* IP: 103.119.50.87


Fields Summary: 
- Name [input]
- Slug [input]
- Description [textarea]
- MetaTitle [input]
- MetaDescription [textarea]
- MetaKeyword [textarea]
*/ 

namespace Pimcore\Model\DataObject;

use Pimcore\Model\DataObject\Exception\InheritanceParentNotFoundException;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

/**
* @method static \Pimcore\Model\DataObject\Type\Listing getByName ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Type\Listing getBySlug ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Type\Listing getByDescription ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Type\Listing getByMetaTitle ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Type\Listing getByMetaDescription ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Type\Listing getByMetaKeyword ($value, $limit = 0) 
*/

class Type extends Concrete implements \Pimcore\Model\DataObject\DirtyIndicatorInterface {

use \Pimcore\Model\DataObject\Traits\DirtyIndicatorTrait;

protected $o_classId = "3";
protected $o_className = "Type";
protected $Name;
protected $Slug;
protected $Description;
protected $MetaTitle;
protected $MetaDescription;
protected $MetaKeyword;


/**
* @param array $values
* @return \Pimcore\Model\DataObject\Type
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

/**
* Get Name - Name
* @return string
*/
public function getName () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Name"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Name;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Name - Name
* @param string $Name
* @return \Pimcore\Model\DataObject\Type
*/
public function setName ($Name) {
	$fd = $this->getClass()->getFieldDefinition("Name");
	$this->Name = $Name;
	return $this;
}

/**
* Get Slug - Slug
* @return string
*/
public function getSlug () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Slug"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Slug;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Slug - Slug
* @param string $Slug
* @return \Pimcore\Model\DataObject\Type
*/
public function setSlug ($Slug) {
	$fd = $this->getClass()->getFieldDefinition("Slug");
	$this->Slug = $Slug;
	return $this;
}

/**
* Get Description - Description
* @return string
*/
public function getDescription () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Description"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Description;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Description - Description
* @param string $Description
* @return \Pimcore\Model\DataObject\Type
*/
public function setDescription ($Description) {
	$fd = $this->getClass()->getFieldDefinition("Description");
	$this->Description = $Description;
	return $this;
}

/**
* Get MetaTitle - Meta Title
* @return string
*/
public function getMetaTitle () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("MetaTitle"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->MetaTitle;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set MetaTitle - Meta Title
* @param string $MetaTitle
* @return \Pimcore\Model\DataObject\Type
*/
public function setMetaTitle ($MetaTitle) {
	$fd = $this->getClass()->getFieldDefinition("MetaTitle");
	$this->MetaTitle = $MetaTitle;
	return $this;
}

/**
* Get MetaDescription - Meta Description
* @return string
*/
public function getMetaDescription () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("MetaDescription"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->MetaDescription;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set MetaDescription - Meta Description
* @param string $MetaDescription
* @return \Pimcore\Model\DataObject\Type
*/
public function setMetaDescription ($MetaDescription) {
	$fd = $this->getClass()->getFieldDefinition("MetaDescription");
	$this->MetaDescription = $MetaDescription;
	return $this;
}

/**
* Get MetaKeyword - Meta Keyword
* @return string
*/
public function getMetaKeyword () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("MetaKeyword"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->MetaKeyword;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set MetaKeyword - Meta Keyword
* @param string $MetaKeyword
* @return \Pimcore\Model\DataObject\Type
*/
public function setMetaKeyword ($MetaKeyword) {
	$fd = $this->getClass()->getFieldDefinition("MetaKeyword");
	$this->MetaKeyword = $MetaKeyword;
	return $this;
}

}

