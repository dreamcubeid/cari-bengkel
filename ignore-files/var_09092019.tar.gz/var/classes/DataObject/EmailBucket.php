<?php 

/** 
* Generated at: 2019-09-09T08:17:22+02:00
* Inheritance: no
* Variants: no
* Changed by: admin (2)
* IP: 66.96.232.79


Fields Summary: 
- Activity [input]
- Subject [input]
- From [input]
- To [input]
- CC [input]
- BCC [input]
- Template [input]
- Params [textarea]
- BodyText [textarea]
- Status [select]
- Counter [numeric]
- Message [textarea]
- Delay [input]
- Attachment [manyToManyRelation]
*/ 

namespace Pimcore\Model\DataObject;

use Pimcore\Model\DataObject\Exception\InheritanceParentNotFoundException;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

/**
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByActivity ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getBySubject ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByFrom ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByTo ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByCC ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByBCC ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByTemplate ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByParams ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByBodyText ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByStatus ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByCounter ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByMessage ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByDelay ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\EmailBucket\Listing getByAttachment ($value, $limit = 0) 
*/

class EmailBucket extends Concrete implements \Pimcore\Model\DataObject\DirtyIndicatorInterface {

use \Pimcore\Model\DataObject\Traits\DirtyIndicatorTrait;

protected $o_classId = "8";
protected $o_className = "EmailBucket";
protected $Activity;
protected $Subject;
protected $From;
protected $To;
protected $CC;
protected $BCC;
protected $Template;
protected $Params;
protected $BodyText;
protected $Status;
protected $Counter;
protected $Message;
protected $Delay;
protected $Attachment;


/**
* @param array $values
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

/**
* Get Activity - Activity
* @return string
*/
public function getActivity () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Activity"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Activity;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Activity - Activity
* @param string $Activity
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setActivity ($Activity) {
	$fd = $this->getClass()->getFieldDefinition("Activity");
	$this->Activity = $Activity;
	return $this;
}

/**
* Get Subject - Subject
* @return string
*/
public function getSubject () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Subject"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Subject;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Subject - Subject
* @param string $Subject
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setSubject ($Subject) {
	$fd = $this->getClass()->getFieldDefinition("Subject");
	$this->Subject = $Subject;
	return $this;
}

/**
* Get From - From
* @return string
*/
public function getFrom () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("From"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->From;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set From - From
* @param string $From
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setFrom ($From) {
	$fd = $this->getClass()->getFieldDefinition("From");
	$this->From = $From;
	return $this;
}

/**
* Get To - To
* @return string
*/
public function getTo () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("To"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->To;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set To - To
* @param string $To
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setTo ($To) {
	$fd = $this->getClass()->getFieldDefinition("To");
	$this->To = $To;
	return $this;
}

/**
* Get CC - CC
* @return string
*/
public function getCC () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("CC"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->CC;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set CC - CC
* @param string $CC
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setCC ($CC) {
	$fd = $this->getClass()->getFieldDefinition("CC");
	$this->CC = $CC;
	return $this;
}

/**
* Get BCC - BCC
* @return string
*/
public function getBCC () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("BCC"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->BCC;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set BCC - BCC
* @param string $BCC
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setBCC ($BCC) {
	$fd = $this->getClass()->getFieldDefinition("BCC");
	$this->BCC = $BCC;
	return $this;
}

/**
* Get Template - Template
* @return string
*/
public function getTemplate () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Template"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Template;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Template - Template
* @param string $Template
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setTemplate ($Template) {
	$fd = $this->getClass()->getFieldDefinition("Template");
	$this->Template = $Template;
	return $this;
}

/**
* Get Params - Params
* @return string
*/
public function getParams () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Params"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Params;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Params - Params
* @param string $Params
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setParams ($Params) {
	$fd = $this->getClass()->getFieldDefinition("Params");
	$this->Params = $Params;
	return $this;
}

/**
* Get BodyText - BodyText
* @return string
*/
public function getBodyText () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("BodyText"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->BodyText;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set BodyText - BodyText
* @param string $BodyText
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setBodyText ($BodyText) {
	$fd = $this->getClass()->getFieldDefinition("BodyText");
	$this->BodyText = $BodyText;
	return $this;
}

/**
* Get Status - Status
* @return string
*/
public function getStatus () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Status"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Status;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Status - Status
* @param string $Status
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setStatus ($Status) {
	$fd = $this->getClass()->getFieldDefinition("Status");
	$this->Status = $Status;
	return $this;
}

/**
* Get Counter - Counter
* @return float
*/
public function getCounter () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Counter"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Counter;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Counter - Counter
* @param float $Counter
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setCounter ($Counter) {
	$fd = $this->getClass()->getFieldDefinition("Counter");
	$this->Counter = $fd->preSetData($this, $Counter);
	return $this;
}

/**
* Get Message - Message
* @return string
*/
public function getMessage () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Message"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Message;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Message - Message
* @param string $Message
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setMessage ($Message) {
	$fd = $this->getClass()->getFieldDefinition("Message");
	$this->Message = $Message;
	return $this;
}

/**
* Get Delay - Delay
* @return string
*/
public function getDelay () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Delay"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Delay;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Delay - Delay
* @param string $Delay
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setDelay ($Delay) {
	$fd = $this->getClass()->getFieldDefinition("Delay");
	$this->Delay = $Delay;
	return $this;
}

/**
* Get Attachment - Attachment
* @return \Pimcore\Model\Asset\Folder[] | \Pimcore\Model\Asset\Image[] | \Pimcore\Model\Asset\Text[] | \Pimcore\Model\Asset\Audio[] | \Pimcore\Model\Asset\Video[] | \Pimcore\Model\Asset\Document[] | \Pimcore\Model\Asset\Archive[] | \Pimcore\Model\Asset\Unknown[]
*/
public function getAttachment () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Attachment"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("Attachment")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Attachment - Attachment
* @param \Pimcore\Model\Asset\Folder[] | \Pimcore\Model\Asset\Image[] | \Pimcore\Model\Asset\Text[] | \Pimcore\Model\Asset\Audio[] | \Pimcore\Model\Asset\Video[] | \Pimcore\Model\Asset\Document[] | \Pimcore\Model\Asset\Archive[] | \Pimcore\Model\Asset\Unknown[] $Attachment
* @return \Pimcore\Model\DataObject\EmailBucket
*/
public function setAttachment ($Attachment) {
	$fd = $this->getClass()->getFieldDefinition("Attachment");
	$currentData = $this->getAttachment();
	$isEqual = $fd->isEqual($currentData, $Attachment);
	if (!$isEqual) {
		$this->markFieldDirty("Attachment", true);
	}
	$this->Attachment = $fd->preSetData($this, $Attachment);
	return $this;
}

}

