<?php 

namespace Pimcore\Model\DataObject\Type;

use Pimcore\Model\DataObject;

/**
 * @method DataObject\Type current()
 * @method DataObject\Type[] load()
 */

class Listing extends DataObject\Listing\Concrete {

protected $classId = "3";
protected $className = "Type";


}
