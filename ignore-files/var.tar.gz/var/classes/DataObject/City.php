<?php 

/** 
* Generated at: 2019-08-29T10:45:38+02:00
* Inheritance: no
* Variants: no
* Changed by: admin (2)
* IP: 125.160.112.3


Fields Summary: 
- Name [input]
- Province [manyToOneRelation]
- Status [input]
- Popular [checkbox]
*/ 

namespace Pimcore\Model\DataObject;

use Pimcore\Model\DataObject\Exception\InheritanceParentNotFoundException;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

/**
* @method static \Pimcore\Model\DataObject\City\Listing getByName ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\City\Listing getByProvince ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\City\Listing getByStatus ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\City\Listing getByPopular ($value, $limit = 0) 
*/

class City extends Concrete implements \Pimcore\Model\DataObject\DirtyIndicatorInterface {

use \Pimcore\Model\DataObject\Traits\DirtyIndicatorTrait;

protected $o_classId = "6";
protected $o_className = "City";
protected $Name;
protected $Province;
protected $Status;
protected $Popular;


/**
* @param array $values
* @return \Pimcore\Model\DataObject\City
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

/**
* Get Name - Name
* @return string
*/
public function getName () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Name"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Name;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Name - Name
* @param string $Name
* @return \Pimcore\Model\DataObject\City
*/
public function setName ($Name) {
	$fd = $this->getClass()->getFieldDefinition("Name");
	$this->Name = $Name;
	return $this;
}

/**
* Get Province - Province
* @return \Pimcore\Model\DataObject\Province
*/
public function getProvince () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Province"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("Province")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Province - Province
* @param \Pimcore\Model\DataObject\Province $Province
* @return \Pimcore\Model\DataObject\City
*/
public function setProvince ($Province) {
	$fd = $this->getClass()->getFieldDefinition("Province");
	$currentData = $this->getProvince();
	$isEqual = $fd->isEqual($currentData, $Province);
	if (!$isEqual) {
		$this->markFieldDirty("Province", true);
	}
	$this->Province = $fd->preSetData($this, $Province);
	return $this;
}

/**
* Get Status - Status
* @return string
*/
public function getStatus () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Status"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Status;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Status - Status
* @param string $Status
* @return \Pimcore\Model\DataObject\City
*/
public function setStatus ($Status) {
	$fd = $this->getClass()->getFieldDefinition("Status");
	$this->Status = $Status;
	return $this;
}

/**
* Get Popular - Popular
* @return boolean
*/
public function getPopular () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Popular"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Popular;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Popular - Popular
* @param boolean $Popular
* @return \Pimcore\Model\DataObject\City
*/
public function setPopular ($Popular) {
	$fd = $this->getClass()->getFieldDefinition("Popular");
	$this->Popular = $Popular;
	return $this;
}

}

