<?php 

/** 
* Generated at: 2019-08-29T10:18:09+02:00
* Inheritance: no
* Variants: no
* Changed by: admin (2)
* IP: 125.160.112.3


Fields Summary: 
- Name [input]
- Email [input]
- Phone [numeric]
- Message [textarea]
*/ 

namespace Pimcore\Model\DataObject;

use Pimcore\Model\DataObject\Exception\InheritanceParentNotFoundException;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

/**
* @method static \Pimcore\Model\DataObject\ContactUs\Listing getByName ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\ContactUs\Listing getByEmail ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\ContactUs\Listing getByPhone ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\ContactUs\Listing getByMessage ($value, $limit = 0) 
*/

class ContactUs extends Concrete implements \Pimcore\Model\DataObject\DirtyIndicatorInterface {

use \Pimcore\Model\DataObject\Traits\DirtyIndicatorTrait;

protected $o_classId = "7";
protected $o_className = "ContactUs";
protected $Name;
protected $Email;
protected $Phone;
protected $Message;


/**
* @param array $values
* @return \Pimcore\Model\DataObject\ContactUs
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

/**
* Get Name - Name
* @return string
*/
public function getName () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Name"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Name;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Name - Name
* @param string $Name
* @return \Pimcore\Model\DataObject\ContactUs
*/
public function setName ($Name) {
	$fd = $this->getClass()->getFieldDefinition("Name");
	$this->Name = $Name;
	return $this;
}

/**
* Get Email - Email
* @return string
*/
public function getEmail () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Email"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Email;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Email - Email
* @param string $Email
* @return \Pimcore\Model\DataObject\ContactUs
*/
public function setEmail ($Email) {
	$fd = $this->getClass()->getFieldDefinition("Email");
	$this->Email = $Email;
	return $this;
}

/**
* Get Phone - Phone
* @return float
*/
public function getPhone () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Phone"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Phone;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Phone - Phone
* @param float $Phone
* @return \Pimcore\Model\DataObject\ContactUs
*/
public function setPhone ($Phone) {
	$fd = $this->getClass()->getFieldDefinition("Phone");
	$this->Phone = $fd->preSetData($this, $Phone);
	return $this;
}

/**
* Get Message - Message
* @return string
*/
public function getMessage () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Message"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Message;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Message - Message
* @param string $Message
* @return \Pimcore\Model\DataObject\ContactUs
*/
public function setMessage ($Message) {
	$fd = $this->getClass()->getFieldDefinition("Message");
	$this->Message = $Message;
	return $this;
}

}

