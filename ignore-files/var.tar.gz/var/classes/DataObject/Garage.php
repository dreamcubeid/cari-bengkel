<?php 

/** 
* Generated at: 2019-08-30T06:05:40+02:00
* Inheritance: no
* Variants: no
* Changed by: admin (2)
* IP: 66.96.232.79


Fields Summary: 
- Name [input]
- GarageType [manyToManyObjectRelation]
- Category [manyToManyObjectRelation]
- OfficialShop [manyToOneRelation]
- Slug [input]
- Address [textarea]
- Province [manyToOneRelation]
- City [manyToOneRelation]
- PostCode [numeric]
- Logo [image]
- Banner [image]
- EstimatedCost [fieldcollections]
- Latitude [numeric]
- Longitude [numeric]
- Zoom [numeric]
- OperatingHours [fieldcollections]
- ContactPerson [input]
- Email [input]
- Phone [fieldcollections]
- Recommended [checkbox]
- View [numeric]
- Like [numeric]
- Unlike [numeric]
- MetaTitle [input]
- MetaDescription [textarea]
- MetaKeyword [textarea]
*/ 

namespace Pimcore\Model\DataObject;

use Pimcore\Model\DataObject\Exception\InheritanceParentNotFoundException;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

/**
* @method static \Pimcore\Model\DataObject\Garage\Listing getByName ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByGarageType ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByCategory ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByOfficialShop ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getBySlug ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByAddress ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByProvince ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByCity ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByPostCode ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByLogo ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByBanner ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByEstimatedCost ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByLatitude ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByLongitude ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByZoom ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByOperatingHours ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByContactPerson ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByEmail ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByPhone ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByRecommended ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByView ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByLike ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByUnlike ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByMetaTitle ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByMetaDescription ($value, $limit = 0) 
* @method static \Pimcore\Model\DataObject\Garage\Listing getByMetaKeyword ($value, $limit = 0) 
*/

class Garage extends Concrete implements \Pimcore\Model\DataObject\DirtyIndicatorInterface {

use \Pimcore\Model\DataObject\Traits\DirtyIndicatorTrait;

protected $o_classId = "1";
protected $o_className = "Garage";
protected $Name;
protected $GarageType;
protected $Category;
protected $OfficialShop;
protected $Slug;
protected $Address;
protected $Province;
protected $City;
protected $PostCode;
protected $Logo;
protected $Banner;
protected $EstimatedCost;
protected $Latitude;
protected $Longitude;
protected $Zoom;
protected $OperatingHours;
protected $ContactPerson;
protected $Email;
protected $Phone;
protected $Recommended;
protected $View;
protected $Like;
protected $Unlike;
protected $MetaTitle;
protected $MetaDescription;
protected $MetaKeyword;


/**
* @param array $values
* @return \Pimcore\Model\DataObject\Garage
*/
public static function create($values = array()) {
	$object = new static();
	$object->setValues($values);
	return $object;
}

/**
* Get Name - Name
* @return string
*/
public function getName () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Name"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Name;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Name - Name
* @param string $Name
* @return \Pimcore\Model\DataObject\Garage
*/
public function setName ($Name) {
	$fd = $this->getClass()->getFieldDefinition("Name");
	$this->Name = $Name;
	return $this;
}

/**
* Get GarageType - Garage Type
* @return \Pimcore\Model\DataObject\Type[]
*/
public function getGarageType () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("GarageType"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("GarageType")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set GarageType - Garage Type
* @param \Pimcore\Model\DataObject\Type[] $GarageType
* @return \Pimcore\Model\DataObject\Garage
*/
public function setGarageType ($GarageType) {
	$fd = $this->getClass()->getFieldDefinition("GarageType");
	$currentData = $this->getGarageType();
	$isEqual = $fd->isEqual($currentData, $GarageType);
	if (!$isEqual) {
		$this->markFieldDirty("GarageType", true);
	}
	$this->GarageType = $fd->preSetData($this, $GarageType);
	return $this;
}

/**
* Get Category - Category
* @return \Pimcore\Model\DataObject\Category[]
*/
public function getCategory () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Category"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("Category")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Category - Category
* @param \Pimcore\Model\DataObject\Category[] $Category
* @return \Pimcore\Model\DataObject\Garage
*/
public function setCategory ($Category) {
	$fd = $this->getClass()->getFieldDefinition("Category");
	$currentData = $this->getCategory();
	$isEqual = $fd->isEqual($currentData, $Category);
	if (!$isEqual) {
		$this->markFieldDirty("Category", true);
	}
	$this->Category = $fd->preSetData($this, $Category);
	return $this;
}

/**
* Get OfficialShop - Official Shop
* @return \Pimcore\Model\DataObject\OfficialShop
*/
public function getOfficialShop () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("OfficialShop"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("OfficialShop")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set OfficialShop - Official Shop
* @param \Pimcore\Model\DataObject\OfficialShop $OfficialShop
* @return \Pimcore\Model\DataObject\Garage
*/
public function setOfficialShop ($OfficialShop) {
	$fd = $this->getClass()->getFieldDefinition("OfficialShop");
	$currentData = $this->getOfficialShop();
	$isEqual = $fd->isEqual($currentData, $OfficialShop);
	if (!$isEqual) {
		$this->markFieldDirty("OfficialShop", true);
	}
	$this->OfficialShop = $fd->preSetData($this, $OfficialShop);
	return $this;
}

/**
* Get Slug - Slug
* @return string
*/
public function getSlug () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Slug"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Slug;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Slug - Slug
* @param string $Slug
* @return \Pimcore\Model\DataObject\Garage
*/
public function setSlug ($Slug) {
	$fd = $this->getClass()->getFieldDefinition("Slug");
	$this->Slug = $Slug;
	return $this;
}

/**
* Get Address - Address
* @return string
*/
public function getAddress () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Address"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Address;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Address - Address
* @param string $Address
* @return \Pimcore\Model\DataObject\Garage
*/
public function setAddress ($Address) {
	$fd = $this->getClass()->getFieldDefinition("Address");
	$this->Address = $Address;
	return $this;
}

/**
* Get Province - Province
* @return \Pimcore\Model\DataObject\Province
*/
public function getProvince () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Province"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("Province")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Province - Province
* @param \Pimcore\Model\DataObject\Province $Province
* @return \Pimcore\Model\DataObject\Garage
*/
public function setProvince ($Province) {
	$fd = $this->getClass()->getFieldDefinition("Province");
	$currentData = $this->getProvince();
	$isEqual = $fd->isEqual($currentData, $Province);
	if (!$isEqual) {
		$this->markFieldDirty("Province", true);
	}
	$this->Province = $fd->preSetData($this, $Province);
	return $this;
}

/**
* Get City - City
* @return \Pimcore\Model\DataObject\City
*/
public function getCity () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("City"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("City")->preGetData($this);

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set City - City
* @param \Pimcore\Model\DataObject\City $City
* @return \Pimcore\Model\DataObject\Garage
*/
public function setCity ($City) {
	$fd = $this->getClass()->getFieldDefinition("City");
	$currentData = $this->getCity();
	$isEqual = $fd->isEqual($currentData, $City);
	if (!$isEqual) {
		$this->markFieldDirty("City", true);
	}
	$this->City = $fd->preSetData($this, $City);
	return $this;
}

/**
* Get PostCode - Post Code
* @return float
*/
public function getPostCode () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("PostCode"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->PostCode;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set PostCode - Post Code
* @param float $PostCode
* @return \Pimcore\Model\DataObject\Garage
*/
public function setPostCode ($PostCode) {
	$fd = $this->getClass()->getFieldDefinition("PostCode");
	$this->PostCode = $fd->preSetData($this, $PostCode);
	return $this;
}

/**
* Get Logo - Logo
* @return \Pimcore\Model\Asset\Image
*/
public function getLogo () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Logo"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Logo;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Logo - Logo
* @param \Pimcore\Model\Asset\Image $Logo
* @return \Pimcore\Model\DataObject\Garage
*/
public function setLogo ($Logo) {
	$fd = $this->getClass()->getFieldDefinition("Logo");
	$this->Logo = $Logo;
	return $this;
}

/**
* Get Banner - Banner
* @return \Pimcore\Model\Asset\Image
*/
public function getBanner () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Banner"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Banner;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Banner - Banner
* @param \Pimcore\Model\Asset\Image $Banner
* @return \Pimcore\Model\DataObject\Garage
*/
public function setBanner ($Banner) {
	$fd = $this->getClass()->getFieldDefinition("Banner");
	$this->Banner = $Banner;
	return $this;
}

/**
* @return \Pimcore\Model\DataObject\Fieldcollection
*/
public function getEstimatedCost () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("EstimatedCost"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("EstimatedCost")->preGetData($this);
	 return $data;
}

/**
* Set EstimatedCost - Estimated Cost
* @param \Pimcore\Model\DataObject\Fieldcollection $EstimatedCost
* @return \Pimcore\Model\DataObject\Garage
*/
public function setEstimatedCost ($EstimatedCost) {
	$fd = $this->getClass()->getFieldDefinition("EstimatedCost");
	$this->EstimatedCost = $fd->preSetData($this, $EstimatedCost);
	return $this;
}

/**
* Get Latitude - Latitude
* @return float
*/
public function getLatitude () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Latitude"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Latitude;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Latitude - Latitude
* @param float $Latitude
* @return \Pimcore\Model\DataObject\Garage
*/
public function setLatitude ($Latitude) {
	$fd = $this->getClass()->getFieldDefinition("Latitude");
	$this->Latitude = $fd->preSetData($this, $Latitude);
	return $this;
}

/**
* Get Longitude - Longitude
* @return float
*/
public function getLongitude () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Longitude"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Longitude;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Longitude - Longitude
* @param float $Longitude
* @return \Pimcore\Model\DataObject\Garage
*/
public function setLongitude ($Longitude) {
	$fd = $this->getClass()->getFieldDefinition("Longitude");
	$this->Longitude = $fd->preSetData($this, $Longitude);
	return $this;
}

/**
* Get Zoom - Zoom
* @return int
*/
public function getZoom () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Zoom"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Zoom;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Zoom - Zoom
* @param int $Zoom
* @return \Pimcore\Model\DataObject\Garage
*/
public function setZoom ($Zoom) {
	$fd = $this->getClass()->getFieldDefinition("Zoom");
	$this->Zoom = $fd->preSetData($this, $Zoom);
	return $this;
}

/**
* @return \Pimcore\Model\DataObject\Fieldcollection
*/
public function getOperatingHours () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("OperatingHours"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("OperatingHours")->preGetData($this);
	 return $data;
}

/**
* Set OperatingHours - Operating Hours
* @param \Pimcore\Model\DataObject\Fieldcollection $OperatingHours
* @return \Pimcore\Model\DataObject\Garage
*/
public function setOperatingHours ($OperatingHours) {
	$fd = $this->getClass()->getFieldDefinition("OperatingHours");
	$this->OperatingHours = $fd->preSetData($this, $OperatingHours);
	return $this;
}

/**
* Get ContactPerson - Contact Person
* @return string
*/
public function getContactPerson () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("ContactPerson"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->ContactPerson;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set ContactPerson - Contact Person
* @param string $ContactPerson
* @return \Pimcore\Model\DataObject\Garage
*/
public function setContactPerson ($ContactPerson) {
	$fd = $this->getClass()->getFieldDefinition("ContactPerson");
	$this->ContactPerson = $ContactPerson;
	return $this;
}

/**
* Get Email - Email
* @return string
*/
public function getEmail () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Email"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Email;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Email - Email
* @param string $Email
* @return \Pimcore\Model\DataObject\Garage
*/
public function setEmail ($Email) {
	$fd = $this->getClass()->getFieldDefinition("Email");
	$this->Email = $Email;
	return $this;
}

/**
* @return \Pimcore\Model\DataObject\Fieldcollection
*/
public function getPhone () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Phone"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->getClass()->getFieldDefinition("Phone")->preGetData($this);
	 return $data;
}

/**
* Set Phone - Phone
* @param \Pimcore\Model\DataObject\Fieldcollection $Phone
* @return \Pimcore\Model\DataObject\Garage
*/
public function setPhone ($Phone) {
	$fd = $this->getClass()->getFieldDefinition("Phone");
	$this->Phone = $fd->preSetData($this, $Phone);
	return $this;
}

/**
* Get Recommended - Recommended
* @return boolean
*/
public function getRecommended () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Recommended"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Recommended;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Recommended - Recommended
* @param boolean $Recommended
* @return \Pimcore\Model\DataObject\Garage
*/
public function setRecommended ($Recommended) {
	$fd = $this->getClass()->getFieldDefinition("Recommended");
	$this->Recommended = $Recommended;
	return $this;
}

/**
* Get View - View
* @return float
*/
public function getView () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("View"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->View;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set View - View
* @param float $View
* @return \Pimcore\Model\DataObject\Garage
*/
public function setView ($View) {
	$fd = $this->getClass()->getFieldDefinition("View");
	$this->View = $fd->preSetData($this, $View);
	return $this;
}

/**
* Get Like - Like
* @return float
*/
public function getLike () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Like"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Like;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Like - Like
* @param float $Like
* @return \Pimcore\Model\DataObject\Garage
*/
public function setLike ($Like) {
	$fd = $this->getClass()->getFieldDefinition("Like");
	$this->Like = $fd->preSetData($this, $Like);
	return $this;
}

/**
* Get Unlike - Unlike
* @return float
*/
public function getUnlike () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("Unlike"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->Unlike;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set Unlike - Unlike
* @param float $Unlike
* @return \Pimcore\Model\DataObject\Garage
*/
public function setUnlike ($Unlike) {
	$fd = $this->getClass()->getFieldDefinition("Unlike");
	$this->Unlike = $fd->preSetData($this, $Unlike);
	return $this;
}

/**
* Get MetaTitle - Meta Title
* @return string
*/
public function getMetaTitle () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("MetaTitle"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->MetaTitle;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set MetaTitle - Meta Title
* @param string $MetaTitle
* @return \Pimcore\Model\DataObject\Garage
*/
public function setMetaTitle ($MetaTitle) {
	$fd = $this->getClass()->getFieldDefinition("MetaTitle");
	$this->MetaTitle = $MetaTitle;
	return $this;
}

/**
* Get MetaDescription - Meta Description
* @return string
*/
public function getMetaDescription () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("MetaDescription"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->MetaDescription;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set MetaDescription - Meta Description
* @param string $MetaDescription
* @return \Pimcore\Model\DataObject\Garage
*/
public function setMetaDescription ($MetaDescription) {
	$fd = $this->getClass()->getFieldDefinition("MetaDescription");
	$this->MetaDescription = $MetaDescription;
	return $this;
}

/**
* Get MetaKeyword - Meta Keyword
* @return string
*/
public function getMetaKeyword () {
	if($this instanceof PreGetValueHookInterface && !\Pimcore::inAdmin()) { 
		$preValue = $this->preGetValue("MetaKeyword"); 
		if($preValue !== null) { 
			return $preValue;
		}
	} 

	$data = $this->MetaKeyword;

	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}

	return $data;
}

/**
* Set MetaKeyword - Meta Keyword
* @param string $MetaKeyword
* @return \Pimcore\Model\DataObject\Garage
*/
public function setMetaKeyword ($MetaKeyword) {
	$fd = $this->getClass()->getFieldDefinition("MetaKeyword");
	$this->MetaKeyword = $MetaKeyword;
	return $this;
}

}

