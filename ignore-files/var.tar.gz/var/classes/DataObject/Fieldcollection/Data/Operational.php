<?php 

/** 
* Generated at: 2019-08-29T10:26:22+02:00
* IP: 125.160.112.3


Fields Summary: 
 - OperationalDay [input]
 - OpenHour [time]
 - CloseHour [time]
*/ 

namespace Pimcore\Model\DataObject\Fieldcollection\Data;

use Pimcore\Model\DataObject;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

class Operational extends DataObject\Fieldcollection\Data\AbstractData implements \Pimcore\Model\DataObject\DirtyIndicatorInterface {

use \Pimcore\Model\DataObject\Traits\DirtyIndicatorTrait;

protected $type = "Operational";
protected $OperationalDay;
protected $OpenHour;
protected $CloseHour;


/**
* Get OperationalDay - Operational Day
* @return string
*/
public function getOperationalDay () {
	$data = $this->OperationalDay;
	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}
	 return $data;
}

/**
* Set OperationalDay - Operational Day
* @param string $OperationalDay
* @return \Pimcore\Model\DataObject\Operational
*/
public function setOperationalDay ($OperationalDay) {
	$fd = $this->getDefinition()->getFieldDefinition("OperationalDay");
	$this->OperationalDay = $OperationalDay;
	return $this;
}

/**
* Get OpenHour - Open Hour
* @return string
*/
public function getOpenHour () {
	$data = $this->OpenHour;
	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}
	 return $data;
}

/**
* Set OpenHour - Open Hour
* @param string $OpenHour
* @return \Pimcore\Model\DataObject\Operational
*/
public function setOpenHour ($OpenHour) {
	$fd = $this->getDefinition()->getFieldDefinition("OpenHour");
	$this->OpenHour = $OpenHour;
	return $this;
}

/**
* Get CloseHour - Close Hour
* @return string
*/
public function getCloseHour () {
	$data = $this->CloseHour;
	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}
	 return $data;
}

/**
* Set CloseHour - Close Hour
* @param string $CloseHour
* @return \Pimcore\Model\DataObject\Operational
*/
public function setCloseHour ($CloseHour) {
	$fd = $this->getDefinition()->getFieldDefinition("CloseHour");
	$this->CloseHour = $CloseHour;
	return $this;
}

}

