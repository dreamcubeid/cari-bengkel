<?php 

/** 
* Generated at: 2019-08-29T10:25:17+02:00
* IP: 125.160.112.3


Fields Summary: 
 - Phone [input]
*/ 

namespace Pimcore\Model\DataObject\Fieldcollection\Data;

use Pimcore\Model\DataObject;
use Pimcore\Model\DataObject\PreGetValueHookInterface;

class Phone extends DataObject\Fieldcollection\Data\AbstractData implements \Pimcore\Model\DataObject\DirtyIndicatorInterface {

use \Pimcore\Model\DataObject\Traits\DirtyIndicatorTrait;

protected $type = "Phone";
protected $Phone;


/**
* Get Phone - Phone
* @return string
*/
public function getPhone () {
	$data = $this->Phone;
	if ($data instanceof \Pimcore\Model\DataObject\Data\EncryptedField) {
		    return $data->getPlain();
	}
	 return $data;
}

/**
* Set Phone - Phone
* @param string $Phone
* @return \Pimcore\Model\DataObject\Phone
*/
public function setPhone ($Phone) {
	$fd = $this->getDefinition()->getFieldDefinition("Phone");
	$this->Phone = $Phone;
	return $this;
}

}

