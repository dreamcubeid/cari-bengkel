<?php 

namespace Pimcore\Model\DataObject\Garage;

use Pimcore\Model\DataObject;

/**
 * @method DataObject\Garage current()
 * @method DataObject\Garage[] load()
 */

class Listing extends DataObject\Listing\Concrete {

protected $classId = "1";
protected $className = "Garage";


}
