<?php 

namespace Pimcore\Model\DataObject\OfficialShop;

use Pimcore\Model\DataObject;

/**
 * @method DataObject\OfficialShop current()
 * @method DataObject\OfficialShop[] load()
 */

class Listing extends DataObject\Listing\Concrete {

protected $classId = "2";
protected $className = "OfficialShop";


}
