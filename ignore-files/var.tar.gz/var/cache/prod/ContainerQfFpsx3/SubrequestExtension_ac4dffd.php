<?php

class SubrequestExtension_ac4dffd extends \Pimcore\Twig\Extension\SubrequestExtension implements \ProxyManager\Proxy\VirtualProxyInterface
{
    private $valueHolder2b092 = null;
    private $initializerc1fb4 = null;
    private static $publicPropertiesc44a5 = [
        
    ];
    public function getFunctions()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'getFunctions', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return $this->valueHolder2b092->getFunctions();
    }
    public function getTokenParsers()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'getTokenParsers', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return $this->valueHolder2b092->getTokenParsers();
    }
    public function getNodeVisitors()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'getNodeVisitors', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return $this->valueHolder2b092->getNodeVisitors();
    }
    public function getFilters()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'getFilters', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return $this->valueHolder2b092->getFilters();
    }
    public function getTests()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'getTests', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return $this->valueHolder2b092->getTests();
    }
    public function getOperators()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'getOperators', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return $this->valueHolder2b092->getOperators();
    }
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;
        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance = $reflection->newInstanceWithoutConstructor();
        unset($instance->incHelper, $instance->actionHelper);
        $instance->initializerc1fb4 = $initializer;
        return $instance;
    }
    public function __construct(\Pimcore\Templating\Helper\Inc $incHelper, \Pimcore\Templating\Helper\Action $actionHelper)
    {
        static $reflection;
        if (! $this->valueHolder2b092) {
            $reflection = $reflection ?? new \ReflectionClass('Pimcore\\Twig\\Extension\\SubrequestExtension');
            $this->valueHolder2b092 = $reflection->newInstanceWithoutConstructor();
        unset($this->incHelper, $this->actionHelper);
        }
        $this->valueHolder2b092->__construct($incHelper, $actionHelper);
    }
    public function & __get($name)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__get', ['name' => $name], $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        if (isset(self::$publicPropertiesc44a5[$name])) {
            return $this->valueHolder2b092->$name;
        }
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            $backtrace = debug_backtrace(false);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    get_parent_class($this),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __set($name, $value)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            return $targetObject->$name = $value;
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function & () use ($targetObject, $name, $value) {
            return $targetObject->$name = $value;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __isset($name)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__isset', array('name' => $name), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            return isset($targetObject->$name);
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();
        return $returnValue;
    }
    public function __unset($name)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__unset', array('name' => $name), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            unset($targetObject->$name);
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();
        return $returnValue;
    }
    public function __clone()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__clone', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $this->valueHolder2b092 = clone $this->valueHolder2b092;
    }
    public function __sleep()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__sleep', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return array('valueHolder2b092');
    }
    public function __wakeup()
    {
        unset($this->incHelper, $this->actionHelper);
    }
    public function setProxyInitializer(\Closure $initializer = null)
    {
        $this->initializerc1fb4 = $initializer;
    }
    public function getProxyInitializer()
    {
        return $this->initializerc1fb4;
    }
    public function initializeProxy() : bool
    {
        return $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'initializeProxy', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
    }
    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder2b092;
    }
    public function getWrappedValueHolderValue() : ?object
    {
        return $this->valueHolder2b092;
    }
}
