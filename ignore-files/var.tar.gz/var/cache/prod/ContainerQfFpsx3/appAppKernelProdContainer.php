<?php

namespace ContainerQfFpsx3;

use Symfony\Component\DependencyInjection\Argument\RewindableGenerator;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\DependencyInjection\Container;
use Symfony\Component\DependencyInjection\Exception\InvalidArgumentException;
use Symfony\Component\DependencyInjection\Exception\LogicException;
use Symfony\Component\DependencyInjection\Exception\RuntimeException;
use Symfony\Component\DependencyInjection\ParameterBag\FrozenParameterBag;

/*
 * This class has been auto-generated
 * by the Symfony Dependency Injection Component.
 *
 * @final since Symfony 3.3
 */
class appAppKernelProdContainer extends Container
{
    private $buildParameters;
    private $containerDir;
    private $parameters = [];
    private $targetDirs = [];
    private $getService;

    public function __construct(array $buildParameters = [], $containerDir = __DIR__)
    {
        $this->getService = \Closure::fromCallable([$this, 'getService']);
        $dir = $this->targetDirs[0] = \dirname($containerDir);
        for ($i = 1; $i <= 4; ++$i) {
            $this->targetDirs[$i] = $dir = \dirname($dir);
        }
        $this->buildParameters = $buildParameters;
        $this->containerDir = $containerDir;
        $this->parameters = $this->getDefaultParameters();

        $this->services = $this->privates = [];
        $this->syntheticIds = [
            'Pimcore\\Cache\\Runtime' => true,
            'Pimcore\\Extension\\Config' => true,
            'kernel' => true,
        ];
        $this->methodMap = [
            'Pimcore\\Bundle\\AdminBundle\\EventListener\\CsrfProtectionListener' => 'getCsrfProtectionListenerService',
            'Pimcore\\Bundle\\AdminBundle\\Security\\User\\TokenStorageUserResolver' => 'getTokenStorageUserResolverService',
            'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\CookiePolicyNoticeListener' => 'getCookiePolicyNoticeListenerService',
            'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FullPageCacheListener' => 'getFullPageCacheListenerService',
            'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleAnalyticsCodeListener' => 'getGoogleAnalyticsCodeListenerService',
            'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleTagManagerListener' => 'getGoogleTagManagerListenerService',
            'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\TagManagerListener' => 'getTagManagerListenerService',
            'Pimcore\\Document\\DocumentStack' => 'getDocumentStackService',
            'Pimcore\\Extension\\Bundle\\PimcoreBundleManager' => 'getPimcoreBundleManagerService',
            'Pimcore\\Http\\RequestHelper' => 'getRequestHelperService',
            'Pimcore\\Http\\Request\\Resolver\\DocumentResolver' => 'getDocumentResolverService',
            'Pimcore\\Http\\Request\\Resolver\\EditmodeResolver' => 'getEditmodeResolverService',
            'Pimcore\\Http\\Request\\Resolver\\OutputTimestampResolver' => 'getOutputTimestampResolverService',
            'Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver' => 'getPimcoreContextResolverService',
            'Pimcore\\Http\\Request\\Resolver\\ResponseHeaderResolver' => 'getResponseHeaderResolverService',
            'Pimcore\\Http\\Request\\Resolver\\SiteResolver' => 'getSiteResolverService',
            'Pimcore\\Http\\ResponseHelper' => 'getResponseHelperService',
            'Pimcore\\Model\\Document\\Service' => 'getServiceService',
            'Pimcore\\Targeting\\Document\\DocumentTargetingConfigurator' => 'getDocumentTargetingConfiguratorService',
            'Symfony\\Bridge\\Twig\\Extension\\WebLinkExtension' => 'getWebLinkExtensionService',
            'Symfony\\Contracts\\Translation\\TranslatorInterface' => 'getTranslatorInterfaceService',
            'cmf_routing.route_provider' => 'getCmfRouting_RouteProviderService',
            'doctrine' => 'getDoctrineService',
            'doctrine.dbal.default_connection' => 'getDoctrine_Dbal_DefaultConnectionService',
            'event_dispatcher' => 'getEventDispatcherService',
            'form.factory' => 'getForm_FactoryService',
            'http_kernel' => 'getHttpKernelService',
            'monolog.logger.admin' => 'getMonolog_Logger_AdminService',
            'monolog.logger.cache' => 'getMonolog_Logger_CacheService',
            'monolog.logger.init' => 'getMonolog_Logger_InitService',
            'monolog.logger.php' => 'getMonolog_Logger_PhpService',
            'monolog.logger.request' => 'getMonolog_Logger_RequestService',
            'monolog.logger.router' => 'getMonolog_Logger_RouterService',
            'monolog.logger.routing' => 'getMonolog_Logger_RoutingService',
            'monolog.logger.security' => 'getMonolog_Logger_SecurityService',
            'pimcore.cache.core.handler' => 'getPimcore_Cache_Core_HandlerService',
            'pimcore.cache.core.pool' => 'getPimcore_Cache_Core_PoolService',
            'pimcore.controller.config.config_normalizer' => 'getPimcore_Controller_Config_ConfigNormalizerService',
            'pimcore.document.tag.block_state_stack' => 'getPimcore_Document_Tag_BlockStateStackService',
            'pimcore.implementation_loader.document.tag' => 'getPimcore_ImplementationLoader_Document_TagService',
            'pimcore.routing.router.request_context' => 'getPimcore_Routing_Router_RequestContextService',
            'pimcore.service.context.pimcore_context_guesser' => 'getPimcore_Service_Context_PimcoreContextGuesserService',
            'pimcore.service.request_matcher_factory' => 'getPimcore_Service_RequestMatcherFactoryService',
            'pimcore.templating.action_renderer' => 'getPimcore_Templating_ActionRendererService',
            'pimcore.templating.include_renderer' => 'getPimcore_Templating_IncludeRendererService',
            'pimcore.templating.tag_renderer' => 'getPimcore_Templating_TagRendererService',
            'pimcore.templating.view_helper.action' => 'getPimcore_Templating_ViewHelper_ActionService',
            'pimcore.templating.view_helper.glossary' => 'getPimcore_Templating_ViewHelper_GlossaryService',
            'pimcore.templating.view_helper.head_meta' => 'getPimcore_Templating_ViewHelper_HeadMetaService',
            'pimcore.templating.view_helper.inc' => 'getPimcore_Templating_ViewHelper_IncService',
            'pimcore.templating.view_helper.navigation' => 'getPimcore_Templating_ViewHelper_NavigationService',
            'pimcore.templating.view_helper.placeholder.container_service' => 'getPimcore_Templating_ViewHelper_Placeholder_ContainerServiceService',
            'pimcore.twig.extension.document_tag' => 'getPimcore_Twig_Extension_DocumentTagService',
            'pimcore.twig.extension.glossary' => 'getPimcore_Twig_Extension_GlossaryService',
            'pimcore.twig.extension.helpers' => 'getPimcore_Twig_Extension_HelpersService',
            'pimcore.twig.extension.navigation' => 'getPimcore_Twig_Extension_NavigationService',
            'pimcore.twig.extension.pimcore_object' => 'getPimcore_Twig_Extension_PimcoreObjectService',
            'pimcore.twig.extension.subrequest' => 'getPimcore_Twig_Extension_SubrequestService',
            'pimcore.twig.extension.templating_helper' => 'getPimcore_Twig_Extension_TemplatingHelperService',
            'pimcore_admin.security.bruteforce_protection_handler' => 'getPimcoreAdmin_Security_BruteforceProtectionHandlerService',
            'pimcore_admin.security.user_loader' => 'getPimcoreAdmin_Security_UserLoaderService',
            'request_stack' => 'getRequestStackService',
            'router' => 'getRouterService',
            'security.authorization_checker' => 'getSecurity_AuthorizationCheckerService',
            'security.token_storage' => 'getSecurity_TokenStorageService',
            'sensio_framework_extra.view.guesser' => 'getSensioFrameworkExtra_View_GuesserService',
            'twig' => 'getTwigService',
        ];
        $this->fileMap = [
            'AppBundle\\Controller\\Api\\GarageController' => 'getGarageControllerService.php',
            'AppBundle\\Controller\\DefaultController' => 'getDefaultControllerService.php',
            'AppBundle\\Repository\\GarageRepository' => 'getGarageRepositoryService.php',
            'AppBundle\\Service\\GarageService' => 'getGarageServiceService.php',
            'GuzzleHttp\\Client' => 'getClientService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\AssetController' => 'getAssetControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\ClassController' => 'getClassControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\ClassificationstoreController' => 'getClassificationstoreControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController' => 'getDataObjectControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectHelperController' => 'getDataObjectHelperControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\QuantityValueController' => 'getQuantityValueControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\VariantsController' => 'getVariantsControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\DocumentController' => 'getDocumentControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\EmailController' => 'getEmailControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\FolderController' => 'getFolderControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\HardlinkController' => 'getHardlinkControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\LinkController' => 'getLinkControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\NewsletterController' => 'getNewsletterControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PageController' => 'getPageControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintcontainerController' => 'getPrintcontainerControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintpageController' => 'getPrintpageControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintpageControllerBase' => 'getPrintpageControllerBaseService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\RenderletController' => 'getRenderletControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\SnippetController' => 'getSnippetControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\ElementController' => 'getElementControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\ElementControllerBase' => 'getElementControllerBaseService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\EmailController' => 'getEmailController2Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\AdminerController' => 'getAdminerControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\LinfoController' => 'getLinfoControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\OpcacheController' => 'getOpcacheControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\IndexController' => 'getIndexControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\InstallController' => 'getInstallControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\LogController' => 'getLogControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\LoginController' => 'getLoginControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\MiscController' => 'getMiscControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\NotificationController' => 'getNotificationControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\PortalController' => 'getPortalControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\RecyclebinController' => 'getRecyclebinControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\RedirectsController' => 'getRedirectsControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\SettingsController' => 'getSettingsControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TagsController' => 'getTagsControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TargetingController' => 'getTargetingControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TranslationController' => 'getTranslationControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\UserController' => 'getUserControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\WorkflowController' => 'getWorkflowControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\ExtensionManager\\ExtensionManagerController' => 'getExtensionManagerControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\AdminController' => 'getAdminControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\AssetController' => 'getAssetController2Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\DataObjectController' => 'getDataObjectController2Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\PimcoreUsersController' => 'getPimcoreUsersControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\SentMailController' => 'getSentMailControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\AnalyticsController' => 'getAnalyticsControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\CustomReportController' => 'getCustomReportControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\PiwikController' => 'getPiwikControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\QrcodeController' => 'getQrcodeControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\ReportsControllerBase' => 'getReportsControllerBaseService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\SettingsController' => 'getSettingsController2Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\ClassController' => 'getClassController2Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\AssetController' => 'getAssetController3Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\DataObjectController' => 'getDataObjectController3Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\DocumentController' => 'getDocumentController2Service.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\TagController' => 'getTagControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Helper' => 'getHelperService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\ImageController' => 'getImageControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\InfoController' => 'getInfoControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Controller\\Searchadmin\\SearchController' => 'getSearchControllerService.php',
            'Pimcore\\Bundle\\AdminBundle\\Session\\Handler\\AdminSessionHandler' => 'getAdminSessionHandlerService.php',
            'Pimcore\\Bundle\\CoreBundle\\Controller\\PublicServicesController' => 'getPublicServicesControllerService.php',
            'Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener' => 'getWorkflowManagementListenerService.php',
            'Pimcore\\Cache\\Symfony\\CacheClearer' => 'getCacheClearerService.php',
            'Pimcore\\Controller\\Config\\ControllerDataProvider' => 'getControllerDataProviderService.php',
            'Pimcore\\DataObject\\Consent\\Service' => 'getService2Service.php',
            'Pimcore\\DataObject\\GridColumnConfig\\Service' => 'getService3Service.php',
            'Pimcore\\Document\\Renderer\\DocumentRenderer' => 'getDocumentRendererService.php',
            'Pimcore\\Document\\Tag\\TagUsageResolver' => 'getTagUsageResolverService.php',
            'Pimcore\\FeatureToggles\\FeatureManagerInterface' => 'getFeatureManagerInterfaceService.php',
            'Pimcore\\Helper\\LongRunningHelper' => 'getLongRunningHelperService.php',
            'Pimcore\\Http\\ClientFactory' => 'getClientFactoryService.php',
            'Pimcore\\Http\\Request\\Resolver\\TemplateResolver' => 'getTemplateResolverService.php',
            'Pimcore\\Http\\Request\\Resolver\\TemplateVarsResolver' => 'getTemplateVarsResolverService.php',
            'Pimcore\\Http\\Request\\Resolver\\ViewModelResolver' => 'getViewModelResolverService.php',
            'Pimcore\\Image\\Optimizer' => 'getOptimizerService.php',
            'Pimcore\\Localization\\LocaleServiceInterface' => 'getLocaleServiceInterfaceService.php',
            'Pimcore\\Log\\Handler\\ApplicationLoggerDb' => 'getApplicationLoggerDbService.php',
            'Pimcore\\Migrations\\Configuration\\ConfigurationFactory' => 'getConfigurationFactoryService.php',
            'Pimcore\\Migrations\\MigrationManager' => 'getMigrationManagerService.php',
            'Pimcore\\Model\\DataObject\\ClassDefinition\\ClassDefinitionManager' => 'getClassDefinitionManagerService.php',
            'Pimcore\\Model\\DataObject\\QuantityValue\\QuantityValueConverterInterface' => 'getQuantityValueConverterInterfaceService.php',
            'Pimcore\\Model\\DataObject\\QuantityValue\\UnitConversionService' => 'getUnitConversionServiceService.php',
            'Pimcore\\Model\\Notification\\Service\\NotificationService' => 'getNotificationServiceService.php',
            'Pimcore\\Tool\\AssetsInstaller' => 'getAssetsInstallerService.php',
            'Pimcore\\Tool\\RestClient' => 'getRestClientService.php',
            'Pimcore\\Workflow\\Dumper\\GraphvizDumper' => 'getGraphvizDumperService.php',
            'Pimcore\\Workflow\\Dumper\\StateMachineGraphvizDumper' => 'getStateMachineGraphvizDumperService.php',
            'Pimcore\\Workflow\\ExpressionService' => 'getExpressionServiceService.php',
            'Pimcore\\Workflow\\Manager' => 'getManagerService.php',
            'Pimcore\\Workflow\\NotificationEmail\\NotificationEmailService' => 'getNotificationEmailServiceService.php',
            'Pimcore\\Workflow\\Place\\StatusInfo' => 'getStatusInfoService.php',
            'Scheb\\TwoFactorBundle\\Model\\PersisterInterface' => 'getPersisterInterfaceService.php',
            'Scheb\\TwoFactorBundle\\Security\\TwoFactor\\Provider\\TwoFactorFormRendererInterface' => 'getTwoFactorFormRendererInterfaceService.php',
            'Symfony\\Bundle\\FrameworkBundle\\Controller\\RedirectController' => 'getRedirectControllerService.php',
            'Symfony\\Bundle\\FrameworkBundle\\Controller\\TemplateController' => 'getTemplateControllerService.php',
            'cache.app' => 'getCache_AppService.php',
            'cache.app_clearer' => 'getCache_AppClearerService.php',
            'cache.global_clearer' => 'getCache_GlobalClearerService.php',
            'cache.system' => 'getCache_SystemService.php',
            'cache.system_clearer' => 'getCache_SystemClearerService.php',
            'cache_clearer' => 'getCacheClearer2Service.php',
            'cache_warmer' => 'getCacheWarmerService.php',
            'cmf_routing.redirect_controller' => 'getCmfRouting_RedirectControllerService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Bundle\\ListCommand' => 'getListCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\CacheClearCommand' => 'getCacheClearCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\CacheWarmingCommand' => 'getCacheWarmingCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\ClassCommand' => 'getClassCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\CustomLayoutCommand' => 'getCustomLayoutCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\FieldCollectionCommand' => 'getFieldCollectionCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\ObjectBrickCommand' => 'getObjectBrickCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\DeleteClassificationStoreCommand' => 'getDeleteClassificationStoreCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\DeleteUnusedLocaleDataCommand' => 'getDeleteUnusedLocaleDataCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Document\\GeneratePagePreviews' => 'getGeneratePagePreviewsService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Document\\MigrateTagNamingStrategyCommand' => 'getMigrateTagNamingStrategyCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\EmailLogsCleanupCommand' => 'getEmailLogsCleanupCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\InternalModelDaoMappingGeneratorCommand' => 'getInternalModelDaoMappingGeneratorCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\InternalUnicodeCldrLanguageTerritoryGeneratorCommand' => 'getInternalUnicodeCldrLanguageTerritoryGeneratorCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\InternalVideoConverterCommand' => 'getInternalVideoConverterCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\LowQualityImagePreviewCommand' => 'getLowQualityImagePreviewCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\MysqlToolsCommand' => 'getMysqlToolsCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ResetPasswordCommand' => 'getResetPasswordCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\RunScriptCommand' => 'getRunScriptCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\SearchBackendReindexCommand' => 'getSearchBackendReindexCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ThumbnailsClearCommand' => 'getThumbnailsClearCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ThumbnailsImageCommand' => 'getThumbnailsImageCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ThumbnailsVideoCommand' => 'getThumbnailsVideoCommandService.php',
            'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Web2PrintPdfCreationCommand' => 'getWeb2PrintPdfCreationCommandService.php',
            'console.command.public_alias.Pimcore\\Migrations\\Command\\ExecuteCommand' => 'getExecuteCommandService.php',
            'console.command.public_alias.Pimcore\\Migrations\\Command\\GenerateCommand' => 'getGenerateCommandService.php',
            'console.command.public_alias.Pimcore\\Migrations\\Command\\LatestCommand' => 'getLatestCommandService.php',
            'console.command.public_alias.Pimcore\\Migrations\\Command\\MarkAllDoneCommand' => 'getMarkAllDoneCommandService.php',
            'console.command.public_alias.Pimcore\\Migrations\\Command\\MigrateCommand' => 'getMigrateCommandService.php',
            'console.command.public_alias.Pimcore\\Migrations\\Command\\StatusCommand' => 'getStatusCommandService.php',
            'console.command.public_alias.Pimcore\\Migrations\\Command\\VersionCommand' => 'getVersionCommandService.php',
            'console.command.public_alias.doctrine_cache.contains_command' => 'getConsole_Command_PublicAlias_DoctrineCache_ContainsCommandService.php',
            'console.command.public_alias.doctrine_cache.delete_command' => 'getConsole_Command_PublicAlias_DoctrineCache_DeleteCommandService.php',
            'console.command.public_alias.doctrine_cache.flush_command' => 'getConsole_Command_PublicAlias_DoctrineCache_FlushCommandService.php',
            'console.command.public_alias.doctrine_cache.stats_command' => 'getConsole_Command_PublicAlias_DoctrineCache_StatsCommandService.php',
            'console.command_loader' => 'getConsole_CommandLoaderService.php',
            'filesystem' => 'getFilesystemService.php',
            'form.type.file' => 'getForm_Type_FileService.php',
            'monolog.logger.console' => 'getMonolog_Logger_ConsoleService.php',
            'monolog.logger.doctrine' => 'getMonolog_Logger_DoctrineService.php',
            'monolog.logger.pimcore' => 'getMonolog_Logger_PimcoreService.php',
            'monolog.logger.pimcore_admin.session' => 'getMonolog_Logger_PimcoreAdmin_SessionService.php',
            'monolog.logger.pimcore_api' => 'getMonolog_Logger_PimcoreApiService.php',
            'monolog.logger.session' => 'getMonolog_Logger_SessionService.php',
            'monolog.logger.translation' => 'getMonolog_Logger_TranslationService.php',
            'pimcore.analytics.google.fallback_service_locator' => 'getPimcore_Analytics_Google_FallbackServiceLocatorService.php',
            'pimcore.bundle_locator' => 'getPimcore_BundleLocatorService.php',
            'pimcore.custom_report.adapter.factories' => 'getPimcore_CustomReport_Adapter_FactoriesService.php',
            'pimcore.document.tag.handler' => 'getPimcore_Document_Tag_HandlerService.php',
            'pimcore.document.tag.naming.strategy' => 'getPimcore_Document_Tag_Naming_StrategyService.php',
            'pimcore.implementation_loader.object.data' => 'getPimcore_ImplementationLoader_Object_DataService.php',
            'pimcore.implementation_loader.object.layout' => 'getPimcore_ImplementationLoader_Object_LayoutService.php',
            'pimcore.locale.intl_formatter' => 'getPimcore_Locale_IntlFormatterService.php',
            'pimcore.model.factory' => 'getPimcore_Model_FactoryService.php',
            'pimcore.newsletter.address_source_adapter.factories' => 'getPimcore_Newsletter_AddressSourceAdapter_FactoriesService.php',
            'pimcore.templating.engine.php' => 'getPimcore_Templating_Engine_PhpService.php',
            'pimcore.templating.engine.twig' => 'getPimcore_Templating_Engine_TwigService.php',
            'pimcore.templating.view_helper.cache' => 'getPimcore_Templating_ViewHelper_CacheService.php',
            'pimcore.templating.view_helper.device' => 'getPimcore_Templating_ViewHelper_DeviceService.php',
            'pimcore.templating.view_helper.get_all_params' => 'getPimcore_Templating_ViewHelper_GetAllParamsService.php',
            'pimcore.templating.view_helper.get_param' => 'getPimcore_Templating_ViewHelper_GetParamService.php',
            'pimcore.templating.view_helper.head_link' => 'getPimcore_Templating_ViewHelper_HeadLinkService.php',
            'pimcore.templating.view_helper.head_script' => 'getPimcore_Templating_ViewHelper_HeadScriptService.php',
            'pimcore.templating.view_helper.head_style' => 'getPimcore_Templating_ViewHelper_HeadStyleService.php',
            'pimcore.templating.view_helper.head_title' => 'getPimcore_Templating_ViewHelper_HeadTitleService.php',
            'pimcore.templating.view_helper.inline_script' => 'getPimcore_Templating_ViewHelper_InlineScriptService.php',
            'pimcore.templating.view_helper.pimcore_url' => 'getPimcore_Templating_ViewHelper_PimcoreUrlService.php',
            'pimcore.templating.view_helper.placeholder' => 'getPimcore_Templating_ViewHelper_PlaceholderService.php',
            'pimcore.web_path_resolver' => 'getPimcore_WebPathResolverService.php',
            'pimcore.workflow.place-options-provider' => 'getPimcore_Workflow_PlaceoptionsproviderService.php',
            'pimcore_admin.security.admin_authenticator' => 'getPimcoreAdmin_Security_AdminAuthenticatorService.php',
            'pimcore_admin.security.logout_success_handler' => 'getPimcoreAdmin_Security_LogoutSuccessHandlerService.php',
            'pimcore_admin.security.user_checker' => 'getPimcoreAdmin_Security_UserCheckerService.php',
            'pimcore_admin.security.user_provider' => 'getPimcoreAdmin_Security_UserProviderService.php',
            'pimcore_admin.security.webservice_authenticator' => 'getPimcoreAdmin_Security_WebserviceAuthenticatorService.php',
            'pimcore_admin.serializer' => 'getPimcoreAdmin_SerializerService.php',
            'pimcore_admin.webservice.service' => 'getPimcoreAdmin_Webservice_ServiceService.php',
            'presta_sitemap.dump_command' => 'getPrestaSitemap_DumpCommandService.php',
            'presta_sitemap.dumper' => 'getPrestaSitemap_DumperService.php',
            'presta_sitemap.generator' => 'getPrestaSitemap_GeneratorService.php',
            'routing.loader' => 'getRouting_LoaderService.php',
            'scheb_two_factor.firewall_context' => 'getSchebTwoFactor_FirewallContextService.php',
            'scheb_two_factor.form_controller' => 'getSchebTwoFactor_FormControllerService.php',
            'scheb_two_factor.security.google_authenticator' => 'getSchebTwoFactor_Security_GoogleAuthenticatorService.php',
            'security.authentication_utils' => 'getSecurity_AuthenticationUtilsService.php',
            'security.csrf.token_manager' => 'getSecurity_Csrf_TokenManagerService.php',
            'security.password_encoder' => 'getSecurity_PasswordEncoderService.php',
            'serializer' => 'getSerializerService.php',
            'services_resetter' => 'getServicesResetterService.php',
            'session' => 'getSessionService.php',
            'swiftmailer.mailer.pimcore_mailer' => 'getSwiftmailer_Mailer_PimcoreMailerService.php',
            'swiftmailer.mailer.pimcore_mailer.transport' => 'getSwiftmailer_Mailer_PimcoreMailer_TransportService.php',
            'templating' => 'getTemplatingService.php',
            'templating.loader' => 'getTemplating_LoaderService.php',
            'twig.controller.exception' => 'getTwig_Controller_ExceptionService.php',
            'twig.controller.preview_error' => 'getTwig_Controller_PreviewErrorService.php',
            'validator' => 'getValidatorService.php',
        ];
        $this->aliases = [
            'Doctrine\\Common\\Persistence\\ConnectionRegistry' => 'doctrine',
            'Pimcore\\Db\\Connection' => 'doctrine.dbal.default_connection',
            'Pimcore\\Db\\ConnectionInterface' => 'doctrine.dbal.default_connection',
            'Pimcore\\Kernel' => 'kernel',
            'Pimcore\\Localization\\Locale' => 'Pimcore\\Localization\\LocaleServiceInterface',
            'Pimcore\\Localization\\LocaleService' => 'Pimcore\\Localization\\LocaleServiceInterface',
            'Scheb\\TwoFactorBundle\\Security\\TwoFactor\\Provider\\Google\\GoogleAuthenticator' => 'scheb_two_factor.security.google_authenticator',
            'Scheb\\TwoFactorBundle\\Security\\TwoFactor\\Provider\\Google\\GoogleAuthenticatorInterface' => 'scheb_two_factor.security.google_authenticator',
            'Scheb\\TwoFactorBundle\\Security\\TwoFactor\\TwoFactorFirewallContext' => 'scheb_two_factor.firewall_context',
            'database_connection' => 'doctrine.dbal.default_connection',
            'mailer' => 'swiftmailer.mailer.pimcore_mailer',
            'pimcore.app_logger.db_writer' => 'Pimcore\\Log\\Handler\\ApplicationLoggerDb',
            'pimcore.cache.runtime' => 'Pimcore\\Cache\\Runtime',
            'pimcore.controller.config.controller_data_provider' => 'Pimcore\\Controller\\Config\\ControllerDataProvider',
            'pimcore.document.renderer' => 'Pimcore\\Document\\Renderer\\DocumentRenderer',
            'pimcore.document_service' => 'Pimcore\\Model\\Document\\Service',
            'pimcore.event_listener.frontend.cookie_policy_notice' => 'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\CookiePolicyNoticeListener',
            'pimcore.event_listener.frontend.full_page_cache' => 'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FullPageCacheListener',
            'pimcore.event_listener.frontend.google_analytics_code' => 'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleAnalyticsCodeListener',
            'pimcore.event_listener.frontend.google_tag_manager' => 'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleTagManagerListener',
            'pimcore.event_listener.frontend.tag_manager' => 'Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\TagManagerListener',
            'pimcore.event_listener.workflow_management' => 'Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener',
            'pimcore.extension.bundle_manager' => 'Pimcore\\Extension\\Bundle\\PimcoreBundleManager',
            'pimcore.extension.config' => 'Pimcore\\Extension\\Config',
            'pimcore.http.request_helper' => 'Pimcore\\Http\\RequestHelper',
            'pimcore.http.response_helper' => 'Pimcore\\Http\\ResponseHelper',
            'pimcore.http_client' => 'GuzzleHttp\\Client',
            'pimcore.locale' => 'Pimcore\\Localization\\LocaleServiceInterface',
            'pimcore.rest_client' => 'Pimcore\\Tool\\RestClient',
            'pimcore.service.request.document_resolver' => 'Pimcore\\Http\\Request\\Resolver\\DocumentResolver',
            'pimcore.service.request.editmode_resolver' => 'Pimcore\\Http\\Request\\Resolver\\EditmodeResolver',
            'pimcore.service.request.output_timestamp_resolver' => 'Pimcore\\Http\\Request\\Resolver\\OutputTimestampResolver',
            'pimcore.service.request.pimcore_context_resolver' => 'Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver',
            'pimcore.service.request.response_header_resolver' => 'Pimcore\\Http\\Request\\Resolver\\ResponseHeaderResolver',
            'pimcore.service.request.site_resolver' => 'Pimcore\\Http\\Request\\Resolver\\SiteResolver',
            'pimcore.service.request.template_resolver' => 'Pimcore\\Http\\Request\\Resolver\\TemplateResolver',
            'pimcore.service.request.template_vars_resolver' => 'Pimcore\\Http\\Request\\Resolver\\TemplateVarsResolver',
            'pimcore.service.request.view_model_resolver' => 'Pimcore\\Http\\Request\\Resolver\\ViewModelResolver',
            'pimcore.templating.engine.delegating' => 'templating',
            'pimcore.tool.assets_installer' => 'Pimcore\\Tool\\AssetsInstaller',
            'pimcore.translator' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
            'pimcore_admin.security.token_storage_user_resolver' => 'Pimcore\\Bundle\\AdminBundle\\Security\\User\\TokenStorageUserResolver',
            'swiftmailer.transport' => 'swiftmailer.mailer.pimcore_mailer.transport',
            'translator' => 'Symfony\\Contracts\\Translation\\TranslatorInterface',
        ];
    }

    public function compile()
    {
        throw new LogicException('You cannot compile a dumped container that was already compiled.');
    }

    public function isCompiled()
    {
        return true;
    }

    public function getRemovedIds()
    {
        return require $this->containerDir.\DIRECTORY_SEPARATOR.'removed-ids.php';
    }

    protected function load($file, $lazyLoad = true)
    {
        return require $this->containerDir.\DIRECTORY_SEPARATOR.$file;
    }

    protected function createProxy($class, \Closure $factory)
    {
        class_exists($class, false) || $this->load("{$class}.php");

        return $factory();
    }

    /*
     * Gets the public 'Pimcore\Bundle\AdminBundle\EventListener\CsrfProtectionListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\CsrfProtectionListener
     */
    protected function getCsrfProtectionListenerService()
    {
        $this->services['Pimcore\\Bundle\\AdminBundle\\EventListener\\CsrfProtectionListener'] = $instance = new \Pimcore\Bundle\AdminBundle\EventListener\CsrfProtectionListener([], ($this->services['pimcore.templating.engine.php'] ?? $this->load('getPimcore_Templating_Engine_PhpService.php')));

        $instance->setLogger(($this->services['monolog.logger.admin'] ?? $this->getMonolog_Logger_AdminService()));
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the public 'Pimcore\Bundle\AdminBundle\Security\User\TokenStorageUserResolver' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\Security\User\TokenStorageUserResolver
     */
    protected function getTokenStorageUserResolverService()
    {
        return $this->services['Pimcore\\Bundle\\AdminBundle\\Security\\User\\TokenStorageUserResolver'] = new \Pimcore\Bundle\AdminBundle\Security\User\TokenStorageUserResolver(($this->services['security.token_storage'] ?? ($this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())));
    }

    /*
     * Gets the public 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\CookiePolicyNoticeListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\CookiePolicyNoticeListener
     */
    protected function getCookiePolicyNoticeListenerService()
    {
        $this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\CookiePolicyNoticeListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\CookiePolicyNoticeListener(($this->services['kernel'] ?? $this->get('kernel', 1)));

        $instance->loadTemplateFromResource('@PimcoreCoreBundle/Resources/misc/cookie-policy-default-template.html');
        $instance->setTranslator(($this->services['Symfony\\Contracts\\Translation\\TranslatorInterface'] ?? $this->getTranslatorInterfaceService()));
        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the public 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\FullPageCacheListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\FullPageCacheListener
     */
    protected function getFullPageCacheListenerService()
    {
        $a = ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService());

        $this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FullPageCacheListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\FullPageCacheListener(($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] ?? ($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] = new \Pimcore\Targeting\VisitorInfoStorage())), new \Pimcore\Cache\FullPage\SessionStatus('_sf2_meta', $a), $a);

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the public 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleAnalyticsCodeListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleAnalyticsCodeListener
     */
    protected function getGoogleAnalyticsCodeListenerService()
    {
        $this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleAnalyticsCodeListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleAnalyticsCodeListener(($this->privates['Pimcore\\Analytics\\Google\\Tracker'] ?? $this->getTrackerService()));

        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the public 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleTagManagerListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleTagManagerListener
     */
    protected function getGoogleTagManagerListenerService()
    {
        $this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleTagManagerListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleTagManagerListener(($this->privates['Pimcore\\Analytics\\SiteId\\SiteIdProvider'] ?? $this->getSiteIdProviderService()), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->services['templating'] ?? $this->load('getTemplatingService.php')));

        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the public 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\TagManagerListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\TagManagerListener
     */
    protected function getTagManagerListenerService()
    {
        $this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\TagManagerListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\TagManagerListener(($this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] ?? $this->getEditmodeResolverService()));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));
        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));

        return $instance;
    }

    /*
     * Gets the public 'Pimcore\Document\DocumentStack' shared autowired service.
     *
     * @return \Pimcore\Document\DocumentStack
     */
    protected function getDocumentStackService()
    {
        return $this->services['Pimcore\\Document\\DocumentStack'] = new \Pimcore\Document\DocumentStack();
    }

    /*
     * Gets the public 'Pimcore\Extension\Bundle\PimcoreBundleManager' shared autowired service.
     *
     * @return \Pimcore\Extension\Bundle\PimcoreBundleManager
     */
    protected function getPimcoreBundleManagerService()
    {
        return $this->services['Pimcore\\Extension\\Bundle\\PimcoreBundleManager'] = new \Pimcore\Extension\Bundle\PimcoreBundleManager(new \Pimcore\Extension\Bundle\Config\StateConfig(($this->services['Pimcore\\Extension\\Config'] ?? $this->get('Pimcore\\Extension\\Config', 1))), new \Pimcore\Extension\Bundle\PimcoreBundleLocator(new \Pimcore\Composer\PackageInfo(), $this->parameters['pimcore.extensions.bundles.search_paths']), ($this->services['kernel'] ?? $this->get('kernel', 1)), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->services['router'] ?? $this->getRouterService()));
    }

    /*
     * Gets the public 'Pimcore\Http\RequestHelper' shared autowired service.
     *
     * @return \Pimcore\Http\RequestHelper
     */
    protected function getRequestHelperService()
    {
        return $this->services['Pimcore\\Http\\RequestHelper'] = new \Pimcore\Http\RequestHelper(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'Pimcore\Http\Request\Resolver\DocumentResolver' shared autowired service.
     *
     * @return \Pimcore\Http\Request\Resolver\DocumentResolver
     */
    protected function getDocumentResolverService()
    {
        return $this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] = new \Pimcore\Http\Request\Resolver\DocumentResolver(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'Pimcore\Http\Request\Resolver\EditmodeResolver' shared autowired service.
     *
     * @return \Pimcore\Http\Request\Resolver\EditmodeResolver
     */
    protected function getEditmodeResolverService()
    {
        $this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] = $instance = new \Pimcore\Http\Request\Resolver\EditmodeResolver(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->services['pimcore_admin.security.user_loader'] ?? $this->getPimcoreAdmin_Security_UserLoaderService()), ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()));

        $a = ($this->services['monolog.logger.init'] ?? $this->getMonolog_Logger_InitService());

        $instance->setLogger($a);
        $instance->setLogger($a);

        return $instance;
    }

    /*
     * Gets the public 'Pimcore\Http\Request\Resolver\OutputTimestampResolver' shared autowired service.
     *
     * @return \Pimcore\Http\Request\Resolver\OutputTimestampResolver
     */
    protected function getOutputTimestampResolverService()
    {
        return $this->services['Pimcore\\Http\\Request\\Resolver\\OutputTimestampResolver'] = new \Pimcore\Http\Request\Resolver\OutputTimestampResolver(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'Pimcore\Http\Request\Resolver\PimcoreContextResolver' shared autowired service.
     *
     * @return \Pimcore\Http\Request\Resolver\PimcoreContextResolver
     */
    protected function getPimcoreContextResolverService()
    {
        return $this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] = new \Pimcore\Http\Request\Resolver\PimcoreContextResolver(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->services['pimcore.service.context.pimcore_context_guesser'] ?? $this->getPimcore_Service_Context_PimcoreContextGuesserService()));
    }

    /*
     * Gets the public 'Pimcore\Http\Request\Resolver\ResponseHeaderResolver' shared autowired service.
     *
     * @return \Pimcore\Http\Request\Resolver\ResponseHeaderResolver
     */
    protected function getResponseHeaderResolverService()
    {
        return $this->services['Pimcore\\Http\\Request\\Resolver\\ResponseHeaderResolver'] = new \Pimcore\Http\Request\Resolver\ResponseHeaderResolver(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'Pimcore\Http\Request\Resolver\SiteResolver' shared autowired service.
     *
     * @return \Pimcore\Http\Request\Resolver\SiteResolver
     */
    protected function getSiteResolverService()
    {
        return $this->services['Pimcore\\Http\\Request\\Resolver\\SiteResolver'] = new \Pimcore\Http\Request\Resolver\SiteResolver(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'Pimcore\Http\ResponseHelper' shared autowired service.
     *
     * @return \Pimcore\Http\ResponseHelper
     */
    protected function getResponseHelperService()
    {
        return $this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper();
    }

    /*
     * Gets the public 'Pimcore\Model\Document\Service' shared autowired service.
     *
     * @return \Pimcore\Model\Document\Service
     */
    protected function getServiceService()
    {
        return $this->services['Pimcore\\Model\\Document\\Service'] = new \Pimcore\Model\Document\Service();
    }

    /*
     * Gets the public 'Pimcore\Targeting\Document\DocumentTargetingConfigurator' shared autowired service.
     *
     * @return \Pimcore\Targeting\Document\DocumentTargetingConfigurator
     */
    protected function getDocumentTargetingConfiguratorService()
    {
        return $this->services['Pimcore\\Targeting\\Document\\DocumentTargetingConfigurator'] = new \Pimcore\Targeting\Document\DocumentTargetingConfigurator(($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] ?? ($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] = new \Pimcore\Targeting\VisitorInfoStorage())), ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()), ($this->services['pimcore_admin.security.user_loader'] ?? $this->getPimcoreAdmin_Security_UserLoaderService()), ($this->services['pimcore.cache.core.handler'] ?? $this->getPimcore_Cache_Core_HandlerService()));
    }

    /*
     * Gets the public 'Symfony\Bridge\Twig\Extension\WebLinkExtension' shared service.
     *
     * @return \Symfony\Bridge\Twig\Extension\WebLinkExtension
     */
    protected function getWebLinkExtensionService()
    {
        return $this->services['Symfony\\Bridge\\Twig\\Extension\\WebLinkExtension'] = new \Symfony\Bridge\Twig\Extension\WebLinkExtension(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the public 'Symfony\Contracts\Translation\TranslatorInterface' shared autowired service.
     *
     * @return \Pimcore\Translation\Translator
     */
    protected function getTranslatorInterfaceService()
    {
        $this->services['Symfony\\Contracts\\Translation\\TranslatorInterface'] = $instance = new \Pimcore\Translation\Translator(($this->privates['translator.default'] ?? $this->getTranslator_DefaultService()));

        $instance->setKernel(($this->services['kernel'] ?? $this->get('kernel', 1)));
        $instance->setAdminPath('@PimcoreCoreBundle/Resources/translations');

        return $instance;
    }

    /*
     * Gets the public 'cmf_routing.route_provider' shared autowired service.
     *
     * @return \Pimcore\Routing\DynamicRouteProvider
     */
    protected function getCmfRouting_RouteProviderService()
    {
        $this->services['cmf_routing.route_provider'] = $instance = new \Pimcore\Routing\DynamicRouteProvider(($this->services['Pimcore\\Http\\Request\\Resolver\\SiteResolver'] ?? $this->getSiteResolverService()));

        $instance->addHandler(($this->privates['Pimcore\\Routing\\Dynamic\\DocumentRouteHandler'] ?? $this->getDocumentRouteHandlerService()));

        return $instance;
    }

    /*
     * Gets the public 'doctrine' shared service.
     *
     * @return \Doctrine\Bundle\DoctrineBundle\Registry
     */
    protected function getDoctrineService()
    {
        return $this->services['doctrine'] = new \Doctrine\Bundle\DoctrineBundle\Registry($this, $this->parameters['doctrine.connections'], [], 'default', '');
    }

    /*
     * Gets the public 'doctrine.dbal.default_connection' shared service.
     *
     * @return \Pimcore\Db\Connection
     */
    protected function getDoctrine_Dbal_DefaultConnectionService()
    {
        $a = new \Symfony\Bridge\Doctrine\ContainerAwareEventManager($this);
        $a->addEventSubscriber(new \Symfony\Cmf\Bundle\RoutingBundle\Doctrine\RouteConditionMetadataListener());

        return $this->services['doctrine.dbal.default_connection'] = (new \Doctrine\Bundle\DoctrineBundle\ConnectionFactory([]))->createConnection(['driver' => 'pdo_mysql', 'charset' => 'UTF8MB4', 'host' => 'localhost', 'port' => '3306', 'user' => 'root', 'password' => 'asdf1@3$', 'dbname' => 'cari_bengkel', 'driverOptions' => [], 'wrapperClass' => '\\Pimcore\\Db\\Connection', 'defaultTableOptions' => ['charset' => 'UTF8MB4', 'collate' => 'utf8mb4_general_ci']], new \Doctrine\DBAL\Configuration(), $a, ['enum' => 'string', 'bit' => 'boolean']);
    }

    /*
     * Gets the public 'event_dispatcher' shared service.
     *
     * @return \Symfony\Component\EventDispatcher\EventDispatcher
     */
    protected function getEventDispatcherService()
    {
        $this->services['event_dispatcher'] = $instance = new \Symfony\Component\EventDispatcher\EventDispatcher();

        $instance->addListener('scheb_two_factor.authentication.complete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\TwoFactorListener'] ?? ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\TwoFactorListener'] = new \Pimcore\Bundle\AdminBundle\EventListener\TwoFactorListener()));
        }, 1 => 'onAuthenticationComplete'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['scheb_two_factor.trusted_cookie_response_listener'] ?? $this->getSchebTwoFactor_TrustedCookieResponseListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleAnalyticsCodeListener'] ?? $this->getGoogleAnalyticsCodeListenerService());
        }, 1 => 'onKernelResponse'], -110);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\CookiePolicyNoticeListener'] ?? $this->getCookiePolicyNoticeListenerService());
        }, 1 => 'onKernelResponse'], -109);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleTagManagerListener'] ?? $this->getGoogleTagManagerListenerService());
        }, 1 => 'onKernelResponse'], -108);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\TagManagerListener'] ?? $this->getTagManagerListenerService());
        }, 1 => 'onKernelResponse'], -107);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FullPageCacheListener'] ?? $this->getFullPageCacheListenerService());
        }, 1 => 'onKernelRequest'], 6);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FullPageCacheListener'] ?? $this->getFullPageCacheListenerService());
        }, 1 => 'onKernelResponse'], -120);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FullPageCacheListener'] ?? $this->getFullPageCacheListenerService());
        }, 1 => 'stopPropagationCheck'], 100);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\MaintenancePageListener'] ?? $this->getMaintenancePageListenerService());
        }, 1 => 'onKernelRequest'], 620);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['response_listener'] ?? ($this->privates['response_listener'] = new \Symfony\Component\HttpKernel\EventListener\ResponseListener('UTF-8')));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['streamed_response_listener'] ?? ($this->privates['streamed_response_listener'] = new \Symfony\Component\HttpKernel\EventListener\StreamedResponseListener()));
        }, 1 => 'onKernelResponse'], -1024);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['locale_listener'] ?? $this->getLocaleListener2Service());
        }, 1 => 'setDefaultLocale'], 100);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['locale_listener'] ?? $this->getLocaleListener2Service());
        }, 1 => 'onKernelRequest'], 16);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['locale_listener'] ?? $this->getLocaleListener2Service());
        }, 1 => 'onKernelFinishRequest'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['validate_request_listener'] ?? ($this->privates['validate_request_listener'] = new \Symfony\Component\HttpKernel\EventListener\ValidateRequestListener()));
        }, 1 => 'onKernelRequest'], 256);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['resolve_controller_name_subscriber'] ?? $this->getResolveControllerNameSubscriberService());
        }, 1 => 'onKernelRequest'], 24);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['locale_aware_listener'] ?? $this->getLocaleAwareListenerService());
        }, 1 => 'onKernelRequest'], 15);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['locale_aware_listener'] ?? $this->getLocaleAwareListenerService());
        }, 1 => 'onKernelFinishRequest'], -15);
        $instance->addListener('console.error', [0 => function () {
            return ($this->privates['console.error_listener'] ?? $this->load('getConsole_ErrorListenerService.php'));
        }, 1 => 'onConsoleError'], -128);
        $instance->addListener('console.terminate', [0 => function () {
            return ($this->privates['console.error_listener'] ?? $this->load('getConsole_ErrorListenerService.php'));
        }, 1 => 'onConsoleTerminate'], -128);
        $instance->addListener('console.error', [0 => function () {
            return ($this->privates['console.suggest_missing_package_subscriber'] ?? ($this->privates['console.suggest_missing_package_subscriber'] = new \Symfony\Bundle\FrameworkBundle\EventListener\SuggestMissingPackageSubscriber()));
        }, 1 => 'onConsoleError'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['session_listener'] ?? $this->getSessionListenerService());
        }, 1 => 'onKernelRequest'], 128);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['session_listener'] ?? $this->getSessionListenerService());
        }, 1 => 'onKernelResponse'], -1000);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['session_listener'] ?? $this->getSessionListenerService());
        }, 1 => 'onFinishRequest'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['debug.debug_handlers_listener'] ?? $this->getDebug_DebugHandlersListenerService());
        }, 1 => 'configure'], 2048);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['debug.debug_handlers_listener'] ?? $this->getDebug_DebugHandlersListenerService());
        }, 1 => 'onKernelException'], -2048);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['router_listener'] ?? $this->getRouterListenerService());
        }, 1 => 'onKernelRequest'], 32);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['router_listener'] ?? $this->getRouterListenerService());
        }, 1 => 'onKernelFinishRequest'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['router_listener'] ?? $this->getRouterListenerService());
        }, 1 => 'onKernelException'], -64);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['web_link.add_link_header_listener'] ?? ($this->privates['web_link.add_link_header_listener'] = new \Symfony\Component\WebLink\EventListener\AddLinkHeaderListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['security.firewall'] ?? $this->getSecurity_FirewallService());
        }, 1 => 'configureLogoutUrlGenerator'], 8);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['security.firewall'] ?? $this->getSecurity_FirewallService());
        }, 1 => 'onKernelRequest'], 8);
        $instance->addListener('kernel.finish_request', [0 => function () {
            return ($this->privates['security.firewall'] ?? $this->getSecurity_FirewallService());
        }, 1 => 'onKernelFinishRequest'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['security.rememberme.response_listener'] ?? ($this->privates['security.rememberme.response_listener'] = new \Symfony\Component\Security\Http\RememberMe\ResponseListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['twig.exception_listener'] ?? $this->load('getTwig_ExceptionListenerService.php'));
        }, 1 => 'logKernelException'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['twig.exception_listener'] ?? $this->load('getTwig_ExceptionListenerService.php'));
        }, 1 => 'onKernelException'], -128);
        $instance->addListener('Symfony\\Component\\Mailer\\Event\\MessageEvent', [0 => function () {
            return ($this->privates['twig.mailer.message_listener'] ?? $this->load('getTwig_Mailer_MessageListenerService.php'));
        }, 1 => 'onMessage'], 0);
        $instance->addListener('console.command', [0 => function () {
            return ($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService());
        }, 1 => 'onCommand'], 255);
        $instance->addListener('console.terminate', [0 => function () {
            return ($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService());
        }, 1 => 'onTerminate'], -255);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->load('getSwiftmailer_EmailSender_ListenerService.php'));
        }, 1 => 'onException'], 0);
        $instance->addListener('kernel.terminate', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->load('getSwiftmailer_EmailSender_ListenerService.php'));
        }, 1 => 'onTerminate'], 0);
        $instance->addListener('console.error', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->load('getSwiftmailer_EmailSender_ListenerService.php'));
        }, 1 => 'onException'], 0);
        $instance->addListener('console.terminate', [0 => function () {
            return ($this->privates['swiftmailer.email_sender.listener'] ?? $this->load('getSwiftmailer_EmailSender_ListenerService.php'));
        }, 1 => 'onTerminate'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.controller.listener'] ?? $this->getSensioFrameworkExtra_Controller_ListenerService());
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.converter.listener'] ?? $this->getSensioFrameworkExtra_Converter_ListenerService());
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.view.listener'] ?? $this->getSensioFrameworkExtra_View_ListenerService());
        }, 1 => 'onKernelController'], -128);
        $instance->addListener('kernel.view', [0 => function () {
            return ($this->privates['sensio_framework_extra.view.listener'] ?? $this->getSensioFrameworkExtra_View_ListenerService());
        }, 1 => 'onKernelView'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['sensio_framework_extra.cache.listener'] ?? ($this->privates['sensio_framework_extra.cache.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\HttpCacheListener()));
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['sensio_framework_extra.cache.listener'] ?? ($this->privates['sensio_framework_extra.cache.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\HttpCacheListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.controller_arguments', [0 => function () {
            return ($this->privates['sensio_framework_extra.security.listener'] ?? $this->getSensioFrameworkExtra_Security_ListenerService());
        }, 1 => 'onKernelControllerArguments'], 0);
        $instance->addListener('kernel.controller_arguments', [0 => function () {
            return ($this->privates['framework_extra_bundle.event.is_granted'] ?? $this->getFrameworkExtraBundle_Event_IsGrantedService());
        }, 1 => 'onKernelControllerArguments'], 0);
        $instance->addListener('presta_sitemap.populate', [0 => function () {
            return ($this->privates['presta_sitemap.eventlistener.route_annotation'] ?? $this->load('getPrestaSitemap_Eventlistener_RouteAnnotationService.php'));
        }, 1 => 'registerRouteAnnotation'], 0);
        $instance->addListener('workflow.completed', [0 => function () {
            return ($this->privates['Pimcore\\Workflow\\EventSubscriber\\NotificationEmailSubscriber'] ?? $this->load('getNotificationEmailSubscriberService.php'));
        }, 1 => 'onWorkflowCompleted'], 0);
        $instance->addListener('workflow.completed', [0 => function () {
            return ($this->privates['Pimcore\\Workflow\\EventSubscriber\\NotesSubscriber'] ?? $this->load('getNotesSubscriberService.php'));
        }, 1 => 'onWorkflowCompleted'], 1);
        $instance->addListener('workflow.enter', [0 => function () {
            return ($this->privates['Pimcore\\Workflow\\EventSubscriber\\NotesSubscriber'] ?? $this->load('getNotesSubscriberService.php'));
        }, 1 => 'onWorkflowEnter'], 0);
        $instance->addListener('pimcore.workflow.preGlobalAction', [0 => function () {
            return ($this->privates['Pimcore\\Workflow\\EventSubscriber\\NotesSubscriber'] ?? $this->load('getNotesSubscriberService.php'));
        }, 1 => 'onPreGlobalAction'], 0);
        $instance->addListener('pimcore.workflow.postGlobalAction', [0 => function () {
            return ($this->privates['Pimcore\\Workflow\\EventSubscriber\\NotesSubscriber'] ?? $this->load('getNotesSubscriberService.php'));
        }, 1 => 'onPostGlobalAction'], 0);
        $instance->addListener('workflow.completed', [0 => function () {
            return ($this->privates['Pimcore\\Workflow\\EventSubscriber\\ChangePublishedStateSubscriber'] ?? ($this->privates['Pimcore\\Workflow\\EventSubscriber\\ChangePublishedStateSubscriber'] = new \Pimcore\Workflow\EventSubscriber\ChangePublishedStateSubscriber()));
        }, 1 => 'onWorkflowCompleted'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FrontendRoutingListener'] ?? $this->getFrontendRoutingListenerService());
        }, 1 => 'onKernelRequest'], 512);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FrontendRoutingListener'] ?? $this->getFrontendRoutingListenerService());
        }, 1 => 'onKernelException'], 64);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\PimcoreContextListener'] ?? $this->getPimcoreContextListenerService());
        }, 1 => 'onKernelRequest'], 24);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\DocumentFallbackListener'] ?? $this->getDocumentFallbackListenerService());
        }, 1 => 'onKernelRequest'], 20);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\PimcoreHeaderListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\PimcoreHeaderListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\PimcoreHeaderListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\LocaleListener'] ?? $this->getLocaleListenerService());
        }, 1 => 'onKernelRequest'], 1);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\LocaleListener'] ?? $this->getLocaleListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\TranslationDebugListener'] ?? $this->getTranslationDebugListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\ElementListener'] ?? $this->getElementListenerService());
        }, 1 => 'onKernelRequest'], 3);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\HardlinkCanonicalListener'] ?? $this->getHardlinkCanonicalListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\BlockStateListener'] ?? $this->getBlockStateListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\BlockStateListener'] ?? $this->getBlockStateListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\DocumentMetaDataListener'] ?? $this->getDocumentMetaDataListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\DocumentStackListener'] ?? $this->getDocumentStackListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\DocumentStackListener'] ?? $this->getDocumentStackListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.view', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ControllerViewModelListener'] ?? $this->load('getControllerViewModelListenerService.php'));
        }, 1 => 'onKernelView'], 10);
        $instance->addListener('kernel.view', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\ContentTemplateListener'] ?? $this->load('getContentTemplateListenerService.php'));
        }, 1 => 'onKernelView'], 16);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\EventedControllerListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\EventedControllerListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\EventedControllerListener()));
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\EventedControllerListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\EventedControllerListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\EventedControllerListener()));
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\TemplateControllerListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\TemplateControllerListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\TemplateControllerListener($this)));
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.view', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\TemplateControllerListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\TemplateControllerListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\TemplateControllerListener($this)));
        }, 1 => 'onKernelView'], 32);
        $instance->addListener('pimcore.dataobject.postDelete', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener'] ?? $this->load('getWorkflowManagementListenerService.php'));
        }, 1 => 'onElementPostDelete'], 0);
        $instance->addListener('pimcore.document.postDelete', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener'] ?? $this->load('getWorkflowManagementListenerService.php'));
        }, 1 => 'onElementPostDelete'], 0);
        $instance->addListener('pimcore.asset.postDelete', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener'] ?? $this->load('getWorkflowManagementListenerService.php'));
        }, 1 => 'onElementPostDelete'], 0);
        $instance->addListener('pimcore.admin.dataobject.get.preSendData', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener'] ?? $this->load('getWorkflowManagementListenerService.php'));
        }, 1 => 'onAdminElementGetPreSendData'], 0);
        $instance->addListener('pimcore.admin.asset.get.preSendData', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener'] ?? $this->load('getWorkflowManagementListenerService.php'));
        }, 1 => 'onAdminElementGetPreSendData'], 0);
        $instance->addListener('pimcore.admin.document.get.preSendData', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\CoreBundle\\EventListener\\WorkflowManagementListener'] ?? $this->load('getWorkflowManagementListenerService.php'));
        }, 1 => 'onAdminElementGetPreSendData'], 0);
        $instance->addListener('pimcore.dataobject.postCopy', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\ElementTagsListener()));
        }, 1 => 'onPostCopy'], 0);
        $instance->addListener('pimcore.document.postCopy', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\ElementTagsListener()));
        }, 1 => 'onPostCopy'], 0);
        $instance->addListener('pimcore.asset.postCopy', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\ElementTagsListener()));
        }, 1 => 'onPostCopy'], 0);
        $instance->addListener('pimcore.asset.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ElementTagsListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\ElementTagsListener()));
        }, 1 => 'onPostAssetDelete'], -9999);
        $instance->addListener('pimcore.dataobject.postAdd', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPostAddElement'], 0);
        $instance->addListener('pimcore.document.postAdd', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPostAddElement'], 0);
        $instance->addListener('pimcore.asset.postAdd', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPostAddElement'], 0);
        $instance->addListener('pimcore.dataobject.preDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPreDeleteElement'], 0);
        $instance->addListener('pimcore.document.preDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPreDeleteElement'], 0);
        $instance->addListener('pimcore.asset.preDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPreDeleteElement'], 0);
        $instance->addListener('pimcore.dataobject.postUpdate', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPostUpdateElement'], 0);
        $instance->addListener('pimcore.document.postUpdate', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPostUpdateElement'], 0);
        $instance->addListener('pimcore.asset.postUpdate', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\SearchBackendListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\SearchBackendListener()));
        }, 1 => 'onPostUpdateElement'], 0);
        $instance->addListener('pimcore.dataobject.postAdd', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostAdd'], 0);
        $instance->addListener('pimcore.document.postAdd', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostAdd'], 0);
        $instance->addListener('pimcore.asset.postAdd', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostAdd'], 0);
        $instance->addListener('pimcore.class.postAdd', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostAdd'], 0);
        $instance->addListener('pimcore.dataobject.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostDelete'], 0);
        $instance->addListener('pimcore.document.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostDelete'], 0);
        $instance->addListener('pimcore.asset.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostDelete'], 0);
        $instance->addListener('pimcore.class.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] ?? ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\UUIDListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\UUIDListener()));
        }, 1 => 'onPostDelete'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ResponseExceptionListener'] ?? $this->load('getResponseExceptionListenerService.php'));
        }, 1 => 'onKernelException'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ResponseHeaderListener'] ?? $this->getResponseHeaderListenerService());
        }, 1 => 'onKernelResponse'], 32);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\EditmodeListener'] ?? $this->getEditmodeListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\EditmodeListener'] ?? $this->getEditmodeListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ResponseStackListener'] ?? $this->getResponseStackListenerService());
        }, 1 => 'onKernelResponse'], 24);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\InternalWysiwygHtmlAttributeFilterListener'] ?? $this->getInternalWysiwygHtmlAttributeFilterListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleSearchConsoleVerificationListener'] ?? $this->getGoogleSearchConsoleVerificationListenerService());
        }, 1 => 'onKernelRequest'], 64);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\OutputTimestampListener'] ?? $this->getOutputTimestampListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('pimcore.test.kernel.booted', [0 => function () {
            return ($this->services['Pimcore\\Migrations\\Configuration\\ConfigurationFactory'] ?? $this->load('getConfigurationFactoryService.php'));
        }, 1 => 'reset'], 0);
        $instance->addListener('pimcore.admin.reports.save_settings', [0 => function () {
            return ($this->privates['Pimcore\\Analytics\\Piwik\\EventListener\\CacheListener'] ?? $this->load('getCacheListenerService.php'));
        }, 1 => 'onSaveSettings'], 0);
        $instance->addListener('pimcore.admin.index.settings', [0 => function () {
            return ($this->privates['Pimcore\\Analytics\\Piwik\\EventListener\\IndexSettingsListener'] ?? $this->load('getIndexSettingsListenerService.php'));
        }, 1 => 'addIndexSettings'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Analytics\\Piwik\\EventListener\\TrackingCodeListener'] ?? $this->getTrackingCodeListenerService());
        }, 1 => 'onKernelResponse'], -110);
        $instance->addListener('presta_sitemap.populate', [0 => function () {
            return ($this->privates['Pimcore\\Sitemap\\EventListener\\SitemapGeneratorListener'] ?? $this->load('getSitemapGeneratorListenerService.php'));
        }, 1 => 'onPopulateSitemap'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\TargetingListener'] ?? $this->getTargetingListenerService());
        }, 1 => 'onKernelRequest'], 7);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\TargetingListener'] ?? $this->getTargetingListenerService());
        }, 1 => 'onKernelResponse'], -115);
        $instance->addListener('pimcore.targeting.pre_resolve', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\TargetingListener'] ?? $this->getTargetingListenerService());
        }, 1 => 'onPreResolve'], 0);
        $instance->addListener('pimcore.tracking.piwik.code.tracking_data', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\PiwikVisitorIdListener'] ?? $this->load('getPiwikVisitorIdListenerService.php'));
        }, 1 => 'onPiwikTrackingData'], 0);
        $instance->addListener('pimcore.targeting.pre_resolve', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\DocumentTargetGroupListener'] ?? $this->load('getDocumentTargetGroupListenerService.php'));
        }, 1 => 'onVisitorInfoResolve'], 0);
        $instance->addListener('pimcore.cache.full_page.prepare_response', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\FullPageCacheCookieCleanupListener'] ?? ($this->privates['Pimcore\\Targeting\\EventListener\\FullPageCacheCookieCleanupListener'] = new \Pimcore\Targeting\EventListener\FullPageCacheCookieCleanupListener()));
        }, 1 => 'onPrepareFullPageCacheResponse'], 0);
        $instance->addListener('pimcore.targeting.visited_pages_count_match', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\VisitedPagesCountListener'] ?? $this->load('getVisitedPagesCountListenerService.php'));
        }, 1 => 'onVisitedPagesCountMatch'], 0);
        $instance->addListener('pimcore.targeting.post_resolve', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\VisitedPagesCountListener'] ?? $this->load('getVisitedPagesCountListenerService.php'));
        }, 1 => 'onPostResolveVisitorInfo'], 0);
        $instance->addListener('pimcore.targeting.pre_resolve', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\ToolbarListener'] ?? $this->getToolbarListenerService());
        }, 1 => 'onPreResolve'], -10);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Targeting\\EventListener\\ToolbarListener'] ?? $this->getToolbarListenerService());
        }, 1 => 'onKernelResponse'], -127);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\BruteforceProtectionListener'] ?? $this->getBruteforceProtectionListenerService());
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\BruteforceProtectionListener'] ?? $this->getBruteforceProtectionListenerService());
        }, 1 => 'onKernelException'], 0);
        $instance->addListener('kernel.controller', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\AdminAuthenticationDoubleCheckListener'] ?? $this->getAdminAuthenticationDoubleCheckListenerService());
        }, 1 => 'onKernelController'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->services['Pimcore\\Bundle\\AdminBundle\\EventListener\\CsrfProtectionListener'] ?? $this->getCsrfProtectionListenerService());
        }, 1 => 'handleRequest'], 0);
        $instance->addListener('kernel.exception', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\AdminExceptionListener'] ?? $this->load('getAdminExceptionListenerService.php'));
        }, 1 => 'onKernelException'], 0);
        $instance->addListener('pimcore.class.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\GridConfigListener'] ?? ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\GridConfigListener'] = new \Pimcore\Bundle\AdminBundle\EventListener\GridConfigListener()));
        }, 1 => 'onClassDelete'], 0);
        $instance->addListener('pimcore.user.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\GridConfigListener'] ?? ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\GridConfigListener'] = new \Pimcore\Bundle\AdminBundle\EventListener\GridConfigListener()));
        }, 1 => 'onUserDelete'], 0);
        $instance->addListener('pimcore.dataobject.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\GridConfigListener'] ?? ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\GridConfigListener'] = new \Pimcore\Bundle\AdminBundle\EventListener\GridConfigListener()));
        }, 1 => 'onObjectDelete'], 0);
        $instance->addListener('pimcore.class.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\ImportConfigListener'] ?? ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\ImportConfigListener'] = new \Pimcore\Bundle\AdminBundle\EventListener\ImportConfigListener()));
        }, 1 => 'onClassDelete'], 0);
        $instance->addListener('pimcore.user.postDelete', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\ImportConfigListener'] ?? ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\ImportConfigListener'] = new \Pimcore\Bundle\AdminBundle\EventListener\ImportConfigListener()));
        }, 1 => 'onUserDelete'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\HttpCacheListener'] ?? $this->getHttpCacheListenerService());
        }, 1 => 'onKernelResponse'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\CustomAdminEntryPointCheckListener'] ?? $this->getCustomAdminEntryPointCheckListenerService());
        }, 1 => 'onKernelRequest'], 560);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\UserPerspectiveListener'] ?? $this->getUserPerspectiveListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('kernel.request', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\UsageStatisticsListener'] ?? $this->getUsageStatisticsListenerService());
        }, 1 => 'onKernelRequest'], 0);
        $instance->addListener('kernel.response', [0 => function () {
            return ($this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\EnablePreviewTimeSliderListener'] ?? $this->getEnablePreviewTimeSliderListenerService());
        }, 1 => 'onKernelResponse'], 0);

        return $instance;
    }

    /*
     * Gets the public 'form.factory' shared service.
     *
     * @return \Symfony\Component\Form\FormFactory
     */
    protected function getForm_FactoryService()
    {
        return $this->services['form.factory'] = new \Symfony\Component\Form\FormFactory(($this->privates['form.registry'] ?? $this->getForm_RegistryService()));
    }

    /*
     * Gets the public 'http_kernel' shared service.
     *
     * @return \Symfony\Component\HttpKernel\HttpKernel
     */
    protected function getHttpKernelService()
    {
        return $this->services['http_kernel'] = new \Symfony\Component\HttpKernel\HttpKernel(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['controller_resolver'] ?? $this->getControllerResolverService()), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), new \Symfony\Component\HttpKernel\Controller\ArgumentResolver(($this->privates['argument_metadata_factory'] ?? ($this->privates['argument_metadata_factory'] = new \Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadataFactory())), new RewindableGenerator(function () {
            yield 0 => ($this->privates['argument_resolver.request_attribute'] ?? ($this->privates['argument_resolver.request_attribute'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\RequestAttributeValueResolver()));
            yield 1 => ($this->privates['argument_resolver.request'] ?? ($this->privates['argument_resolver.request'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\RequestValueResolver()));
            yield 2 => ($this->privates['argument_resolver.session'] ?? ($this->privates['argument_resolver.session'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\SessionValueResolver()));
            yield 3 => ($this->privates['security.user_value_resolver'] ?? $this->load('getSecurity_UserValueResolverService.php'));
            yield 4 => ($this->privates['Pimcore\\Controller\\ArgumentValueResolver\\DocumentValueResolver'] ?? $this->load('getDocumentValueResolverService.php'));
            yield 5 => ($this->privates['Pimcore\\Controller\\ArgumentValueResolver\\ViewModelValueResolver'] ?? $this->load('getViewModelValueResolverService.php'));
            yield 6 => ($this->privates['Pimcore\\Controller\\ArgumentValueResolver\\EditmodeValueResolver'] ?? $this->load('getEditmodeValueResolverService.php'));
            yield 7 => ($this->privates['Pimcore\\Controller\\ArgumentValueResolver\\TemplateVarsValueResolver'] ?? $this->load('getTemplateVarsValueResolverService.php'));
            yield 8 => ($this->privates['Pimcore\\Controller\\ArgumentValueResolver\\WebsiteConfigValueResolver'] ?? ($this->privates['Pimcore\\Controller\\ArgumentValueResolver\\WebsiteConfigValueResolver'] = new \Pimcore\Controller\ArgumentValueResolver\WebsiteConfigValueResolver()));
            yield 9 => ($this->privates['argument_resolver.service'] ?? $this->load('getArgumentResolver_ServiceService.php'));
            yield 10 => ($this->privates['argument_resolver.default'] ?? ($this->privates['argument_resolver.default'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\DefaultValueResolver()));
            yield 11 => ($this->privates['argument_resolver.variadic'] ?? ($this->privates['argument_resolver.variadic'] = new \Symfony\Component\HttpKernel\Controller\ArgumentResolver\VariadicValueResolver()));
        }, 12)));
    }

    /*
     * Gets the public 'monolog.logger.admin' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_AdminService()
    {
        $this->services['monolog.logger.admin'] = $instance = new \Symfony\Bridge\Monolog\Logger('admin');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'monolog.logger.cache' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_CacheService()
    {
        $this->services['monolog.logger.cache'] = $instance = new \Symfony\Bridge\Monolog\Logger('cache');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'monolog.logger.init' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_InitService()
    {
        $this->services['monolog.logger.init'] = $instance = new \Symfony\Bridge\Monolog\Logger('init');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'monolog.logger.php' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_PhpService()
    {
        $this->services['monolog.logger.php'] = $instance = new \Symfony\Bridge\Monolog\Logger('php');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'monolog.logger.request' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_RequestService()
    {
        $this->services['monolog.logger.request'] = $instance = new \Symfony\Bridge\Monolog\Logger('request');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'monolog.logger.router' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_RouterService()
    {
        $this->services['monolog.logger.router'] = $instance = new \Symfony\Bridge\Monolog\Logger('router');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'monolog.logger.routing' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_RoutingService()
    {
        $this->services['monolog.logger.routing'] = $instance = new \Symfony\Bridge\Monolog\Logger('routing');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'monolog.logger.security' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_Logger_SecurityService()
    {
        $this->services['monolog.logger.security'] = $instance = new \Symfony\Bridge\Monolog\Logger('security');

        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the public 'pimcore.cache.core.handler' shared autowired service.
     *
     * @return \Pimcore\Cache\Core\EventDispatchingCoreHandler
     */
    protected function getPimcore_Cache_Core_HandlerService()
    {
        $a = ($this->services['pimcore.cache.core.pool'] ?? $this->getPimcore_Cache_Core_PoolService());
        $b = new \Pimcore\Cache\Core\WriteLock($a);

        $c = ($this->services['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService());

        $b->setLogger($c);
        $b->setLogger($c);

        $this->services['pimcore.cache.core.handler'] = $instance = new \Pimcore\Cache\Core\EventDispatchingCoreHandler($a, $b, ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));

        $instance->setLogger($c);
        $instance->setLogger($c);

        return $instance;
    }

    /*
     * Gets the public 'pimcore.cache.core.pool' shared service.
     *
     * @return \Pimcore\Cache\Pool\Doctrine
     */
    protected function getPimcore_Cache_Core_PoolService()
    {
        $this->services['pimcore.cache.core.pool'] = $instance = new \Pimcore\Cache\Pool\Doctrine(($this->services['doctrine.dbal.default_connection'] ?? $this->getDoctrine_Dbal_DefaultConnectionService()), 2419200);

        $instance->setLogger(($this->services['monolog.logger.cache'] ?? $this->getMonolog_Logger_CacheService()));

        return $instance;
    }

    /*
     * Gets the public 'pimcore.controller.config.config_normalizer' shared autowired service.
     *
     * @return \Pimcore\Controller\Config\ConfigNormalizer
     */
    protected function getPimcore_Controller_Config_ConfigNormalizerService()
    {
        $this->services['pimcore.controller.config.config_normalizer'] = $instance = new \Pimcore\Controller\Config\ConfigNormalizer(($this->services['kernel'] ?? $this->get('kernel', 1)));

        $instance->setRoutingDefaults($this->parameters['pimcore.routing.defaults']);

        return $instance;
    }

    /*
     * Gets the public 'pimcore.document.tag.block_state_stack' shared autowired service.
     *
     * @return \Pimcore\Document\Tag\Block\BlockStateStack
     */
    protected function getPimcore_Document_Tag_BlockStateStackService()
    {
        return $this->services['pimcore.document.tag.block_state_stack'] = new \Pimcore\Document\Tag\Block\BlockStateStack();
    }

    /*
     * Gets the public 'pimcore.implementation_loader.document.tag' shared autowired service.
     *
     * @return \Pimcore\Model\Document\Tag\Loader\TagLoader
     */
    protected function getPimcore_ImplementationLoader_Document_TagService()
    {
        return $this->services['pimcore.implementation_loader.document.tag'] = new \Pimcore\Model\Document\Tag\Loader\TagLoader([0 => new \Pimcore\Loader\ImplementationLoader\ClassMapLoader(['href' => '\\Pimcore\\Model\\Document\\Tag\\Relation', 'multihref' => '\\Pimcore\\Model\\Document\\Tag\\Relations']), 1 => new \Pimcore\Model\Document\Tag\Loader\PrefixLoader([0 => '\\Pimcore\\Model\\Document\\Tag\\', 1 => '\\Document_Tag_'])]);
    }

    /*
     * Gets the public 'pimcore.routing.router.request_context' shared service.
     *
     * @return \Symfony\Component\Routing\RequestContext
     */
    protected function getPimcore_Routing_Router_RequestContextService()
    {
        return $this->services['pimcore.routing.router.request_context'] = new \Symfony\Component\Routing\RequestContext('', 'GET', 'localhost', 'http', 80, 443);
    }

    /*
     * Gets the public 'pimcore.service.context.pimcore_context_guesser' shared autowired service.
     *
     * @return \Pimcore\Http\Context\PimcoreContextGuesser
     */
    protected function getPimcore_Service_Context_PimcoreContextGuesserService()
    {
        $this->services['pimcore.service.context.pimcore_context_guesser'] = $instance = new \Pimcore\Http\Context\PimcoreContextGuesser(($this->services['pimcore.service.request_matcher_factory'] ?? ($this->services['pimcore.service.request_matcher_factory'] = new \Pimcore\Http\RequestMatcherFactory())));

        $instance->addContextRoutes('profiler', [0 => ['path' => '^/_(profiler|wdt)', 'route' => false, 'host' => false, 'methods' => []]]);
        $instance->addContextRoutes('admin', [0 => ['path' => '^/admin', 'route' => false, 'host' => false, 'methods' => []], 1 => ['route' => '^pimcore_admin_', 'path' => false, 'host' => false, 'methods' => []]]);
        $instance->addContextRoutes('webservice', [0 => ['path' => '^/webservice', 'route' => false, 'host' => false, 'methods' => []], 1 => ['route' => '^pimcore_webservice', 'path' => false, 'host' => false, 'methods' => []]]);
        $instance->addContextRoutes('plugin', [0 => ['path' => '^/plugin', 'route' => false, 'host' => false, 'methods' => []]]);

        return $instance;
    }

    /*
     * Gets the public 'pimcore.service.request_matcher_factory' shared autowired service.
     *
     * @return \Pimcore\Http\RequestMatcherFactory
     */
    protected function getPimcore_Service_RequestMatcherFactoryService()
    {
        return $this->services['pimcore.service.request_matcher_factory'] = new \Pimcore\Http\RequestMatcherFactory();
    }

    /*
     * Gets the public 'pimcore.templating.action_renderer' shared autowired service.
     *
     * @return \Pimcore\Templating\Renderer\ActionRenderer
     */
    protected function getPimcore_Templating_ActionRendererService()
    {
        return $this->services['pimcore.templating.action_renderer'] = new \Pimcore\Templating\Renderer\ActionRenderer(($this->privates['templating.helper.actions'] ?? $this->load('getTemplating_Helper_ActionsService.php')), ($this->services['pimcore.controller.config.config_normalizer'] ?? $this->getPimcore_Controller_Config_ConfigNormalizerService()));
    }

    /*
     * Gets the public 'pimcore.templating.include_renderer' shared autowired service.
     *
     * @return \Pimcore\Templating\Renderer\IncludeRenderer
     */
    protected function getPimcore_Templating_IncludeRendererService()
    {
        return $this->services['pimcore.templating.include_renderer'] = new \Pimcore\Templating\Renderer\IncludeRenderer(($this->services['pimcore.templating.action_renderer'] ?? $this->getPimcore_Templating_ActionRendererService()), ($this->services['Pimcore\\Targeting\\Document\\DocumentTargetingConfigurator'] ?? $this->getDocumentTargetingConfiguratorService()));
    }

    /*
     * Gets the public 'pimcore.templating.tag_renderer' shared autowired service.
     *
     * @return \Pimcore\Templating\Renderer\TagRenderer
     */
    protected function getPimcore_Templating_TagRendererService()
    {
        $this->services['pimcore.templating.tag_renderer'] = $instance = new \Pimcore\Templating\Renderer\TagRenderer(($this->services['pimcore.implementation_loader.document.tag'] ?? $this->getPimcore_ImplementationLoader_Document_TagService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] ?? $this->getEditmodeResolverService()));

        $a = ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService());

        $instance->setLogger($a);
        $instance->setLogger($a);

        return $instance;
    }

    /*
     * Gets the public 'pimcore.templating.view_helper.action' shared autowired service.
     *
     * @return \Pimcore\Templating\Helper\Action
     */
    protected function getPimcore_Templating_ViewHelper_ActionService()
    {
        $this->services['pimcore.templating.view_helper.action'] = $instance = new \Pimcore\Templating\Helper\Action(($this->services['pimcore.templating.action_renderer'] ?? $this->getPimcore_Templating_ActionRendererService()), ($this->services['Pimcore\\Targeting\\Document\\DocumentTargetingConfigurator'] ?? $this->getDocumentTargetingConfiguratorService()));

        $instance->setRoutingDefaults($this->parameters['pimcore.routing.defaults']);

        return $instance;
    }

    /*
     * Gets the public 'pimcore.templating.view_helper.glossary' shared autowired service.
     *
     * @return \Pimcore\Templating\Helper\Glossary
     */
    protected function getPimcore_Templating_ViewHelper_GlossaryService()
    {
        return $this->services['pimcore.templating.view_helper.glossary'] = new \Pimcore\Templating\Helper\Glossary(new \Pimcore\Tool\Glossary\Processor(($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] ?? $this->getEditmodeResolverService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService())));
    }

    /*
     * Gets the public 'pimcore.templating.view_helper.head_meta' shared autowired service.
     *
     * @return \Pimcore\Templating\Helper\HeadMeta
     */
    protected function getPimcore_Templating_ViewHelper_HeadMetaService()
    {
        return $this->services['pimcore.templating.view_helper.head_meta'] = new \Pimcore\Templating\Helper\HeadMeta(($this->services['pimcore.templating.view_helper.placeholder.container_service'] ?? $this->getPimcore_Templating_ViewHelper_Placeholder_ContainerServiceService()));
    }

    /*
     * Gets the public 'pimcore.templating.view_helper.inc' shared autowired service.
     *
     * @return \Pimcore\Templating\Helper\Inc
     */
    protected function getPimcore_Templating_ViewHelper_IncService()
    {
        return $this->services['pimcore.templating.view_helper.inc'] = new \Pimcore\Templating\Helper\Inc(($this->services['pimcore.templating.include_renderer'] ?? $this->getPimcore_Templating_IncludeRendererService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] ?? $this->getEditmodeResolverService()));
    }

    /*
     * Gets the public 'pimcore.templating.view_helper.navigation' shared autowired service.
     *
     * @return \Pimcore\Templating\Helper\Navigation
     */
    protected function getPimcore_Templating_ViewHelper_NavigationService($lazyLoad = true)
    {
        if ($lazyLoad) {
            return $this->services['pimcore.templating.view_helper.navigation'] = $this->createProxy('Navigation_a34f8f7', function () {
                return \Navigation_a34f8f7::staticProxyConstructor(function (&$wrappedInstance, \ProxyManager\Proxy\LazyLoadingInterface $proxy) {
                    $wrappedInstance = $this->getPimcore_Templating_ViewHelper_NavigationService(false);

                    $proxy->setProxyInitializer(null);

                    return true;
                });
            });
        }

        return new \Pimcore\Templating\Helper\Navigation(new \Pimcore\Navigation\Builder(($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService())), new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'breadcrumbs' => ['privates', 'Pimcore\\Navigation\\Renderer\\Breadcrumbs', 'getBreadcrumbsService.php', true],
            'menu' => ['privates', 'Pimcore\\Navigation\\Renderer\\Menu', 'getMenuService.php', true],
        ], [
            'breadcrumbs' => '?',
            'menu' => '?',
        ]));
    }

    /*
     * Gets the public 'pimcore.templating.view_helper.placeholder.container_service' shared autowired service.
     *
     * @return \Pimcore\Templating\Helper\Placeholder\ContainerService
     */
    protected function getPimcore_Templating_ViewHelper_Placeholder_ContainerServiceService()
    {
        $this->services['pimcore.templating.view_helper.placeholder.container_service'] = $instance = new \Pimcore\Templating\Helper\Placeholder\ContainerService();

        $instance->setEventDispatcher(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));

        return $instance;
    }

    /*
     * Gets the public 'pimcore.twig.extension.document_tag' shared autowired service.
     *
     * @return \Pimcore\Twig\Extension\DocumentTagExtension
     */
    protected function getPimcore_Twig_Extension_DocumentTagService()
    {
        return $this->services['pimcore.twig.extension.document_tag'] = new \Pimcore\Twig\Extension\DocumentTagExtension(($this->services['pimcore.templating.tag_renderer'] ?? $this->getPimcore_Templating_TagRendererService()));
    }

    /*
     * Gets the public 'pimcore.twig.extension.glossary' shared autowired service.
     *
     * @return \Pimcore\Twig\Extension\GlossaryExtension
     */
    protected function getPimcore_Twig_Extension_GlossaryService()
    {
        return $this->services['pimcore.twig.extension.glossary'] = new \Pimcore\Twig\Extension\GlossaryExtension(($this->services['pimcore.templating.view_helper.glossary'] ?? $this->getPimcore_Templating_ViewHelper_GlossaryService()));
    }

    /*
     * Gets the public 'pimcore.twig.extension.helpers' shared autowired service.
     *
     * @return \Pimcore\Twig\Extension\HelpersExtension
     */
    protected function getPimcore_Twig_Extension_HelpersService()
    {
        return $this->services['pimcore.twig.extension.helpers'] = new \Pimcore\Twig\Extension\HelpersExtension();
    }

    /*
     * Gets the public 'pimcore.twig.extension.navigation' shared autowired service.
     *
     * @return \Pimcore\Twig\Extension\NavigationExtension
     */
    protected function getPimcore_Twig_Extension_NavigationService()
    {
        return $this->services['pimcore.twig.extension.navigation'] = new \Pimcore\Twig\Extension\NavigationExtension(($this->services['pimcore.templating.view_helper.navigation'] ?? $this->getPimcore_Templating_ViewHelper_NavigationService()));
    }

    /*
     * Gets the public 'pimcore.twig.extension.pimcore_object' shared autowired service.
     *
     * @return \Pimcore\Twig\Extension\PimcoreObjectExtension
     */
    protected function getPimcore_Twig_Extension_PimcoreObjectService()
    {
        return $this->services['pimcore.twig.extension.pimcore_object'] = new \Pimcore\Twig\Extension\PimcoreObjectExtension();
    }

    /*
     * Gets the public 'pimcore.twig.extension.subrequest' shared autowired service.
     *
     * @return \Pimcore\Twig\Extension\SubrequestExtension
     */
    protected function getPimcore_Twig_Extension_SubrequestService($lazyLoad = true)
    {
        if ($lazyLoad) {
            return $this->services['pimcore.twig.extension.subrequest'] = $this->createProxy('SubrequestExtension_ac4dffd', function () {
                return \SubrequestExtension_ac4dffd::staticProxyConstructor(function (&$wrappedInstance, \ProxyManager\Proxy\LazyLoadingInterface $proxy) {
                    $wrappedInstance = $this->getPimcore_Twig_Extension_SubrequestService(false);

                    $proxy->setProxyInitializer(null);

                    return true;
                });
            });
        }

        return new \Pimcore\Twig\Extension\SubrequestExtension(($this->services['pimcore.templating.view_helper.inc'] ?? $this->getPimcore_Templating_ViewHelper_IncService()), ($this->services['pimcore.templating.view_helper.action'] ?? $this->getPimcore_Templating_ViewHelper_ActionService()));
    }

    /*
     * Gets the public 'pimcore.twig.extension.templating_helper' shared autowired service.
     *
     * @return \Pimcore\Twig\Extension\TemplatingHelperExtension
     */
    protected function getPimcore_Twig_Extension_TemplatingHelperService()
    {
        return $this->services['pimcore.twig.extension.templating_helper'] = new \Pimcore\Twig\Extension\TemplatingHelperExtension(($this->services['pimcore.templating.engine.php'] ?? $this->load('getPimcore_Templating_Engine_PhpService.php')));
    }

    /*
     * Gets the public 'pimcore_admin.security.bruteforce_protection_handler' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\Security\BruteforceProtectionHandler
     */
    protected function getPimcoreAdmin_Security_BruteforceProtectionHandlerService()
    {
        $this->services['pimcore_admin.security.bruteforce_protection_handler'] = $instance = new \Pimcore\Bundle\AdminBundle\Security\BruteforceProtectionHandler(($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()));

        $a = ($this->services['monolog.logger.security'] ?? $this->getMonolog_Logger_SecurityService());

        $instance->setLogger($a);
        $instance->setLogger($a);

        return $instance;
    }

    /*
     * Gets the public 'pimcore_admin.security.user_loader' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\Security\User\UserLoader
     */
    protected function getPimcoreAdmin_Security_UserLoaderService()
    {
        return $this->services['pimcore_admin.security.user_loader'] = new \Pimcore\Bundle\AdminBundle\Security\User\UserLoader(($this->services['Pimcore\\Bundle\\AdminBundle\\Security\\User\\TokenStorageUserResolver'] ?? $this->getTokenStorageUserResolverService()), ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()));
    }

    /*
     * Gets the public 'request_stack' shared service.
     *
     * @return \Symfony\Component\HttpFoundation\RequestStack
     */
    protected function getRequestStackService()
    {
        return $this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack();
    }

    /*
     * Gets the public 'router' shared service.
     *
     * @return \Symfony\Cmf\Component\Routing\ChainRouter
     */
    protected function getRouterService()
    {
        $a = ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService());

        $this->services['router'] = $instance = new \Symfony\Cmf\Component\Routing\ChainRouter($a);

        $b = ($this->services['pimcore.routing.router.request_context'] ?? $this->getPimcore_Routing_Router_RequestContextService());
        $c = new \Symfony\Bundle\FrameworkBundle\Routing\Router((new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'routing.loader' => ['services', 'routing.loader', 'getRouting_LoaderService.php', true],
        ], [
            'routing.loader' => 'Symfony\\Component\\Config\\Loader\\LoaderInterface',
        ]))->withContext('router.default', $this), ($this->targetDirs[3].'/app/config/routing.yml'), ['cache_dir' => $this->targetDirs[0], 'debug' => false, 'generator_class' => 'Symfony\\Component\\Routing\\Generator\\CompiledUrlGenerator', 'generator_dumper_class' => 'Symfony\\Component\\Routing\\Generator\\Dumper\\CompiledUrlGeneratorDumper', 'matcher_class' => 'Symfony\\Bundle\\FrameworkBundle\\Routing\\RedirectableCompiledUrlMatcher', 'matcher_dumper_class' => 'Symfony\\Component\\Routing\\Matcher\\Dumper\\CompiledUrlMatcherDumper', 'strict_requirements' => NULL], $b, new \Symfony\Component\DependencyInjection\ParameterBag\ContainerBag($this), ($this->services['monolog.logger.router'] ?? $this->getMonolog_Logger_RouterService()), 'en');
        $c->setConfigCacheFactory(($this->privates['config_cache_factory'] ?? ($this->privates['config_cache_factory'] = new \Symfony\Component\Config\ResourceCheckerConfigCacheFactory())));
        $d = ($this->services['cmf_routing.route_provider'] ?? $this->getCmfRouting_RouteProviderService());

        $e = new \Symfony\Cmf\Bundle\RoutingBundle\Routing\DynamicRouter($b, new \Symfony\Cmf\Component\Routing\NestedMatcher\NestedMatcher($d, new \Symfony\Cmf\Component\Routing\NestedMatcher\UrlMatcher(new \Symfony\Component\Routing\RouteCollection(), new \Symfony\Component\Routing\RequestContext())), new \Symfony\Cmf\Component\Routing\ContentAwareGenerator($d, $a), '', ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), $d);
        $e->setRequestStack(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
        $e->addRouteEnhancer(new \Symfony\Cmf\Component\Routing\Enhancer\RouteContentEnhancer('_route_object', '_content'), 100);
        $f = new \Pimcore\Routing\Staticroute\Router($b, ($this->services['pimcore.controller.config.config_normalizer'] ?? $this->getPimcore_Controller_Config_ConfigNormalizerService()));

        $g = ($this->services['monolog.logger.routing'] ?? $this->getMonolog_Logger_RoutingService());

        $f->setLogger($g);
        $f->setLocaleParams([]);
        $f->setLogger($g);

        $instance->setContext($b);
        $instance->add($c, '300');
        $instance->add($e, '200');
        $instance->add($f, 100);

        return $instance;
    }

    /*
     * Gets the public 'security.authorization_checker' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\AuthorizationChecker
     */
    protected function getSecurity_AuthorizationCheckerService()
    {
        return $this->services['security.authorization_checker'] = new \Symfony\Component\Security\Core\Authorization\AuthorizationChecker(($this->services['security.token_storage'] ?? ($this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())), ($this->privates['security.authentication.manager'] ?? $this->getSecurity_Authentication_ManagerService()), ($this->privates['security.access.decision_manager'] ?? $this->getSecurity_Access_DecisionManagerService()), false);
    }

    /*
     * Gets the public 'security.token_storage' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage
     */
    protected function getSecurity_TokenStorageService()
    {
        return $this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage();
    }

    /*
     * Gets the public 'sensio_framework_extra.view.guesser' shared service.
     *
     * @return \Pimcore\Bundle\CoreBundle\Templating\LegacyTemplateGuesser
     */
    protected function getSensioFrameworkExtra_View_GuesserService()
    {
        return $this->services['sensio_framework_extra.view.guesser'] = new \Pimcore\Bundle\CoreBundle\Templating\LegacyTemplateGuesser(($this->services['kernel'] ?? $this->get('kernel', 1)), ($this->services['templating'] ?? $this->load('getTemplatingService.php')));
    }

    /*
     * Gets the public 'twig' shared service.
     *
     * @return \Twig\Environment
     */
    protected function getTwigService()
    {
        $a = new \Symfony\Bundle\TwigBundle\Loader\FilesystemLoader(($this->privates['templating.locator'] ?? $this->load('getTemplating_LocatorService.php')), ($this->privates['templating.name_parser'] ?? $this->load('getTemplating_NameParserService.php')), $this->targetDirs[3]);
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views'), 'Framework');
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/views'), '!Framework');
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/SecurityBundle/Resources/views'), 'Security');
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/SecurityBundle/Resources/views'), '!Security');
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views'), 'Twig');
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views'), '!Twig');
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/swiftmailer-bundle/Resources/views'), 'Swiftmailer');
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/swiftmailer-bundle/Resources/views'), '!Swiftmailer');
        $a->addPath(($this->targetDirs[3].'/vendor/doctrine/doctrine-bundle/Resources/views'), 'Doctrine');
        $a->addPath(($this->targetDirs[3].'/vendor/doctrine/doctrine-bundle/Resources/views'), '!Doctrine');
        $a->addPath(($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/views'), 'SchebTwoFactor');
        $a->addPath(($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/views'), '!SchebTwoFactor');
        $a->addPath(($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/views'), 'PimcoreCore');
        $a->addPath(($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/views'), '!PimcoreCore');
        $a->addPath(($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/AdminBundle/Resources/views'), 'PimcoreAdmin');
        $a->addPath(($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/AdminBundle/Resources/views'), '!PimcoreAdmin');
        $a->addPath(($this->targetDirs[3].'/app/Resources/views'));
        $a->addPath(($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bridge/Twig/Resources/views/Form'));

        $this->services['twig'] = $instance = new \Twig\Environment($a, ['debug' => false, 'strict_variables' => false, 'exception_controller' => 'twig.controller.exception::showAction', 'form_themes' => $this->parameters['twig.form.resources'], 'autoescape' => 'name', 'cache' => ($this->targetDirs[0].'/twig'), 'charset' => 'UTF-8', 'default_path' => ($this->targetDirs[3].'/templates'), 'paths' => [], 'date' => ['format' => 'F j, Y H:i', 'interval_format' => '%d days', 'timezone' => NULL], 'number_format' => ['decimals' => 0, 'decimal_point' => '.', 'thousands_separator' => ',']]);

        $b = ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack()));
        $c = new \Symfony\Bridge\Twig\AppVariable();
        $c->setEnvironment('prod');
        $c->setDebug(false);
        if ($this->has('security.token_storage')) {
            $c->setTokenStorage(($this->services['security.token_storage'] ?? ($this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())));
        }
        if ($this->has('request_stack')) {
            $c->setRequestStack($b);
        }

        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\CsrfExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\LogoutUrlExtension(($this->privates['security.logout_url_generator'] ?? $this->getSecurity_LogoutUrlGeneratorService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\SecurityExtension(($this->services['security.authorization_checker'] ?? $this->getSecurity_AuthorizationCheckerService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\TranslationExtension(($this->services['Symfony\\Contracts\\Translation\\TranslatorInterface'] ?? $this->getTranslatorInterfaceService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\AssetExtension(($this->privates['assets.packages'] ?? $this->getAssets_PackagesService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\CodeExtension(($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))), $this->targetDirs[3], 'UTF-8'));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\RoutingExtension(($this->services['router'] ?? $this->getRouterService())));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\YamlExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\StopwatchExtension(($this->privates['debug.stopwatch'] ?? ($this->privates['debug.stopwatch'] = new \Symfony\Component\Stopwatch\Stopwatch(true))), false));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\ExpressionExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\HttpKernelExtension());
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\HttpFoundationExtension(new \Symfony\Component\HttpFoundation\UrlHelper($b, ($this->services['pimcore.routing.router.request_context'] ?? $this->getPimcore_Routing_Router_RequestContextService()))));
        $instance->addExtension(($this->services['Symfony\\Bridge\\Twig\\Extension\\WebLinkExtension'] ?? $this->getWebLinkExtensionService()));
        $instance->addExtension(new \Symfony\Bridge\Twig\Extension\FormExtension([0 => $this, 1 => 'twig.form.renderer']));
        $instance->addExtension(new \Doctrine\Bundle\DoctrineBundle\Twig\DoctrineExtension());
        $instance->addExtension(($this->services['pimcore.twig.extension.helpers'] ?? ($this->services['pimcore.twig.extension.helpers'] = new \Pimcore\Twig\Extension\HelpersExtension())));
        $instance->addExtension(($this->services['pimcore.twig.extension.document_tag'] ?? $this->getPimcore_Twig_Extension_DocumentTagService()));
        $instance->addExtension(($this->services['pimcore.twig.extension.subrequest'] ?? $this->getPimcore_Twig_Extension_SubrequestService()));
        $instance->addExtension(($this->services['pimcore.twig.extension.pimcore_object'] ?? ($this->services['pimcore.twig.extension.pimcore_object'] = new \Pimcore\Twig\Extension\PimcoreObjectExtension())));
        $instance->addExtension(($this->services['pimcore.twig.extension.templating_helper'] ?? $this->getPimcore_Twig_Extension_TemplatingHelperService()));
        $instance->addExtension(($this->services['pimcore.twig.extension.navigation'] ?? $this->getPimcore_Twig_Extension_NavigationService()));
        $instance->addExtension(($this->services['pimcore.twig.extension.glossary'] ?? $this->getPimcore_Twig_Extension_GlossaryService()));
        $instance->addExtension(new \Pimcore\Twig\Extension\AssetCompressExtension());
        $instance->addExtension(new \Pimcore\Twig\Extension\WebsiteConfigExtension());
        $instance->addExtension(new \Pimcore\Twig\Extension\DumpExtension());
        $instance->addExtension(new \Phive\Twig\Extensions\Deferred\DeferredExtension());
        $instance->addExtension(new \Twig_Extensions_Extension_Text());
        $instance->addGlobal('app', $c);
        $instance->addRuntimeLoader(new \Twig\RuntimeLoader\ContainerRuntimeLoader(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'Symfony\\Bridge\\Twig\\Extension\\CsrfRuntime' => ['privates', 'twig.runtime.security_csrf', 'getTwig_Runtime_SecurityCsrfService.php', true],
            'Symfony\\Bridge\\Twig\\Extension\\HttpKernelRuntime' => ['privates', 'twig.runtime.httpkernel', 'getTwig_Runtime_HttpkernelService.php', true],
            'Symfony\\Component\\Form\\FormRenderer' => ['privates', 'twig.form.renderer', 'getTwig_Form_RendererService.php', true],
        ], [
            'Symfony\\Bridge\\Twig\\Extension\\CsrfRuntime' => '?',
            'Symfony\\Bridge\\Twig\\Extension\\HttpKernelRuntime' => '?',
            'Symfony\\Component\\Form\\FormRenderer' => '?',
        ])));
        $instance->addGlobal('container', $this);
        (new \Symfony\Bundle\TwigBundle\DependencyInjection\Configurator\EnvironmentConfigurator('F j, Y H:i', '%d days', NULL, 0, '.', ','))->configure($instance);

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Analytics\Google\Tracker' shared autowired service.
     *
     * @return \Pimcore\Analytics\Google\Tracker
     */
    protected function getTrackerService()
    {
        $this->privates['Pimcore\\Analytics\\Google\\Tracker'] = $instance = new \Pimcore\Analytics\Google\Tracker(($this->privates['Pimcore\\Analytics\\SiteId\\SiteIdProvider'] ?? $this->getSiteIdProviderService()), ($this->privates['Pimcore\\Analytics\\Google\\Config\\ConfigProvider'] ?? ($this->privates['Pimcore\\Analytics\\Google\\Config\\ConfigProvider'] = new \Pimcore\Analytics\Google\Config\ConfigProvider())), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->services['templating'] ?? $this->load('getTemplatingService.php')));

        $instance->setLogger(($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Analytics\Piwik\Config\ConfigProvider' shared autowired service.
     *
     * @return \Pimcore\Analytics\Piwik\Config\ConfigProvider
     */
    protected function getConfigProviderService()
    {
        return $this->privates['Pimcore\\Analytics\\Piwik\\Config\\ConfigProvider'] = new \Pimcore\Analytics\Piwik\Config\ConfigProvider();
    }

    /*
     * Gets the private 'Pimcore\Analytics\Piwik\EventListener\TrackingCodeListener' shared autowired service.
     *
     * @return \Pimcore\Analytics\Piwik\EventListener\TrackingCodeListener
     */
    protected function getTrackingCodeListenerService()
    {
        $this->privates['Pimcore\\Analytics\\Piwik\\EventListener\\TrackingCodeListener'] = $instance = new \Pimcore\Analytics\Piwik\EventListener\TrackingCodeListener(new \Pimcore\Analytics\Piwik\Tracker(($this->privates['Pimcore\\Analytics\\SiteId\\SiteIdProvider'] ?? $this->getSiteIdProviderService()), ($this->privates['Pimcore\\Analytics\\Piwik\\Config\\ConfigProvider'] ?? ($this->privates['Pimcore\\Analytics\\Piwik\\Config\\ConfigProvider'] = new \Pimcore\Analytics\Piwik\Config\ConfigProvider())), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->services['templating'] ?? $this->load('getTemplatingService.php'))));

        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Analytics\SiteId\SiteIdProvider' shared autowired service.
     *
     * @return \Pimcore\Analytics\SiteId\SiteIdProvider
     */
    protected function getSiteIdProviderService()
    {
        return $this->privates['Pimcore\\Analytics\\SiteId\\SiteIdProvider'] = new \Pimcore\Analytics\SiteId\SiteIdProvider(($this->services['Pimcore\\Http\\Request\\Resolver\\SiteResolver'] ?? $this->getSiteResolverService()));
    }

    /*
     * Gets the private 'Pimcore\Bundle\AdminBundle\EventListener\AdminAuthenticationDoubleCheckListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\AdminAuthenticationDoubleCheckListener
     */
    protected function getAdminAuthenticationDoubleCheckListenerService()
    {
        return $this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\AdminAuthenticationDoubleCheckListener'] = new \Pimcore\Bundle\AdminBundle\EventListener\AdminAuthenticationDoubleCheckListener(($this->services['pimcore.service.request_matcher_factory'] ?? ($this->services['pimcore.service.request_matcher_factory'] = new \Pimcore\Http\RequestMatcherFactory())), ($this->services['Pimcore\\Bundle\\AdminBundle\\Security\\User\\TokenStorageUserResolver'] ?? $this->getTokenStorageUserResolverService()), $this->parameters['pimcore.admin.unauthenticated_routes']);
    }

    /*
     * Gets the private 'Pimcore\Bundle\AdminBundle\EventListener\BruteforceProtectionListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\BruteforceProtectionListener
     */
    protected function getBruteforceProtectionListenerService()
    {
        $this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\BruteforceProtectionListener'] = $instance = new \Pimcore\Bundle\AdminBundle\EventListener\BruteforceProtectionListener(($this->services['pimcore_admin.security.bruteforce_protection_handler'] ?? $this->getPimcoreAdmin_Security_BruteforceProtectionHandlerService()));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\AdminBundle\EventListener\CustomAdminEntryPointCheckListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\CustomAdminEntryPointCheckListener
     */
    protected function getCustomAdminEntryPointCheckListenerService()
    {
        $this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\CustomAdminEntryPointCheckListener'] = $instance = new \Pimcore\Bundle\AdminBundle\EventListener\CustomAdminEntryPointCheckListener(NULL);

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\AdminBundle\EventListener\EnablePreviewTimeSliderListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\EnablePreviewTimeSliderListener
     */
    protected function getEnablePreviewTimeSliderListenerService()
    {
        $this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\EnablePreviewTimeSliderListener'] = $instance = new \Pimcore\Bundle\AdminBundle\EventListener\EnablePreviewTimeSliderListener(($this->services['Pimcore\\Http\\Request\\Resolver\\OutputTimestampResolver'] ?? $this->getOutputTimestampResolverService()), ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] ?? $this->getEditmodeResolverService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService()));

        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\AdminBundle\EventListener\HttpCacheListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\HttpCacheListener
     */
    protected function getHttpCacheListenerService()
    {
        $this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\HttpCacheListener'] = $instance = new \Pimcore\Bundle\AdminBundle\EventListener\HttpCacheListener(($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()), ($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\AdminBundle\EventListener\UsageStatisticsListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\UsageStatisticsListener
     */
    protected function getUsageStatisticsListenerService()
    {
        $this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\UsageStatisticsListener'] = $instance = new \Pimcore\Bundle\AdminBundle\EventListener\UsageStatisticsListener(($this->services['Pimcore\\Bundle\\AdminBundle\\Security\\User\\TokenStorageUserResolver'] ?? $this->getTokenStorageUserResolverService()));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\AdminBundle\EventListener\UserPerspectiveListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\AdminBundle\EventListener\UserPerspectiveListener
     */
    protected function getUserPerspectiveListenerService()
    {
        $this->privates['Pimcore\\Bundle\\AdminBundle\\EventListener\\UserPerspectiveListener'] = $instance = new \Pimcore\Bundle\AdminBundle\EventListener\UserPerspectiveListener(($this->services['Pimcore\\Bundle\\AdminBundle\\Security\\User\\TokenStorageUserResolver'] ?? $this->getTokenStorageUserResolverService()));

        $a = ($this->services['monolog.logger.admin'] ?? $this->getMonolog_Logger_AdminService());

        $instance->setLogger($a);
        $instance->setLogger($a);
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\BlockStateListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\BlockStateListener
     */
    protected function getBlockStateListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\BlockStateListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\BlockStateListener(($this->services['pimcore.document.tag.block_state_stack'] ?? ($this->services['pimcore.document.tag.block_state_stack'] = new \Pimcore\Document\Tag\Block\BlockStateStack())));

        $a = ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService());

        $instance->setLogger($a);
        $instance->setLogger($a);
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentFallbackListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentFallbackListener
     */
    protected function getDocumentFallbackListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\DocumentFallbackListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentFallbackListener(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\SiteResolver'] ?? $this->getSiteResolverService()), ($this->services['Pimcore\\Model\\Document\\Service'] ?? ($this->services['Pimcore\\Model\\Document\\Service'] = new \Pimcore\Model\Document\Service())));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentMetaDataListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentMetaDataListener
     */
    protected function getDocumentMetaDataListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\DocumentMetaDataListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentMetaDataListener(($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService()), ($this->services['pimcore.templating.view_helper.head_meta'] ?? $this->getPimcore_Templating_ViewHelper_HeadMetaService()));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentStackListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentStackListener
     */
    protected function getDocumentStackListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\DocumentStackListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\DocumentStackListener(($this->services['Pimcore\\Document\\DocumentStack'] ?? ($this->services['Pimcore\\Document\\DocumentStack'] = new \Pimcore\Document\DocumentStack())));

        $instance->setLogger(($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\EditmodeListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\EditmodeListener
     */
    protected function getEditmodeListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\EditmodeListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\EditmodeListener(($this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] ?? $this->getEditmodeResolverService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService()), ($this->services['pimcore_admin.security.user_loader'] ?? $this->getPimcoreAdmin_Security_UserLoaderService()), ($this->services['Pimcore\\Extension\\Bundle\\PimcoreBundleManager'] ?? $this->getPimcoreBundleManagerService()));

        $instance->setLogger(($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\ElementListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\ElementListener
     */
    protected function getElementListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\ElementListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\ElementListener(($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService()), ($this->services['Pimcore\\Http\\Request\\Resolver\\EditmodeResolver'] ?? $this->getEditmodeResolverService()), ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()), ($this->services['pimcore_admin.security.user_loader'] ?? $this->getPimcoreAdmin_Security_UserLoaderService()), ($this->services['Pimcore\\Targeting\\Document\\DocumentTargetingConfigurator'] ?? $this->getDocumentTargetingConfiguratorService()));

        $a = ($this->services['monolog.logger.init'] ?? $this->getMonolog_Logger_InitService());

        $instance->setLogger($a);
        $instance->setLogger($a);
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\FrontendRoutingListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\FrontendRoutingListener
     */
    protected function getFrontendRoutingListenerService()
    {
        $a = ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService());
        $b = new \Pimcore\Routing\RedirectHandler();

        $c = ($this->services['monolog.logger.routing'] ?? $this->getMonolog_Logger_RoutingService());
        $d = ($this->services['Pimcore\\Http\\Request\\Resolver\\SiteResolver'] ?? $this->getSiteResolverService());

        $b->setLogger($c);
        $b->setLogger($c);
        $b->setRequestHelper($a);
        $b->setSiteResolver($d);

        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\FrontendRoutingListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\FrontendRoutingListener($a, $b, $d);

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleSearchConsoleVerificationListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleSearchConsoleVerificationListener
     */
    protected function getGoogleSearchConsoleVerificationListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\GoogleSearchConsoleVerificationListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\GoogleSearchConsoleVerificationListener();

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\HardlinkCanonicalListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\HardlinkCanonicalListener
     */
    protected function getHardlinkCanonicalListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\HardlinkCanonicalListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\HardlinkCanonicalListener(($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService()));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\InternalWysiwygHtmlAttributeFilterListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\InternalWysiwygHtmlAttributeFilterListener
     */
    protected function getInternalWysiwygHtmlAttributeFilterListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\InternalWysiwygHtmlAttributeFilterListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\InternalWysiwygHtmlAttributeFilterListener();

        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));
        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\LocaleListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\LocaleListener
     */
    protected function getLocaleListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\LocaleListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\LocaleListener();

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\Frontend\OutputTimestampListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\Frontend\OutputTimestampListener
     */
    protected function getOutputTimestampListenerService()
    {
        return $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\Frontend\\OutputTimestampListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\Frontend\OutputTimestampListener(($this->services['Pimcore\\Http\\Request\\Resolver\\OutputTimestampResolver'] ?? $this->getOutputTimestampResolverService()));
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\MaintenancePageListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\MaintenancePageListener
     */
    protected function getMaintenancePageListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\MaintenancePageListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\MaintenancePageListener(($this->services['kernel'] ?? $this->get('kernel', 1)));

        $instance->loadTemplateFromResource('@PimcoreCoreBundle/Resources/misc/maintenance.html');
        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\PimcoreContextListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\PimcoreContextListener
     */
    protected function getPimcoreContextListenerService()
    {
        $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\PimcoreContextListener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\PimcoreContextListener(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));

        $a = ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService());

        $instance->setLogger($a);
        $instance->setLogger($a);

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\ResponseHeaderListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\ResponseHeaderListener
     */
    protected function getResponseHeaderListenerService()
    {
        return $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ResponseHeaderListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\ResponseHeaderListener(($this->services['Pimcore\\Http\\Request\\Resolver\\ResponseHeaderResolver'] ?? $this->getResponseHeaderResolverService()));
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\ResponseStackListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\ResponseStackListener
     */
    protected function getResponseStackListenerService()
    {
        return $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\ResponseStackListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\ResponseStackListener(($this->privates['Pimcore\\Http\\ResponseStack'] ?? ($this->privates['Pimcore\\Http\\ResponseStack'] = new \Pimcore\Http\ResponseStack())));
    }

    /*
     * Gets the private 'Pimcore\Bundle\CoreBundle\EventListener\TranslationDebugListener' shared autowired service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\TranslationDebugListener
     */
    protected function getTranslationDebugListenerService()
    {
        return $this->privates['Pimcore\\Bundle\\CoreBundle\\EventListener\\TranslationDebugListener'] = new \Pimcore\Bundle\CoreBundle\EventListener\TranslationDebugListener(($this->services['Symfony\\Contracts\\Translation\\TranslatorInterface'] ?? $this->getTranslatorInterfaceService()), 'pimcore_debug_translations');
    }

    /*
     * Gets the private 'Pimcore\Http\Response\CodeInjector' shared autowired service.
     *
     * @return \Pimcore\Http\Response\CodeInjector
     */
    protected function getCodeInjectorService()
    {
        return $this->privates['Pimcore\\Http\\Response\\CodeInjector'] = new \Pimcore\Http\Response\CodeInjector(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));
    }

    /*
     * Gets the private 'Pimcore\Routing\Dynamic\DocumentRouteHandler' shared autowired service.
     *
     * @return \Pimcore\Routing\Dynamic\DocumentRouteHandler
     */
    protected function getDocumentRouteHandlerService()
    {
        return $this->privates['Pimcore\\Routing\\Dynamic\\DocumentRouteHandler'] = new \Pimcore\Routing\Dynamic\DocumentRouteHandler(($this->services['Pimcore\\Model\\Document\\Service'] ?? ($this->services['Pimcore\\Model\\Document\\Service'] = new \Pimcore\Model\Document\Service())), ($this->services['Pimcore\\Http\\Request\\Resolver\\SiteResolver'] ?? $this->getSiteResolverService()), ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()), ($this->services['pimcore.controller.config.config_normalizer'] ?? $this->getPimcore_Controller_Config_ConfigNormalizerService()));
    }

    /*
     * Gets the private 'Pimcore\Targeting\ActionHandler\DelegatingActionHandler' shared autowired service.
     *
     * @return \Pimcore\Targeting\ActionHandler\DelegatingActionHandler
     */
    protected function getDelegatingActionHandlerService()
    {
        return $this->privates['Pimcore\\Targeting\\ActionHandler\\DelegatingActionHandler'] = new \Pimcore\Targeting\ActionHandler\DelegatingActionHandler(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'assign_target_group' => ['privates', 'Pimcore\\Targeting\\ActionHandler\\AssignTargetGroup', 'getAssignTargetGroupService.php', true],
            'codesnippet' => ['privates', 'Pimcore\\Targeting\\ActionHandler\\CodeSnippet', 'getCodeSnippetService.php', true],
            'redirect' => ['privates', 'Pimcore\\Targeting\\ActionHandler\\Redirect', 'getRedirectService.php', true],
        ], [
            'assign_target_group' => '?',
            'codesnippet' => '?',
            'redirect' => '?',
        ]), ($this->privates['Pimcore\\Targeting\\DataLoader'] ?? $this->getDataLoaderService()));
    }

    /*
     * Gets the private 'Pimcore\Targeting\ConditionMatcher' shared autowired service.
     *
     * @return \Pimcore\Targeting\ConditionMatcher
     */
    protected function getConditionMatcherService()
    {
        $a = ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService());

        return $this->privates['Pimcore\\Targeting\\ConditionMatcher'] = new \Pimcore\Targeting\ConditionMatcher(new \Pimcore\Targeting\ConditionFactory($a, $this->parameters['pimcore.targeting.conditions']), ($this->privates['Pimcore\\Targeting\\DataLoader'] ?? $this->getDataLoaderService()), $a, new \Symfony\Component\ExpressionLanguage\ExpressionLanguage(($this->services['pimcore.cache.core.pool'] ?? $this->getPimcore_Cache_Core_PoolService())), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'Pimcore\Targeting\DataLoader' shared autowired service.
     *
     * @return \Pimcore\Targeting\DataLoader
     */
    protected function getDataLoaderService()
    {
        return $this->privates['Pimcore\\Targeting\\DataLoader'] = new \Pimcore\Targeting\DataLoader(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'device' => ['privates', 'Pimcore\\Targeting\\DataProvider\\Device', 'getDeviceService.php', true],
            'geoip' => ['privates', 'Pimcore\\Targeting\\DataProvider\\GeoIp', 'getGeoIpService.php', true],
            'geolocation' => ['privates', 'Pimcore\\Targeting\\DataProvider\\GeoLocation', 'getGeoLocationService.php', true],
            'piwik' => ['privates', 'Pimcore\\Targeting\\DataProvider\\Piwik', 'getPiwikService.php', true],
            'targeting_storage' => ['privates', 'Pimcore\\Targeting\\DataProvider\\TargetingStorage', 'getTargetingStorageService.php', true],
            'visited_pages_counter' => ['privates', 'Pimcore\\Targeting\\DataProvider\\VisitedPagesCounter', 'getVisitedPagesCounterService.php', true],
        ], [
            'device' => '?',
            'geoip' => '?',
            'geolocation' => '?',
            'piwik' => '?',
            'targeting_storage' => '?',
            'visited_pages_counter' => '?',
        ]));
    }

    /*
     * Gets the private 'Pimcore\Targeting\Debug\OverrideHandler' shared autowired service.
     *
     * @return \Pimcore\Targeting\Debug\OverrideHandler
     */
    protected function getOverrideHandlerService($lazyLoad = true)
    {
        if ($lazyLoad) {
            return $this->privates['Pimcore\\Targeting\\Debug\\OverrideHandler'] = $this->createProxy('OverrideHandler_fb58919', function () {
                return \OverrideHandler_fb58919::staticProxyConstructor(function (&$wrappedInstance, \ProxyManager\Proxy\LazyLoadingInterface $proxy) {
                    $wrappedInstance = $this->getOverrideHandlerService(false);

                    $proxy->setProxyInitializer(null);

                    return true;
                });
            });
        }

        return new \Pimcore\Targeting\Debug\OverrideHandler(($this->services['form.factory'] ?? $this->getForm_FactoryService()), [0 => new \Pimcore\Targeting\Debug\Override\DocumentTargetingOverrideHandler(($this->services['Pimcore\\Targeting\\Document\\DocumentTargetingConfigurator'] ?? $this->getDocumentTargetingConfiguratorService())), 1 => new \Pimcore\Targeting\Debug\Override\LanguageOverrideHandler(), 2 => new \Pimcore\Targeting\Debug\Override\DeviceOverrideHandler(), 3 => new \Pimcore\Targeting\Debug\Override\LocationOverrideHandler()]);
    }

    /*
     * Gets the private 'Pimcore\Targeting\EventListener\TargetingListener' shared autowired service.
     *
     * @return \Pimcore\Targeting\EventListener\TargetingListener
     */
    protected function getTargetingListenerService()
    {
        $a = ($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] ?? ($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] = new \Pimcore\Targeting\VisitorInfoStorage()));
        $b = ($this->privates['Pimcore\\Targeting\\ActionHandler\\DelegatingActionHandler'] ?? $this->getDelegatingActionHandlerService());
        $c = ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService());

        $this->privates['Pimcore\\Targeting\\EventListener\\TargetingListener'] = $instance = new \Pimcore\Targeting\EventListener\TargetingListener(new \Pimcore\Targeting\VisitorInfoResolver(($this->privates['Pimcore\\Targeting\\Storage\\CookieStorage'] ?? $this->getCookieStorageService()), $a, ($this->privates['Pimcore\\Targeting\\ConditionMatcher'] ?? $this->getConditionMatcherService()), $b, ($this->services['doctrine.dbal.default_connection'] ?? $this->getDoctrine_Dbal_DefaultConnectionService()), $c), $b, $a, ($this->services['Pimcore\\Http\\RequestHelper'] ?? $this->getRequestHelperService()), new \Pimcore\Targeting\Code\TargetingCodeGenerator($c, ($this->services['templating'] ?? $this->load('getTemplatingService.php'))));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));
        $instance->setResponseHelper(($this->services['Pimcore\\Http\\ResponseHelper'] ?? ($this->services['Pimcore\\Http\\ResponseHelper'] = new \Pimcore\Http\ResponseHelper())));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Targeting\EventListener\ToolbarListener' shared autowired service.
     *
     * @return \Pimcore\Targeting\EventListener\ToolbarListener
     */
    protected function getToolbarListenerService()
    {
        $this->privates['Pimcore\\Targeting\\EventListener\\ToolbarListener'] = $instance = new \Pimcore\Targeting\EventListener\ToolbarListener(($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] ?? ($this->privates['Pimcore\\Targeting\\VisitorInfoStorage'] = new \Pimcore\Targeting\VisitorInfoStorage())), ($this->services['Pimcore\\Http\\Request\\Resolver\\DocumentResolver'] ?? $this->getDocumentResolverService()), new \Pimcore\Targeting\Debug\TargetingDataCollector(($this->privates['Pimcore\\Targeting\\Storage\\CookieStorage'] ?? $this->getCookieStorageService()), ($this->services['Pimcore\\Targeting\\Document\\DocumentTargetingConfigurator'] ?? $this->getDocumentTargetingConfiguratorService())), ($this->privates['Pimcore\\Targeting\\Debug\\OverrideHandler'] ?? $this->getOverrideHandlerService()), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->services['templating'] ?? $this->load('getTemplatingService.php')), ($this->privates['Pimcore\\Http\\Response\\CodeInjector'] ?? $this->getCodeInjectorService()));

        $instance->setPimcoreContextResolver(($this->services['Pimcore\\Http\\Request\\Resolver\\PimcoreContextResolver'] ?? $this->getPimcoreContextResolverService()));

        return $instance;
    }

    /*
     * Gets the private 'Pimcore\Targeting\Storage\CookieStorage' shared autowired service.
     *
     * @return \Pimcore\Targeting\Storage\CookieStorage
     */
    protected function getCookieStorageService()
    {
        return $this->privates['Pimcore\\Targeting\\Storage\\CookieStorage'] = new \Pimcore\Targeting\Storage\CookieStorage(new \Pimcore\Targeting\Storage\Cookie\JWTCookieSaveHandler('F0dx6arBNiDt7tdqSDgr0MlyYSe/hzML', [], NULL, ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService())), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));
    }

    /*
     * Gets the private 'annotations.cached_reader' shared service.
     *
     * @return \Doctrine\Common\Annotations\CachedReader
     */
    protected function getAnnotations_CachedReaderService()
    {
        return $this->privates['annotations.cached_reader'] = new \Doctrine\Common\Annotations\CachedReader(($this->privates['annotations.reader'] ?? $this->getAnnotations_ReaderService()), $this->load('getAnnotations_CacheService.php'), false);
    }

    /*
     * Gets the private 'annotations.reader' shared service.
     *
     * @return \Doctrine\Common\Annotations\AnnotationReader
     */
    protected function getAnnotations_ReaderService()
    {
        $this->privates['annotations.reader'] = $instance = new \Doctrine\Common\Annotations\AnnotationReader();

        $a = new \Doctrine\Common\Annotations\AnnotationRegistry();
        $a->registerUniqueLoader('class_exists');

        $instance->addGlobalIgnoredName('required', $a);

        return $instance;
    }

    /*
     * Gets the private 'assets.packages' shared service.
     *
     * @return \Symfony\Component\Asset\Packages
     */
    protected function getAssets_PackagesService()
    {
        return $this->privates['assets.packages'] = new \Symfony\Component\Asset\Packages(new \Symfony\Component\Asset\PathPackage('', new \Symfony\Component\Asset\VersionStrategy\EmptyVersionStrategy(), new \Symfony\Component\Asset\Context\RequestStackContext(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), '', false)), []);
    }

    /*
     * Gets the private 'controller_resolver' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Controller\ControllerResolver
     */
    protected function getControllerResolverService()
    {
        return $this->privates['controller_resolver'] = new \Symfony\Bundle\FrameworkBundle\Controller\ControllerResolver($this, ($this->privates['controller_name_converter'] ?? ($this->privates['controller_name_converter'] = new \Symfony\Bundle\FrameworkBundle\Controller\ControllerNameParser(($this->services['kernel'] ?? $this->get('kernel', 1))))), ($this->services['monolog.logger.request'] ?? $this->getMonolog_Logger_RequestService()));
    }

    /*
     * Gets the private 'debug.debug_handlers_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\DebugHandlersListener
     */
    protected function getDebug_DebugHandlersListenerService()
    {
        return $this->privates['debug.debug_handlers_listener'] = new \Symfony\Component\HttpKernel\EventListener\DebugHandlersListener(NULL, ($this->services['monolog.logger.php'] ?? $this->getMonolog_Logger_PhpService()), NULL, 0, false, ($this->privates['debug.file_link_formatter'] ?? ($this->privates['debug.file_link_formatter'] = new \Symfony\Component\HttpKernel\Debug\FileLinkFormatter(NULL))), false, 'UTF-8');
    }

    /*
     * Gets the private 'form.registry' shared service.
     *
     * @return \Symfony\Component\Form\FormRegistry
     */
    protected function getForm_RegistryService()
    {
        return $this->privates['form.registry'] = new \Symfony\Component\Form\FormRegistry([0 => new \Symfony\Component\Form\Extension\DependencyInjection\DependencyInjectionExtension(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'Symfony\\Cmf\\Bundle\\RoutingBundle\\Form\\Type\\RouteTypeType' => ['privates', 'cmf_routing.route_type_form_type', 'getCmfRouting_RouteTypeFormTypeService.php', true],
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\ChoiceType' => ['privates', 'form.type.choice', 'getForm_Type_ChoiceService.php', true],
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FileType' => ['services', 'form.type.file', 'getForm_Type_FileService.php', true],
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FormType' => ['privates', 'form.type.form', 'getForm_Type_FormService.php', true],
        ], [
            'Symfony\\Cmf\\Bundle\\RoutingBundle\\Form\\Type\\RouteTypeType' => '?',
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\ChoiceType' => '?',
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FileType' => '?',
            'Symfony\\Component\\Form\\Extension\\Core\\Type\\FormType' => '?',
        ]), ['Symfony\\Component\\Form\\Extension\\Core\\Type\\FormType' => new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_extension.form.transformation_failure_handling'] ?? $this->load('getForm_TypeExtension_Form_TransformationFailureHandlingService.php'));
            yield 1 => ($this->privates['form.type_extension.form.http_foundation'] ?? $this->load('getForm_TypeExtension_Form_HttpFoundationService.php'));
            yield 2 => ($this->privates['form.type_extension.form.validator'] ?? $this->load('getForm_TypeExtension_Form_ValidatorService.php'));
            yield 3 => ($this->privates['form.type_extension.upload.validator'] ?? $this->load('getForm_TypeExtension_Upload_ValidatorService.php'));
            yield 4 => ($this->privates['form.type_extension.csrf'] ?? $this->load('getForm_TypeExtension_CsrfService.php'));
        }, 5), 'Symfony\\Component\\Form\\Extension\\Core\\Type\\RepeatedType' => new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_extension.repeated.validator'] ?? ($this->privates['form.type_extension.repeated.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\RepeatedTypeValidatorExtension()));
        }, 1), 'Symfony\\Component\\Form\\Extension\\Core\\Type\\SubmitType' => new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_extension.submit.validator'] ?? ($this->privates['form.type_extension.submit.validator'] = new \Symfony\Component\Form\Extension\Validator\Type\SubmitTypeValidatorExtension()));
        }, 1)], new RewindableGenerator(function () {
            yield 0 => ($this->privates['form.type_guesser.validator'] ?? $this->load('getForm_TypeGuesser_ValidatorService.php'));
        }, 1))], new \Symfony\Component\Form\ResolvedFormTypeFactory());
    }

    /*
     * Gets the private 'framework_extra_bundle.argument_name_convertor' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\Request\ArgumentNameConverter
     */
    protected function getFrameworkExtraBundle_ArgumentNameConvertorService()
    {
        return $this->privates['framework_extra_bundle.argument_name_convertor'] = new \Sensio\Bundle\FrameworkExtraBundle\Request\ArgumentNameConverter(($this->privates['argument_metadata_factory'] ?? ($this->privates['argument_metadata_factory'] = new \Symfony\Component\HttpKernel\ControllerMetadata\ArgumentMetadataFactory())));
    }

    /*
     * Gets the private 'framework_extra_bundle.event.is_granted' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\IsGrantedListener
     */
    protected function getFrameworkExtraBundle_Event_IsGrantedService()
    {
        return $this->privates['framework_extra_bundle.event.is_granted'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\IsGrantedListener(($this->privates['framework_extra_bundle.argument_name_convertor'] ?? $this->getFrameworkExtraBundle_ArgumentNameConvertorService()), ($this->services['security.authorization_checker'] ?? $this->getSecurity_AuthorizationCheckerService()));
    }

    /*
     * Gets the private 'locale_aware_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\LocaleAwareListener
     */
    protected function getLocaleAwareListenerService()
    {
        return $this->privates['locale_aware_listener'] = new \Symfony\Component\HttpKernel\EventListener\LocaleAwareListener(new RewindableGenerator(function () {
            yield 0 => ($this->privates['translator.default'] ?? $this->getTranslator_DefaultService());
        }, 1), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())));
    }

    /*
     * Gets the private 'locale_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\LocaleListener
     */
    protected function getLocaleListener2Service()
    {
        return $this->privates['locale_listener'] = new \Symfony\Component\HttpKernel\EventListener\LocaleListener(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), 'en', ($this->services['router'] ?? $this->getRouterService()));
    }

    /*
     * Gets the private 'monolog.handler.console' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Handler\ConsoleHandler
     */
    protected function getMonolog_Handler_ConsoleService()
    {
        return $this->privates['monolog.handler.console'] = new \Symfony\Bridge\Monolog\Handler\ConsoleHandler(NULL, true, [], []);
    }

    /*
     * Gets the private 'monolog.handler.main' shared service.
     *
     * @return \Monolog\Handler\FingersCrossedHandler
     */
    protected function getMonolog_Handler_MainService()
    {
        $a = new \Monolog\Handler\StreamHandler(($this->targetDirs[2].'/logs/prod.log'), 100, true, NULL, false);
        $a->pushProcessor(($this->privates['monolog.processor.psr_log_message'] ?? ($this->privates['monolog.processor.psr_log_message'] = new \Monolog\Processor\PsrLogMessageProcessor())));

        return $this->privates['monolog.handler.main'] = new \Monolog\Handler\FingersCrossedHandler($a, 400, 2000, true, true, NULL);
    }

    /*
     * Gets the private 'monolog.logger' shared service.
     *
     * @return \Symfony\Bridge\Monolog\Logger
     */
    protected function getMonolog_LoggerService()
    {
        $this->privates['monolog.logger'] = $instance = new \Symfony\Bridge\Monolog\Logger('app');

        $instance->useMicrosecondTimestamps(true);
        $instance->pushHandler(($this->privates['monolog.handler.console'] ?? $this->getMonolog_Handler_ConsoleService()));
        $instance->pushHandler(($this->privates['monolog.handler.main'] ?? $this->getMonolog_Handler_MainService()));

        return $instance;
    }

    /*
     * Gets the private 'resolve_controller_name_subscriber' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\EventListener\ResolveControllerNameSubscriber
     */
    protected function getResolveControllerNameSubscriberService()
    {
        return $this->privates['resolve_controller_name_subscriber'] = new \Symfony\Bundle\FrameworkBundle\EventListener\ResolveControllerNameSubscriber(($this->privates['controller_name_converter'] ?? ($this->privates['controller_name_converter'] = new \Symfony\Bundle\FrameworkBundle\Controller\ControllerNameParser(($this->services['kernel'] ?? $this->get('kernel', 1))))));
    }

    /*
     * Gets the private 'router_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\RouterListener
     */
    protected function getRouterListenerService()
    {
        return $this->privates['router_listener'] = new \Symfony\Component\HttpKernel\EventListener\RouterListener(($this->services['router'] ?? $this->getRouterService()), ($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->services['pimcore.routing.router.request_context'] ?? $this->getPimcore_Routing_Router_RequestContextService()), ($this->services['monolog.logger.request'] ?? $this->getMonolog_Logger_RequestService()), $this->targetDirs[3], false);
    }

    /*
     * Gets the private 'scheb_two_factor.security.authentication.trust_resolver' shared service.
     *
     * @return \Scheb\TwoFactorBundle\Security\Authentication\AuthenticationTrustResolver
     */
    protected function getSchebTwoFactor_Security_Authentication_TrustResolverService()
    {
        return $this->privates['scheb_two_factor.security.authentication.trust_resolver'] = new \Scheb\TwoFactorBundle\Security\Authentication\AuthenticationTrustResolver(new \Symfony\Component\Security\Core\Authentication\AuthenticationTrustResolver(NULL, NULL));
    }

    /*
     * Gets the private 'scheb_two_factor.trusted_cookie_response_listener' shared service.
     *
     * @return \Scheb\TwoFactorBundle\Security\TwoFactor\Trusted\TrustedCookieResponseListener
     */
    protected function getSchebTwoFactor_TrustedCookieResponseListenerService($lazyLoad = true)
    {
        if ($lazyLoad) {
            return $this->privates['scheb_two_factor.trusted_cookie_response_listener'] = $this->createProxy('TrustedCookieResponseListener_c7f9b85', function () {
                return \TrustedCookieResponseListener_c7f9b85::staticProxyConstructor(function (&$wrappedInstance, \ProxyManager\Proxy\LazyLoadingInterface $proxy) {
                    $wrappedInstance = $this->getSchebTwoFactor_TrustedCookieResponseListenerService(false);

                    $proxy->setProxyInitializer(null);

                    return true;
                });
            });
        }

        return new \Scheb\TwoFactorBundle\Security\TwoFactor\Trusted\TrustedCookieResponseListener(($this->privates['scheb_two_factor.trusted_token_storage'] ?? $this->getSchebTwoFactor_TrustedTokenStorageService()), 5184000, 'trusted_device', false, 'lax', NULL);
    }

    /*
     * Gets the private 'scheb_two_factor.trusted_token_storage' shared service.
     *
     * @return \Scheb\TwoFactorBundle\Security\TwoFactor\Trusted\TrustedDeviceTokenStorage
     */
    protected function getSchebTwoFactor_TrustedTokenStorageService($lazyLoad = true)
    {
        if ($lazyLoad) {
            return $this->privates['scheb_two_factor.trusted_token_storage'] = $this->createProxy('TrustedDeviceTokenStorage_fc7b3c4', function () {
                return \TrustedDeviceTokenStorage_fc7b3c4::staticProxyConstructor(function (&$wrappedInstance, \ProxyManager\Proxy\LazyLoadingInterface $proxy) {
                    $wrappedInstance = $this->getSchebTwoFactor_TrustedTokenStorageService(false);

                    $proxy->setProxyInitializer(null);

                    return true;
                });
            });
        }

        return new \Scheb\TwoFactorBundle\Security\TwoFactor\Trusted\TrustedDeviceTokenStorage(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), new \Scheb\TwoFactorBundle\Security\TwoFactor\Trusted\JwtTokenEncoder('F0dx6arBNiDt7tdqSDgr0MlyYSe/hzML'), 'trusted_device', 5184000);
    }

    /*
     * Gets the private 'security.access.decision_manager' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authorization\AccessDecisionManager
     */
    protected function getSecurity_Access_DecisionManagerService()
    {
        return $this->privates['security.access.decision_manager'] = new \Symfony\Component\Security\Core\Authorization\AccessDecisionManager(new RewindableGenerator(function () {
            yield 0 => ($this->privates['security.access.authenticated_voter'] ?? $this->load('getSecurity_Access_AuthenticatedVoterService.php'));
            yield 1 => ($this->privates['scheb_two_factor.security.access.authenticated_voter'] ?? ($this->privates['scheb_two_factor.security.access.authenticated_voter'] = new \Scheb\TwoFactorBundle\Security\Authorization\Voter\TwoFactorInProgressVoter()));
            yield 2 => ($this->privates['security.access.role_hierarchy_voter'] ?? $this->load('getSecurity_Access_RoleHierarchyVoterService.php'));
            yield 3 => ($this->privates['security.access.expression_voter'] ?? $this->load('getSecurity_Access_ExpressionVoterService.php'));
        }, 4), 'affirmative', false, true);
    }

    /*
     * Gets the private 'security.authentication.manager' shared service.
     *
     * @return \Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager
     */
    protected function getSecurity_Authentication_ManagerService()
    {
        $this->privates['security.authentication.manager'] = $instance = new \Symfony\Component\Security\Core\Authentication\AuthenticationProviderManager(new RewindableGenerator(function () {
            yield 0 => ($this->privates['security.authentication.provider.dao.admin_webdav.two_factor_decorator'] ?? $this->load('getSecurity_Authentication_Provider_Dao_AdminWebdav_TwoFactorDecoratorService.php'));
            yield 1 => ($this->privates['security.authentication.provider.guard.admin.two_factor_decorator'] ?? $this->load('getSecurity_Authentication_Provider_Guard_Admin_TwoFactorDecoratorService.php'));
            yield 2 => ($this->privates['security.authentication.provider.two_factor.admin'] ?? $this->load('getSecurity_Authentication_Provider_TwoFactor_AdminService.php'));
            yield 3 => ($this->privates['security.authentication.provider.anonymous.admin.two_factor_decorator'] ?? $this->load('getSecurity_Authentication_Provider_Anonymous_Admin_TwoFactorDecoratorService.php'));
            yield 4 => ($this->privates['security.authentication.provider.guard.webservice.two_factor_decorator'] ?? $this->load('getSecurity_Authentication_Provider_Guard_Webservice_TwoFactorDecoratorService.php'));
        }, 5), true);

        $instance->setEventDispatcher(($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()));

        return $instance;
    }

    /*
     * Gets the private 'security.firewall' shared service.
     *
     * @return \Symfony\Bundle\SecurityBundle\EventListener\FirewallListener
     */
    protected function getSecurity_FirewallService()
    {
        return $this->privates['security.firewall'] = new \Symfony\Bundle\SecurityBundle\EventListener\FirewallListener(($this->privates['security.firewall.map'] ?? $this->getSecurity_Firewall_MapService()), ($this->services['event_dispatcher'] ?? $this->getEventDispatcherService()), ($this->privates['security.logout_url_generator'] ?? $this->getSecurity_LogoutUrlGeneratorService()));
    }

    /*
     * Gets the private 'security.firewall.map' shared service.
     *
     * @return \Symfony\Bundle\SecurityBundle\Security\FirewallMap
     */
    protected function getSecurity_Firewall_MapService()
    {
        return $this->privates['security.firewall.map'] = new \Symfony\Bundle\SecurityBundle\Security\FirewallMap(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'security.firewall.map.context.admin' => ['privates', 'security.firewall.map.context.admin', 'getSecurity_Firewall_Map_Context_AdminService.php', true],
            'security.firewall.map.context.admin_webdav' => ['privates', 'security.firewall.map.context.admin_webdav', 'getSecurity_Firewall_Map_Context_AdminWebdavService.php', true],
            'security.firewall.map.context.dev' => ['privates', 'security.firewall.map.context.dev', 'getSecurity_Firewall_Map_Context_DevService.php', true],
            'security.firewall.map.context.webservice' => ['privates', 'security.firewall.map.context.webservice', 'getSecurity_Firewall_Map_Context_WebserviceService.php', true],
        ], [
            'security.firewall.map.context.admin' => '?',
            'security.firewall.map.context.admin_webdav' => '?',
            'security.firewall.map.context.dev' => '?',
            'security.firewall.map.context.webservice' => '?',
        ]), new RewindableGenerator(function () {
            yield 'security.firewall.map.context.dev' => ($this->privates['.security.request_matcher.Iy.T22O'] ?? ($this->privates['.security.request_matcher.Iy.T22O'] = new \Symfony\Component\HttpFoundation\RequestMatcher('^/(_(profiler|wdt)|css|images|js)/')));
            yield 'security.firewall.map.context.admin_webdav' => ($this->privates['.security.request_matcher.gpN4paB'] ?? ($this->privates['.security.request_matcher.gpN4paB'] = new \Symfony\Component\HttpFoundation\RequestMatcher('^/admin/asset/webdav')));
            yield 'security.firewall.map.context.admin' => ($this->privates['.security.request_matcher.B3ldH_a'] ?? ($this->privates['.security.request_matcher.B3ldH_a'] = new \Symfony\Component\HttpFoundation\RequestMatcher('^/admin')));
            yield 'security.firewall.map.context.webservice' => ($this->privates['.security.request_matcher.ojoWEU2'] ?? ($this->privates['.security.request_matcher.ojoWEU2'] = new \Symfony\Component\HttpFoundation\RequestMatcher('^/webservice')));
        }, 4));
    }

    /*
     * Gets the private 'security.logout_url_generator' shared service.
     *
     * @return \Symfony\Component\Security\Http\Logout\LogoutUrlGenerator
     */
    protected function getSecurity_LogoutUrlGeneratorService()
    {
        $this->privates['security.logout_url_generator'] = $instance = new \Symfony\Component\Security\Http\Logout\LogoutUrlGenerator(($this->services['request_stack'] ?? ($this->services['request_stack'] = new \Symfony\Component\HttpFoundation\RequestStack())), ($this->services['router'] ?? $this->getRouterService()), ($this->services['security.token_storage'] ?? ($this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())));

        $instance->registerListener('admin', '/admin/logout', 'logout', '_csrf_token', NULL, NULL);

        return $instance;
    }

    /*
     * Gets the private 'security.role_hierarchy' shared service.
     *
     * @return \Symfony\Component\Security\Core\Role\RoleHierarchy
     */
    protected function getSecurity_RoleHierarchyService()
    {
        return $this->privates['security.role_hierarchy'] = new \Symfony\Component\Security\Core\Role\RoleHierarchy($this->parameters['security.role_hierarchy.roles']);
    }

    /*
     * Gets the private 'sensio_framework_extra.controller.listener' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\ControllerListener
     */
    protected function getSensioFrameworkExtra_Controller_ListenerService()
    {
        return $this->privates['sensio_framework_extra.controller.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\ControllerListener(($this->privates['annotations.cached_reader'] ?? $this->getAnnotations_CachedReaderService()));
    }

    /*
     * Gets the private 'sensio_framework_extra.converter.listener' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\ParamConverterListener
     */
    protected function getSensioFrameworkExtra_Converter_ListenerService()
    {
        $a = new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\ParamConverterManager();
        $a->add(new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DoctrineParamConverter(($this->services['doctrine'] ?? $this->getDoctrineService()), new \Symfony\Component\ExpressionLanguage\ExpressionLanguage()), 0, 'doctrine.orm');
        $a->add(new \Sensio\Bundle\FrameworkExtraBundle\Request\ParamConverter\DateTimeParamConverter(), 0, 'datetime');

        return $this->privates['sensio_framework_extra.converter.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\ParamConverterListener($a, true);
    }

    /*
     * Gets the private 'sensio_framework_extra.security.listener' shared service.
     *
     * @return \Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener
     */
    protected function getSensioFrameworkExtra_Security_ListenerService()
    {
        return $this->privates['sensio_framework_extra.security.listener'] = new \Sensio\Bundle\FrameworkExtraBundle\EventListener\SecurityListener(($this->privates['framework_extra_bundle.argument_name_convertor'] ?? $this->getFrameworkExtraBundle_ArgumentNameConvertorService()), new \Sensio\Bundle\FrameworkExtraBundle\Security\ExpressionLanguage(), ($this->privates['scheb_two_factor.security.authentication.trust_resolver'] ?? $this->getSchebTwoFactor_Security_Authentication_TrustResolverService()), ($this->privates['security.role_hierarchy'] ?? $this->getSecurity_RoleHierarchyService()), ($this->services['security.token_storage'] ?? ($this->services['security.token_storage'] = new \Symfony\Component\Security\Core\Authentication\Token\Storage\TokenStorage())), ($this->services['security.authorization_checker'] ?? $this->getSecurity_AuthorizationCheckerService()), ($this->privates['monolog.logger'] ?? $this->getMonolog_LoggerService()));
    }

    /*
     * Gets the private 'sensio_framework_extra.view.listener' shared service.
     *
     * @return \Pimcore\Bundle\CoreBundle\EventListener\LegacyTemplateListener
     */
    protected function getSensioFrameworkExtra_View_ListenerService()
    {
        $this->privates['sensio_framework_extra.view.listener'] = $instance = new \Pimcore\Bundle\CoreBundle\EventListener\LegacyTemplateListener(($this->services['sensio_framework_extra.view.guesser'] ?? $this->getSensioFrameworkExtra_View_GuesserService()), ($this->services['twig'] ?? $this->getTwigService()));

        $instance->setTemplateEngine(($this->services['templating'] ?? $this->load('getTemplatingService.php')));

        return $instance;
    }

    /*
     * Gets the private 'session_listener' shared service.
     *
     * @return \Symfony\Component\HttpKernel\EventListener\SessionListener
     */
    protected function getSessionListenerService()
    {
        return $this->privates['session_listener'] = new \Symfony\Component\HttpKernel\EventListener\SessionListener(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'initialized_session' => ['services', 'session', NULL, true],
            'session' => ['services', 'session', 'getSessionService.php', true],
        ], [
            'initialized_session' => '?',
            'session' => '?',
        ]));
    }

    /*
     * Gets the private 'translator.default' shared service.
     *
     * @return \Symfony\Bundle\FrameworkBundle\Translation\Translator
     */
    protected function getTranslator_DefaultService()
    {
        $this->privates['translator.default'] = $instance = new \Symfony\Bundle\FrameworkBundle\Translation\Translator(new \Symfony\Component\DependencyInjection\Argument\ServiceLocator($this->getService, [
            'translation.loader.csv' => ['privates', 'translation.loader.csv', 'getTranslation_Loader_CsvService.php', true],
            'translation.loader.dat' => ['privates', 'translation.loader.dat', 'getTranslation_Loader_DatService.php', true],
            'translation.loader.ini' => ['privates', 'translation.loader.ini', 'getTranslation_Loader_IniService.php', true],
            'translation.loader.json' => ['privates', 'translation.loader.json', 'getTranslation_Loader_JsonService.php', true],
            'translation.loader.mo' => ['privates', 'translation.loader.mo', 'getTranslation_Loader_MoService.php', true],
            'translation.loader.php' => ['privates', 'translation.loader.php', 'getTranslation_Loader_PhpService.php', true],
            'translation.loader.po' => ['privates', 'translation.loader.po', 'getTranslation_Loader_PoService.php', true],
            'translation.loader.qt' => ['privates', 'translation.loader.qt', 'getTranslation_Loader_QtService.php', true],
            'translation.loader.res' => ['privates', 'translation.loader.res', 'getTranslation_Loader_ResService.php', true],
            'translation.loader.xliff' => ['privates', 'translation.loader.xliff', 'getTranslation_Loader_XliffService.php', true],
            'translation.loader.yml' => ['privates', 'translation.loader.yml', 'getTranslation_Loader_YmlService.php', true],
        ], [
            'translation.loader.csv' => '?',
            'translation.loader.dat' => '?',
            'translation.loader.ini' => '?',
            'translation.loader.json' => '?',
            'translation.loader.mo' => '?',
            'translation.loader.php' => '?',
            'translation.loader.po' => '?',
            'translation.loader.qt' => '?',
            'translation.loader.res' => '?',
            'translation.loader.xliff' => '?',
            'translation.loader.yml' => '?',
        ]), new \Symfony\Component\Translation\Formatter\MessageFormatter(new \Symfony\Component\Translation\IdentityTranslator()), 'en', ['translation.loader.php' => [0 => 'php'], 'translation.loader.yml' => [0 => 'yaml', 1 => 'yml'], 'translation.loader.xliff' => [0 => 'xlf', 1 => 'xliff'], 'translation.loader.po' => [0 => 'po'], 'translation.loader.mo' => [0 => 'mo'], 'translation.loader.qt' => [0 => 'ts'], 'translation.loader.csv' => [0 => 'csv'], 'translation.loader.res' => [0 => 'res'], 'translation.loader.dat' => [0 => 'dat'], 'translation.loader.ini' => [0 => 'ini'], 'translation.loader.json' => [0 => 'json']], ['cache_dir' => ($this->targetDirs[0].'/translations'), 'debug' => false, 'resource_files' => ['af' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.af.xlf')], 'ar' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.ar.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.ar.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.ar.xlf')], 'az' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.az.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.az.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.az.xlf')], 'be' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.be.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.be.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.be.xlf')], 'bg' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.bg.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.bg.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.bg.xlf')], 'ca' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.ca.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.ca.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.ca.xlf')], 'cs' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.cs.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.cs.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.cs.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.cs.yml')], 'cy' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.cy.xlf')], 'da' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.da.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.da.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.da.xlf')], 'de' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.de.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.de.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.de.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.de.yml')], 'el' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.el.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.el.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.el.xlf')], 'en' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.en.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.en.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.en.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.en.yml')], 'es' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.es.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.es.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.es.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.es.yml')], 'et' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.et.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.et.xlf')], 'eu' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.eu.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.eu.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.eu.xlf')], 'fa' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.fa.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.fa.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.fa.xlf')], 'fi' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.fi.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.fi.xlf')], 'fr' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.fr.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.fr.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.fr.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.fr.yml')], 'gl' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.gl.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.gl.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.gl.xlf')], 'he' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.he.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.he.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.he.xlf')], 'hr' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.hr.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.hr.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.hr.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.hr.yml')], 'hu' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.hu.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.hu.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.hu.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.hu.yml')], 'hy' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.hy.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.hy.xlf')], 'id' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.id.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.id.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.id.xlf')], 'it' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.it.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.it.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.it.xlf')], 'ja' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.ja.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.ja.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.ja.xlf')], 'lb' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.lb.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.lb.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.lb.xlf')], 'lt' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.lt.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.lt.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.lt.xlf')], 'lv' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.lv.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.lv.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.lv.xlf')], 'mn' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.mn.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.mn.xlf')], 'nb' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.nb.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.nb.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.nb.xlf')], 'nl' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.nl.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.nl.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.nl.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.nl.yml')], 'nn' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.nn.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.nn.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.nn.xlf')], 'no' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.no.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.no.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.no.xlf')], 'pl' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.pl.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.pl.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.pl.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.pl.yml')], 'pt' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.pt.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.pt.xlf')], 'pt_BR' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.pt_BR.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.pt_BR.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.pt_BR.xlf')], 'ro' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.ro.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.ro.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.ro.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.ro.yml')], 'ru' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.ru.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.ru.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.ru.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.ru.yml')], 'sk' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.sk.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.sk.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.sk.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.sk.yml')], 'sl' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.sl.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.sl.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.sl.xlf')], 'sq' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.sq.xlf')], 'sr_Cyrl' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.sr_Cyrl.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.sr_Cyrl.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.sr_Cyrl.xlf')], 'sr_Latn' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.sr_Latn.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.sr_Latn.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.sr_Latn.xlf')], 'sv' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.sv.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.sv.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.sv.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.sv.yml')], 'th' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.th.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.th.xlf')], 'tl' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.tl.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.tl.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.tl.xlf')], 'tr' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.tr.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.tr.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.tr.xlf')], 'uk' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.uk.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.uk.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.uk.xlf'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations/messages.uk.yml')], 'vi' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.vi.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.vi.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.vi.xlf')], 'zh_CN' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.zh_CN.xlf'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations/validators.zh_CN.xlf'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.zh_CN.xlf')], 'zh_TW' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations/validators.zh_TW.xlf')], 'pt_PT' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations/security.pt_PT.xlf')], 'extended' => [0 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/cs.extended.json'), 1 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/de.extended.json'), 2 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/en.extended.json'), 3 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/es.extended.json'), 4 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/fr.extended.json'), 5 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/it.extended.json'), 6 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/nl.extended.json'), 7 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/pl.extended.json'), 8 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations/sk.extended.json')]], 'scanned_directories' => [0 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Validator/Resources/translations'), 1 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Form/Resources/translations'), 2 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Component/Security/Core/Resources/translations'), 3 => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle/Resources/translations'), 4 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle/Resources/translations'), 5 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle/Resources/translations'), 6 => ($this->targetDirs[3].'/app/Resources/FrameworkBundle/translations'), 7 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/SecurityBundle/Resources/translations'), 8 => ($this->targetDirs[3].'/app/Resources/SecurityBundle/translations'), 9 => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/translations'), 10 => ($this->targetDirs[3].'/app/Resources/TwigBundle/translations'), 11 => ($this->targetDirs[3].'/vendor/symfony/monolog-bundle/Resources/translations'), 12 => ($this->targetDirs[3].'/app/Resources/MonologBundle/translations'), 13 => ($this->targetDirs[3].'/vendor/symfony/swiftmailer-bundle/Resources/translations'), 14 => ($this->targetDirs[3].'/app/Resources/SwiftmailerBundle/translations'), 15 => ($this->targetDirs[3].'/vendor/doctrine/doctrine-bundle/Resources/translations'), 16 => ($this->targetDirs[3].'/app/Resources/DoctrineBundle/translations'), 17 => ($this->targetDirs[3].'/vendor/sensio/framework-extra-bundle/Resources/translations'), 18 => ($this->targetDirs[3].'/app/Resources/SensioFrameworkExtraBundle/translations'), 19 => ($this->targetDirs[3].'/vendor/symfony-cmf/routing-bundle/src/Resources/translations'), 20 => ($this->targetDirs[3].'/app/Resources/CmfRoutingBundle/translations'), 21 => ($this->targetDirs[3].'/vendor/presta/sitemap-bundle/Resources/translations'), 22 => ($this->targetDirs[3].'/app/Resources/PrestaSitemapBundle/translations'), 23 => ($this->targetDirs[3].'/app/Resources/SchebTwoFactorBundle/translations'), 24 => ($this->targetDirs[3].'/app/Resources/PimcoreCoreBundle/translations'), 25 => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/AdminBundle/Resources/translations'), 26 => ($this->targetDirs[3].'/app/Resources/PimcoreAdminBundle/translations'), 27 => ($this->targetDirs[3].'/src/AppBundle/Resources/translations'), 28 => ($this->targetDirs[3].'/app/Resources/AppBundle/translations'), 29 => ($this->targetDirs[3].'/translations'), 30 => ($this->targetDirs[3].'/app/Resources/translations')]]);

        $instance->setConfigCacheFactory(($this->privates['config_cache_factory'] ?? ($this->privates['config_cache_factory'] = new \Symfony\Component\Config\ResourceCheckerConfigCacheFactory())));
        $instance->setFallbackLocales([0 => 'en']);

        return $instance;
    }

    public function getParameter($name)
    {
        $name = (string) $name;
        if (isset($this->buildParameters[$name])) {
            return $this->buildParameters[$name];
        }

        if (!(isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters))) {
            throw new InvalidArgumentException(sprintf('The parameter "%s" must be defined.', $name));
        }
        if (isset($this->loadedDynamicParameters[$name])) {
            return $this->loadedDynamicParameters[$name] ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
        }

        return $this->parameters[$name];
    }

    public function hasParameter($name)
    {
        $name = (string) $name;
        if (isset($this->buildParameters[$name])) {
            return true;
        }

        return isset($this->parameters[$name]) || isset($this->loadedDynamicParameters[$name]) || array_key_exists($name, $this->parameters);
    }

    public function setParameter($name, $value)
    {
        throw new LogicException('Impossible to call set() on a frozen ParameterBag.');
    }

    public function getParameterBag()
    {
        if (null === $this->parameterBag) {
            $parameters = $this->parameters;
            foreach ($this->loadedDynamicParameters as $name => $loaded) {
                $parameters[$name] = $loaded ? $this->dynamicParameters[$name] : $this->getDynamicParameter($name);
            }
            foreach ($this->buildParameters as $name => $value) {
                $parameters[$name] = $value;
            }
            $this->parameterBag = new FrozenParameterBag($parameters);
        }

        return $this->parameterBag;
    }

    private $loadedDynamicParameters = [
        'kernel.root_dir' => false,
        'kernel.project_dir' => false,
        'kernel.cache_dir' => false,
        'kernel.logs_dir' => false,
        'kernel.bundles_metadata' => false,
        'session.save_path' => false,
        'validator.mapping.cache.file' => false,
        'translator.default_path' => false,
        'router.resource' => false,
        'serializer.mapping.cache.file' => false,
        'twig.default_path' => false,
        'pimcore.config' => false,
        'pimcore.geoip.db_file' => false,
        'doctrine_migrations.dir_name' => false,
    ];
    private $dynamicParameters = [];

    /*
     * Computes a dynamic parameter.
     *
     * @param string $name The name of the dynamic parameter to load
     *
     * @return mixed The value of the dynamic parameter
     *
     * @throws InvalidArgumentException When the dynamic parameter does not exist
     */
    private function getDynamicParameter($name)
    {
        switch ($name) {
            case 'kernel.root_dir': $value = ($this->targetDirs[3].'/app'); break;
            case 'kernel.project_dir': $value = $this->targetDirs[3]; break;
            case 'kernel.cache_dir': $value = $this->targetDirs[0]; break;
            case 'kernel.logs_dir': $value = ($this->targetDirs[2].'/logs'); break;
            case 'kernel.bundles_metadata': $value = [
                'FrameworkBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/FrameworkBundle'),
                    'namespace' => 'Symfony\\Bundle\\FrameworkBundle',
                ],
                'SecurityBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/SecurityBundle'),
                    'namespace' => 'Symfony\\Bundle\\SecurityBundle',
                ],
                'TwigBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle'),
                    'namespace' => 'Symfony\\Bundle\\TwigBundle',
                ],
                'MonologBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/symfony/monolog-bundle'),
                    'namespace' => 'Symfony\\Bundle\\MonologBundle',
                ],
                'SwiftmailerBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/symfony/swiftmailer-bundle'),
                    'namespace' => 'Symfony\\Bundle\\SwiftmailerBundle',
                ],
                'DoctrineBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/doctrine/doctrine-bundle'),
                    'namespace' => 'Doctrine\\Bundle\\DoctrineBundle',
                ],
                'SensioFrameworkExtraBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/sensio/framework-extra-bundle'),
                    'namespace' => 'Sensio\\Bundle\\FrameworkExtraBundle',
                ],
                'CmfRoutingBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/symfony-cmf/routing-bundle/src'),
                    'namespace' => 'Symfony\\Cmf\\Bundle\\RoutingBundle',
                ],
                'PrestaSitemapBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/presta/sitemap-bundle'),
                    'namespace' => 'Presta\\SitemapBundle',
                ],
                'SchebTwoFactorBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/scheb/two-factor-bundle'),
                    'namespace' => 'Scheb\\TwoFactorBundle',
                ],
                'PimcoreCoreBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/CoreBundle'),
                    'namespace' => 'Pimcore\\Bundle\\CoreBundle',
                ],
                'PimcoreAdminBundle' => [
                    'path' => ($this->targetDirs[3].'/vendor/pimcore/pimcore/bundles/AdminBundle'),
                    'namespace' => 'Pimcore\\Bundle\\AdminBundle',
                ],
                'AppBundle' => [
                    'path' => ($this->targetDirs[3].'/src/AppBundle'),
                    'namespace' => 'AppBundle',
                ],
            ]; break;
            case 'session.save_path': $value = ($this->targetDirs[3].'/app/../var/sessions'); break;
            case 'validator.mapping.cache.file': $value = ($this->targetDirs[0].'/validation.php'); break;
            case 'translator.default_path': $value = ($this->targetDirs[3].'/translations'); break;
            case 'router.resource': $value = ($this->targetDirs[3].'/app/config/routing.yml'); break;
            case 'serializer.mapping.cache.file': $value = ($this->targetDirs[0].'/serialization.php'); break;
            case 'twig.default_path': $value = ($this->targetDirs[3].'/templates'); break;
            case 'pimcore.config': $value = [
                'web_profiler' => [
                    'toolbar' => [
                        'excluded_routes' => [
                            0 => [
                                'path' => '^/admin/asset/image-editor',
                                'route' => false,
                                'host' => false,
                                'methods' => [

                                ],
                            ],
                        ],
                    ],
                ],
                'security' => [
                    'encoder_factories' => [
                        'Pimcore\\Bundle\\AdminBundle\\Security\\User\\User' => [
                            'id' => 'pimcore_admin.security.password_encoder_factory',
                        ],
                    ],
                ],
                'error_handling' => [
                    'render_error_document' => true,
                ],
                'bundles' => [
                    'search_paths' => [
                        0 => 'src',
                        1 => 'vendor/pimcore/pimcore/bundles',
                    ],
                    'handle_composer' => true,
                ],
                'objects' => [
                    'class_definitions' => [
                        'data' => [
                            'map' => [
                                'block' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Block',
                                'calculatedValue' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\CalculatedValue',
                                'checkbox' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Checkbox',
                                'classificationstore' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Classificationstore',
                                'consent' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Consent',
                                'country' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Country',
                                'countrymultiselect' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Countrymultiselect',
                                'date' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Date',
                                'datetime' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Datetime',
                                'email' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Email',
                                'encryptedField' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\EncryptedField',
                                'externalImage' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\ExternalImage',
                                'fieldcollections' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Fieldcollections',
                                'firstname' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Firstname',
                                'gender' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Gender',
                                'geobounds' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Geobounds',
                                'geopoint' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Geopoint',
                                'geopolygon' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Geopolygon',
                                'hotspotimage' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Hotspotimage',
                                'manyToOneRelation' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\ManyToOneRelation',
                                'image' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Image',
                                'imageGallery' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\ImageGallery',
                                'input' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Input',
                                'language' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Language',
                                'languagemultiselect' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Languagemultiselect',
                                'lastname' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Lastname',
                                'link' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Link',
                                'localizedfields' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Localizedfields',
                                'manyToManyRelation' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\ManyToManyRelation',
                                'advancedManyToManyRelation' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\AdvancedManyToManyRelation',
                                'multiselect' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Multiselect',
                                'newsletterActive' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\NewsletterActive',
                                'reverseManyToManyObjectRelation' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\ReverseManyToManyObjectRelation',
                                'numeric' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Numeric',
                                'objectbricks' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Objectbricks',
                                'manyToManyObjectRelation' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\ManyToManyObjectRelation',
                                'advancedManyToManyObjectRelation' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\AdvancedManyToManyObjectRelation',
                                'password' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Password',
                                'rgbaColor' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\RgbaColor',
                                'targetGroup' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\TargetGroup',
                                'targetGroupMultiselect' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\TargetGroupMultiselect',
                                'quantityValue' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\QuantityValue',
                                'inputQuantityValue' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\InputQuantityValue',
                                'select' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Select',
                                'slider' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Slider',
                                'structuredTable' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\StructuredTable',
                                'table' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Table',
                                'textarea' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Textarea',
                                'time' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Time',
                                'user' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\User',
                                'video' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Video',
                                'wysiwyg' => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\Wysiwyg',
                            ],
                            'prefixes' => [
                                0 => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Data\\',
                                1 => '\\Object_Class_Data_',
                            ],
                        ],
                        'layout' => [
                            'prefixes' => [
                                0 => '\\Pimcore\\Model\\DataObject\\ClassDefinition\\Layout\\',
                                1 => '\\Object_Class_Layout_',
                            ],
                            'map' => [

                            ],
                        ],
                    ],
                    'tree_paging_limit' => 30,
                ],
                'documents' => [
                    'tags' => [
                        'map' => [
                            'href' => '\\Pimcore\\Model\\Document\\Tag\\Relation',
                            'multihref' => '\\Pimcore\\Model\\Document\\Tag\\Relations',
                        ],
                        'prefixes' => [
                            0 => '\\Pimcore\\Model\\Document\\Tag\\',
                            1 => '\\Document_Tag_',
                        ],
                    ],
                    'create_redirect_when_moved' => false,
                    'allow_trailing_slash' => 'no',
                    'generate_preview' => false,
                    'tree_paging_limit' => 50,
                    'editables' => [
                        'naming_strategy' => 'nested',
                    ],
                    'areas' => [
                        'autoload' => true,
                    ],
                    'newsletter' => [
                        'defaultUrlPrefix' => NULL,
                    ],
                ],
                'newsletter' => [
                    'source_adapters' => [
                        'defaultAdapter' => 'pimcore.document.newsletter.factory.default',
                        'csvList' => 'pimcore.document.newsletter.factory.csv',
                        'reportAdapter' => 'pimcore.document.newsletter.factory.report',
                    ],
                    'method' => NULL,
                ],
                'custom_report' => [
                    'adapters' => [
                        'sql' => 'pimcore.custom_report.adapter.factory.sql',
                        'analytics' => 'pimcore.custom_report.adapter.factory.analytics',
                    ],
                ],
                'targeting' => [
                    'data_providers' => [
                        'device' => 'Pimcore\\Targeting\\DataProvider\\Device',
                        'geoip' => 'Pimcore\\Targeting\\DataProvider\\GeoIp',
                        'geolocation' => 'Pimcore\\Targeting\\DataProvider\\GeoLocation',
                        'piwik' => 'Pimcore\\Targeting\\DataProvider\\Piwik',
                        'targeting_storage' => 'Pimcore\\Targeting\\DataProvider\\TargetingStorage',
                        'visited_pages_counter' => 'Pimcore\\Targeting\\DataProvider\\VisitedPagesCounter',
                    ],
                    'conditions' => [
                        'browser' => 'Pimcore\\Targeting\\Condition\\Browser',
                        'country' => 'Pimcore\\Targeting\\Condition\\Country',
                        'geopoint' => 'Pimcore\\Targeting\\Condition\\GeoPoint',
                        'hardwareplatform' => 'Pimcore\\Targeting\\Condition\\HardwarePlatform',
                        'language' => 'Pimcore\\Targeting\\Condition\\Language',
                        'operatingsystem' => 'Pimcore\\Targeting\\Condition\\OperatingSystem',
                        'referringsite' => 'Pimcore\\Targeting\\Condition\\ReferringSite',
                        'searchengine' => 'Pimcore\\Targeting\\Condition\\SearchEngine',
                        'target_group' => 'Pimcore\\Targeting\\Condition\\TargetGroup',
                        'timeonsite' => 'Pimcore\\Targeting\\Condition\\TimeOnSite',
                        'url' => 'Pimcore\\Targeting\\Condition\\Url',
                        'visitedpagebefore' => 'Pimcore\\Targeting\\Condition\\Piwik\\VisitedPageBefore',
                        'visitedpagesbefore' => 'Pimcore\\Targeting\\Condition\\VisitedPagesBefore',
                    ],
                    'action_handlers' => [
                        'assign_target_group' => 'Pimcore\\Targeting\\ActionHandler\\AssignTargetGroup',
                        'codesnippet' => 'Pimcore\\Targeting\\ActionHandler\\CodeSnippet',
                        'redirect' => 'Pimcore\\Targeting\\ActionHandler\\Redirect',
                    ],
                    'enabled' => true,
                    'storage_id' => 'Pimcore\\Targeting\\Storage\\CookieStorage',
                    'session' => [
                        'enabled' => false,
                    ],
                ],
                'context' => [
                    'profiler' => [
                        'routes' => [
                            0 => [
                                'path' => '^/_(profiler|wdt)',
                                'route' => false,
                                'host' => false,
                                'methods' => [

                                ],
                            ],
                        ],
                    ],
                    'admin' => [
                        'routes' => [
                            0 => [
                                'path' => '^/admin',
                                'route' => false,
                                'host' => false,
                                'methods' => [

                                ],
                            ],
                            1 => [
                                'route' => '^pimcore_admin_',
                                'path' => false,
                                'host' => false,
                                'methods' => [

                                ],
                            ],
                        ],
                    ],
                    'webservice' => [
                        'routes' => [
                            0 => [
                                'path' => '^/webservice',
                                'route' => false,
                                'host' => false,
                                'methods' => [

                                ],
                            ],
                            1 => [
                                'route' => '^pimcore_webservice',
                                'path' => false,
                                'host' => false,
                                'methods' => [

                                ],
                            ],
                        ],
                    ],
                    'plugin' => [
                        'routes' => [
                            0 => [
                                'path' => '^/plugin',
                                'route' => false,
                                'host' => false,
                                'methods' => [

                                ],
                            ],
                        ],
                    ],
                ],
                'admin' => [
                    'session' => [
                        'attribute_bags' => [
                            'pimcore_admin' => [
                                'storage_key' => '_pimcore_admin',
                            ],
                            'pimcore_documents' => [
                                'storage_key' => '_pimcore_documents',
                            ],
                            'pimcore_objects' => [
                                'storage_key' => '_pimcore_objects',
                            ],
                            'pimcore_copy' => [
                                'storage_key' => '_pimcore_copy',
                            ],
                            'pimcore_gridconfig' => [
                                'storage_key' => '_pimcore_gridconfig',
                            ],
                            'pimcore_importconfig' => [
                                'storage_key' => '_pimcore_importconfig',
                            ],
                        ],
                    ],
                    'unauthenticated_routes' => [
                        0 => [
                            'route' => 'pimcore_settings_display_custom_logo',
                            'path' => false,
                            'host' => false,
                            'methods' => [

                            ],
                        ],
                        1 => [
                            'route' => 'pimcore_admin_login',
                            'path' => false,
                            'host' => false,
                            'methods' => [

                            ],
                        ],
                        2 => [
                            'route' => 'pimcore_admin_webdav',
                            'path' => false,
                            'host' => false,
                            'methods' => [

                            ],
                        ],
                    ],
                    'translations' => [
                        'path' => '@PimcoreCoreBundle/Resources/translations',
                    ],
                ],
                'migrations' => [
                    'sets' => [
                        'app' => [
                            'name' => 'Migrations',
                            'namespace' => 'App\\Migrations',
                            'directory' => ($this->targetDirs[3].'/app/Resources/migrations'),
                            'connection' => NULL,
                        ],
                        'pimcore_core' => [
                            'name' => 'Pimcore Core Migrations',
                            'namespace' => 'Pimcore\\Bundle\\CoreBundle\\Migrations',
                            'directory' => ($this->targetDirs[3].'/app/../vendor/pimcore/pimcore/bundles/CoreBundle/Resources/migrations'),
                            'connection' => NULL,
                        ],
                    ],
                ],
                'sitemaps' => [
                    'generators' => [
                        'pimcore_documents' => [
                            'enabled' => true,
                            'priority' => 100,
                            'generator_id' => 'Pimcore\\Sitemap\\Document\\DocumentTreeGenerator',
                        ],
                    ],
                ],
                'mime' => [
                    'extensions' => [
                        'ez' => 'application/andrew-inset',
                        'atom' => 'application/atom+xml',
                        'jar' => 'application/java-archive',
                        'hqx' => 'application/mac-binhex40',
                        'cpt' => 'application/mac-compactpro',
                        'mathml' => 'application/mathml+xml',
                        'doc' => 'application/msword',
                        'dat' => 'application/octet-stream',
                        'oda' => 'application/oda',
                        'ogg' => 'application/ogg',
                        'pdf' => 'application/pdf',
                        'ai' => 'application/ai',
                        'eps' => 'application/postscript',
                        'ps' => 'application/postscript',
                        'rdf' => 'application/rdf+xml',
                        'rss' => 'application/rss+xml',
                        'smi' => 'application/smil',
                        'smil' => 'application/smil',
                        'gram' => 'application/srgs',
                        'grxml' => 'application/srgs+xml',
                        'kml' => 'application/vnd.google-earth.kml+xml',
                        'kmz' => 'application/vnd.google-earth.kmz',
                        'mif' => 'application/vnd.mif',
                        'xul' => 'application/vnd.mozilla.xul+xml',
                        'xls' => 'application/vnd.ms-excel',
                        'xlb' => 'application/vnd.ms-excel',
                        'xlt' => 'application/vnd.ms-excel',
                        'xlam' => 'application/vnd.ms-excel.addin.macroEnabled.12',
                        'xlsb' => 'application/vnd.ms-excel.sheet.binary.macroEnabled.12',
                        'xlsm' => 'application/vnd.ms-excel.sheet.macroEnabled.12',
                        'xltm' => 'application/vnd.ms-excel.template.macroEnabled.12',
                        'docm' => 'application/vnd.ms-word.document.macroEnabled.12',
                        'dotm' => 'application/vnd.ms-word.template.macroEnabled.12',
                        'ppam' => 'application/vnd.ms-powerpoint.addin.macroEnabled.12',
                        'pptm' => 'application/vnd.ms-powerpoint.presentation.macroEnabled.12',
                        'ppsm' => 'application/vnd.ms-powerpoint.slideshow.macroEnabled.12',
                        'potm' => 'application/vnd.ms-powerpoint.template.macroEnabled.12',
                        'ppt' => 'application/vnd.ms-powerpoint',
                        'pps' => 'application/vnd.ms-powerpoint',
                        'odc' => 'application/vnd.oasis.opendocument.chart',
                        'odb' => 'application/vnd.oasis.opendocument.database',
                        'odf' => 'application/vnd.oasis.opendocument.formula',
                        'odg' => 'application/vnd.oasis.opendocument.graphics',
                        'otg' => 'application/vnd.oasis.opendocument.graphics-template',
                        'odi' => 'application/vnd.oasis.opendocument.image',
                        'odp' => 'application/vnd.oasis.opendocument.presentation',
                        'otp' => 'application/vnd.oasis.opendocument.presentation-template',
                        'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
                        'ots' => 'application/vnd.oasis.opendocument.spreadsheet-template',
                        'odt' => 'application/vnd.oasis.opendocument.text',
                        'odm' => 'application/vnd.oasis.opendocument.text-master',
                        'ott' => 'application/vnd.oasis.opendocument.text-template',
                        'oth' => 'application/vnd.oasis.opendocument.text-web',
                        'potx' => 'application/vnd.openxmlformats-officedocument.presentationml.template',
                        'ppsx' => 'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
                        'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                        'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        'xltx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.template',
                        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                        'dotx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
                        'vsd' => 'application/vnd.visio',
                        'wbxml' => 'application/vnd.wap.wbxml',
                        'wmlc' => 'application/vnd.wap.wmlc',
                        'wmlsc' => 'application/vnd.wap.wmlscriptc',
                        'vxml' => 'application/voicexml+xml',
                        'bcpio' => 'application/x-bcpio',
                        'vcd' => 'application/x-cdlink',
                        'pgn' => 'application/x-chess-pgn',
                        'cpio' => 'application/x-cpio',
                        'csh' => 'application/x-csh',
                        'dcr' => 'application/x-director',
                        'dir' => 'application/x-director',
                        'dxr' => 'application/x-director',
                        'dxf' => 'application/x-autocad',
                        'dvi' => 'application/x-dvi',
                        'spl' => 'application/x-futuresplash',
                        'tgz' => 'application/x-gtar',
                        'gtar' => 'application/x-gtar',
                        'hdf' => 'application/x-hdf',
                        'js' => 'application/x-javascript',
                        'skp' => 'application/x-koan',
                        'skd' => 'application/x-koan',
                        'skt' => 'application/x-koan',
                        'skm' => 'application/x-koan',
                        'latex' => 'application/x-latex',
                        'nc' => 'application/x-netcdf',
                        'cdf' => 'application/x-netcdf',
                        'sh' => 'application/x-sh',
                        'shar' => 'application/x-shar',
                        'swf' => 'application/x-shockwave-flash',
                        'sit' => 'application/x-stuffit',
                        'sv4cpio' => 'application/x-sv4cpio',
                        'sv4crc' => 'application/x-sv4crc',
                        'tar' => 'application/x-tar',
                        'tcl' => 'application/x-tcl',
                        'tex' => 'application/x-tex',
                        'texinfo' => 'application/x-texinfo',
                        'texi' => 'application/x-texinfo',
                        't' => 'application/x-troff',
                        'tr' => 'application/x-troff',
                        'roff' => 'application/x-troff',
                        'man' => 'application/x-troff-man',
                        'me' => 'application/x-troff-me',
                        'ms' => 'application/x-troff-ms',
                        'ustar' => 'application/x-ustar',
                        'src' => 'application/x-wais-source',
                        'xhtml' => 'application/xhtml+xml',
                        'xht' => 'application/xhtml+xml',
                        'xslt' => 'application/xslt+xml',
                        'xml' => 'application/xml',
                        'xsl' => 'application/xml',
                        'dtd' => 'application/xml-dtd',
                        'zip' => 'application/zip',
                        'au' => 'audio/basic',
                        'snd' => 'audio/basic',
                        'mid' => 'audio/midi',
                        'midi' => 'audio/midi',
                        'kar' => 'audio/midi',
                        'mpga' => 'audio/mpeg',
                        'mp2' => 'audio/mpeg',
                        'mp3' => 'audio/mpeg',
                        'aif' => 'audio/x-aiff',
                        'aiff' => 'audio/x-aiff',
                        'aifc' => 'audio/x-aiff',
                        'm3u' => 'audio/x-mpegurl',
                        'wma' => 'audio/x-ms-wma',
                        'wax' => 'audio/x-ms-wax',
                        'ram' => 'audio/x-pn-realaudio',
                        'ra' => 'audio/x-pn-realaudio',
                        'rm' => 'application/vnd.rn-realmedia',
                        'wav' => 'audio/x-wav',
                        'pdb' => 'chemical/x-pdb',
                        'xyz' => 'chemical/x-xyz',
                        'bmp' => 'image/bmp',
                        'cgm' => 'image/cgm',
                        'gif' => 'image/gif',
                        'ief' => 'image/ief',
                        'jpeg' => 'image/jpeg',
                        'jpg' => 'image/jpeg',
                        'jpe' => 'image/jpeg',
                        'png' => 'image/png',
                        'svg' => 'image/svg+xml',
                        'tiff' => 'image/tiff',
                        'tif' => 'image/tiff',
                        'djvu' => 'image/vnd.djvu',
                        'djv' => 'image/vnd.djvu',
                        'wbmp' => 'image/vnd.wap.wbmp',
                        'ras' => 'image/x-cmu-raster',
                        'ico' => 'image/x-icon',
                        'pnm' => 'image/x-portable-anymap',
                        'pbm' => 'image/x-portable-bitmap',
                        'pgm' => 'image/x-portable-graymap',
                        'ppm' => 'image/x-portable-pixmap',
                        'rgb' => 'image/x-rgb',
                        'xbm' => 'image/x-xbitmap',
                        'psd' => 'image/x-photoshop',
                        'psb' => 'image/psb',
                        'xpm' => 'image/x-xpixmap',
                        'xwd' => 'image/x-xwindowdump',
                        'eml' => 'message/rfc822',
                        'igs' => 'model/iges',
                        'iges' => 'model/iges',
                        'msh' => 'model/mesh',
                        'mesh' => 'model/mesh',
                        'silo' => 'model/mesh',
                        'wrl' => 'model/vrml',
                        'vrml' => 'model/vrml',
                        'ics' => 'text/calendar',
                        'ifb' => 'text/calendar',
                        'css' => 'text/css',
                        'csv' => 'text/csv',
                        'html' => 'text/html',
                        'htm' => 'text/html',
                        'txt' => 'text/plain',
                        'asc' => 'text/plain',
                        'rtx' => 'text/richtext',
                        'rtf' => 'text/rtf',
                        'sgml' => 'text/sgml',
                        'sgm' => 'text/sgml',
                        'tsv' => 'text/tab-separated-values',
                        'wml' => 'text/vnd.wap.wml',
                        'wmls' => 'text/vnd.wap.wmlscript',
                        'etx' => 'text/x-setext',
                        'mpeg' => 'video/mpeg',
                        'mpg' => 'video/mpeg',
                        'mpe' => 'video/mpeg',
                        'qt' => 'video/quicktime',
                        'mov' => 'video/quicktime',
                        'mxu' => 'video/vnd.mpegurl',
                        'm4u' => 'video/vnd.mpegurl',
                        'flv' => 'video/x-flv',
                        'f4v' => 'video/mp4',
                        'mp4' => 'video/mp4',
                        'asf' => 'video/x-ms-asf',
                        'asx' => 'video/x-ms-asf',
                        'wmv' => 'video/x-ms-wmv',
                        'wm' => 'video/x-ms-wm',
                        'wmx' => 'video/x-ms-wmx',
                        'avi' => 'video/x-msvideo',
                        'ogv' => 'video/ogg',
                        'movie' => 'video/x-sgi-movie',
                        'ice' => 'x-conference/x-cooltalk',
                    ],
                ],
                'flags' => [

                ],
                'translations' => [
                    'case_insensitive' => false,
                    'debugging' => [
                        'enabled' => true,
                        'parameter' => 'pimcore_debug_translations',
                    ],
                    'data_object' => [

                    ],
                ],
                'maps' => [
                    'tile_layer_url_template' => 'https://a.tile.openstreetmap.org/{z}/{x}/{y}.png',
                    'geocoding_url_template' => 'https://nominatim.openstreetmap.org/search?q={q}&addressdetails=1&format=json&limit=1',
                    'reverse_geocoding_url_template' => 'https://nominatim.openstreetmap.org/reverse?format=json&lat={lat}&lon={lon}&addressdetails=1',
                ],
                'general' => [
                    'timezone' => 'Europe/Berlin',
                    'path_variable' => NULL,
                    'domain' => NULL,
                    'redirect_to_maindomain' => false,
                    'language' => 'en',
                    'valid_languages' => 'en',
                    'fallback_languages' => [

                    ],
                    'default_language' => 'en',
                    'disable_usage_statistics' => false,
                    'debug_admin_translations' => false,
                    'instance_identifier' => NULL,
                    'show_cookie_notice' => false,
                ],
                'webservice' => [
                    'enabled' => false,
                ],
                'assets' => [
                    'preview_image_thumbnail' => NULL,
                    'default_upload_path' => '_default_upload_bucket',
                    'tree_paging_limit' => 100,
                    'image' => [
                        'low_quality_image_preview' => [
                            'enabled' => true,
                            'generator' => NULL,
                        ],
                        'focal_point_detection' => [
                            'enabled' => true,
                        ],
                        'thumbnails' => [
                            'webp_auto_support' => true,
                            'auto_clear_temp_files' => true,
                        ],
                    ],
                    'video' => [
                        'thumbnails' => [
                            'auto_clear_temp_files' => true,
                        ],
                    ],
                    'versions' => [
                        'days' => NULL,
                        'steps' => NULL,
                        'use_hardlinks' => true,
                    ],
                    'icc_rgb_profile' => NULL,
                    'icc_cmyk_profile' => NULL,
                    'hide_edit_image' => false,
                    'disable_tree_preview' => true,
                ],
                'encryption' => [
                    'secret' => NULL,
                ],
                'models' => [
                    'class_overrides' => [

                    ],
                ],
                'routing' => [
                    'defaults' => [
                        'bundle' => 'AppBundle',
                        'controller' => 'Default',
                        'action' => 'default',
                    ],
                    'static' => [
                        'locale_params' => [

                        ],
                    ],
                ],
                'cache' => [
                    'enabled' => true,
                    'lifetime' => NULL,
                    'pool_service_id' => NULL,
                    'default_lifetime' => 2419200,
                    'pools' => [
                        'doctrine' => [
                            'enabled' => true,
                            'connection' => 'default',
                        ],
                        'redis' => [
                            'enabled' => false,
                        ],
                    ],
                ],
                'email' => [
                    'method' => NULL,
                ],
                'workflows' => [

                ],
                'httpclient' => [
                    'adapter' => 'Socket',
                    'proxy_host' => NULL,
                    'proxy_port' => NULL,
                    'proxy_user' => NULL,
                    'proxy_pass' => NULL,
                ],
                'applicationlog' => [
                    'archive_treshold' => '',
                    'archive_alternative_database' => '',
                ],
            ]; break;
            case 'pimcore.geoip.db_file': $value = ($this->targetDirs[2].'/config/GeoLite2-City.mmdb'); break;
            case 'doctrine_migrations.dir_name': $value = ($this->targetDirs[3].'/app/DoctrineMigrations'); break;
            default: throw new InvalidArgumentException(sprintf('The dynamic parameter "%s" must be defined.', $name));
        }
        $this->loadedDynamicParameters[$name] = true;

        return $this->dynamicParameters[$name] = $value;
    }

    /*
     * Gets the default parameters.
     *
     * @return array An array of the default parameters
     */
    protected function getDefaultParameters()
    {
        return [
            'kernel.environment' => 'prod',
            'kernel.debug' => false,
            'kernel.name' => 'app',
            'kernel.bundles' => [
                'FrameworkBundle' => 'Symfony\\Bundle\\FrameworkBundle\\FrameworkBundle',
                'SecurityBundle' => 'Symfony\\Bundle\\SecurityBundle\\SecurityBundle',
                'TwigBundle' => 'Symfony\\Bundle\\TwigBundle\\TwigBundle',
                'MonologBundle' => 'Symfony\\Bundle\\MonologBundle\\MonologBundle',
                'SwiftmailerBundle' => 'Symfony\\Bundle\\SwiftmailerBundle\\SwiftmailerBundle',
                'DoctrineBundle' => 'Doctrine\\Bundle\\DoctrineBundle\\DoctrineBundle',
                'SensioFrameworkExtraBundle' => 'Sensio\\Bundle\\FrameworkExtraBundle\\SensioFrameworkExtraBundle',
                'CmfRoutingBundle' => 'Symfony\\Cmf\\Bundle\\RoutingBundle\\CmfRoutingBundle',
                'PrestaSitemapBundle' => 'Presta\\SitemapBundle\\PrestaSitemapBundle',
                'SchebTwoFactorBundle' => 'Scheb\\TwoFactorBundle\\SchebTwoFactorBundle',
                'PimcoreCoreBundle' => 'Pimcore\\Bundle\\CoreBundle\\PimcoreCoreBundle',
                'PimcoreAdminBundle' => 'Pimcore\\Bundle\\AdminBundle\\PimcoreAdminBundle',
                'AppBundle' => 'AppBundle\\AppBundle',
            ],
            'kernel.charset' => 'UTF-8',
            'kernel.container_class' => 'appAppKernelProdContainer',
            'locale' => 'en',
            'secret' => 'F0dx6arBNiDt7tdqSDgr0MlyYSe/hzML',
            'fragment.renderer.hinclude.global_template' => NULL,
            'fragment.path' => '/_fragment',
            'kernel.secret' => 'F0dx6arBNiDt7tdqSDgr0MlyYSe/hzML',
            'kernel.http_method_override' => true,
            'kernel.trusted_hosts' => [

            ],
            'kernel.default_locale' => 'en',
            'templating.helper.code.file_link_format' => NULL,
            'debug.file_link_format' => NULL,
            'session.metadata.storage_key' => '_sf2_meta',
            'session.storage.options' => [
                'cache_limiter' => '0',
                'cookie_httponly' => true,
                'gc_probability' => 1,
            ],
            'session.metadata.update_threshold' => 0,
            'form.type_extension.csrf.enabled' => true,
            'form.type_extension.csrf.field_name' => '_token',
            'asset.request_context.base_path' => '',
            'asset.request_context.secure' => false,
            'templating.loader.cache.path' => NULL,
            'templating.engines' => [
                0 => 'php',
                1 => 'twig',
            ],
            'templating.helper.form.resources' => [
                0 => 'FrameworkBundle:Form',
            ],
            'validator.mapping.cache.prefix' => '',
            'validator.translation_domain' => 'validators',
            'translator.logging' => false,
            'data_collector.templates' => [

            ],
            'debug.error_handler.throw_at' => 0,
            'router.request_context.host' => 'localhost',
            'router.request_context.scheme' => 'http',
            'router.request_context.base_url' => '',
            'router.cache_class_prefix' => 'appAppKernelProdContainer',
            'request_listener.http_port' => 80,
            'request_listener.https_port' => 443,
            'serializer.mapping.cache.prefix' => '',
            'security.authentication.trust_resolver.anonymous_class' => NULL,
            'security.authentication.trust_resolver.rememberme_class' => NULL,
            'security.role_hierarchy.roles' => [
                'ROLE_PIMCORE_ADMIN' => [
                    0 => 'ROLE_PIMCORE_USER',
                ],
            ],
            'security.access.denied_url' => NULL,
            'security.authentication.manager.erase_credentials' => true,
            'security.authentication.session_strategy.strategy' => 'migrate',
            'security.access.always_authenticate_before_granting' => false,
            'security.authentication.hide_user_not_found' => true,
            'twig.exception_listener.controller' => 'twig.controller.exception::showAction',
            'twig.form.resources' => [
                0 => 'form_div_layout.html.twig',
            ],
            'monolog.use_microseconds' => true,
            'monolog.swift_mailer.handlers' => [

            ],
            'monolog.handlers_to_channels' => [
                'monolog.handler.console' => NULL,
                'monolog.handler.main' => NULL,
            ],
            'swiftmailer.mailer.pimcore_mailer.transport.name' => 'smtp',
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.encryption' => NULL,
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.port' => 25,
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.host' => 'localhost',
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.username' => NULL,
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.password' => NULL,
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.auth_mode' => NULL,
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.timeout' => 30,
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.source_ip' => NULL,
            'swiftmailer.mailer.pimcore_mailer.transport.smtp.local_domain' => NULL,
            'swiftmailer.mailer.pimcore_mailer.spool.enabled' => false,
            'swiftmailer.mailer.pimcore_mailer.plugin.impersonate' => NULL,
            'swiftmailer.mailer.pimcore_mailer.single_address' => NULL,
            'swiftmailer.mailer.pimcore_mailer.delivery.enabled' => true,
            'swiftmailer.spool.enabled' => false,
            'swiftmailer.delivery.enabled' => true,
            'swiftmailer.single_address' => NULL,
            'swiftmailer.mailers' => [
                'pimcore_mailer' => 'swiftmailer.mailer.pimcore_mailer',
            ],
            'swiftmailer.default_mailer' => 'pimcore_mailer',
            'doctrine_cache.apc.class' => 'Doctrine\\Common\\Cache\\ApcCache',
            'doctrine_cache.apcu.class' => 'Doctrine\\Common\\Cache\\ApcuCache',
            'doctrine_cache.array.class' => 'Doctrine\\Common\\Cache\\ArrayCache',
            'doctrine_cache.chain.class' => 'Doctrine\\Common\\Cache\\ChainCache',
            'doctrine_cache.couchbase.class' => 'Doctrine\\Common\\Cache\\CouchbaseCache',
            'doctrine_cache.couchbase.connection.class' => 'Couchbase',
            'doctrine_cache.couchbase.hostnames' => 'localhost:8091',
            'doctrine_cache.file_system.class' => 'Doctrine\\Common\\Cache\\FilesystemCache',
            'doctrine_cache.php_file.class' => 'Doctrine\\Common\\Cache\\PhpFileCache',
            'doctrine_cache.memcache.class' => 'Doctrine\\Common\\Cache\\MemcacheCache',
            'doctrine_cache.memcache.connection.class' => 'Memcache',
            'doctrine_cache.memcache.host' => 'localhost',
            'doctrine_cache.memcache.port' => 11211,
            'doctrine_cache.memcached.class' => 'Doctrine\\Common\\Cache\\MemcachedCache',
            'doctrine_cache.memcached.connection.class' => 'Memcached',
            'doctrine_cache.memcached.host' => 'localhost',
            'doctrine_cache.memcached.port' => 11211,
            'doctrine_cache.mongodb.class' => 'Doctrine\\Common\\Cache\\MongoDBCache',
            'doctrine_cache.mongodb.collection.class' => 'MongoCollection',
            'doctrine_cache.mongodb.connection.class' => 'MongoClient',
            'doctrine_cache.mongodb.server' => 'localhost:27017',
            'doctrine_cache.predis.client.class' => 'Predis\\Client',
            'doctrine_cache.predis.scheme' => 'tcp',
            'doctrine_cache.predis.host' => 'localhost',
            'doctrine_cache.predis.port' => 6379,
            'doctrine_cache.redis.class' => 'Doctrine\\Common\\Cache\\RedisCache',
            'doctrine_cache.redis.connection.class' => 'Redis',
            'doctrine_cache.redis.host' => 'localhost',
            'doctrine_cache.redis.port' => 6379,
            'doctrine_cache.riak.class' => 'Doctrine\\Common\\Cache\\RiakCache',
            'doctrine_cache.riak.bucket.class' => 'Riak\\Bucket',
            'doctrine_cache.riak.connection.class' => 'Riak\\Connection',
            'doctrine_cache.riak.bucket_property_list.class' => 'Riak\\BucketPropertyList',
            'doctrine_cache.riak.host' => 'localhost',
            'doctrine_cache.riak.port' => 8087,
            'doctrine_cache.sqlite3.class' => 'Doctrine\\Common\\Cache\\SQLite3Cache',
            'doctrine_cache.sqlite3.connection.class' => 'SQLite3',
            'doctrine_cache.void.class' => 'Doctrine\\Common\\Cache\\VoidCache',
            'doctrine_cache.wincache.class' => 'Doctrine\\Common\\Cache\\WinCacheCache',
            'doctrine_cache.xcache.class' => 'Doctrine\\Common\\Cache\\XcacheCache',
            'doctrine_cache.zenddata.class' => 'Doctrine\\Common\\Cache\\ZendDataCache',
            'doctrine_cache.security.acl.cache.class' => 'Doctrine\\Bundle\\DoctrineCacheBundle\\Acl\\Model\\AclCache',
            'doctrine.dbal.logger.chain.class' => 'Doctrine\\DBAL\\Logging\\LoggerChain',
            'doctrine.dbal.logger.profiling.class' => 'Doctrine\\DBAL\\Logging\\DebugStack',
            'doctrine.dbal.logger.class' => 'Symfony\\Bridge\\Doctrine\\Logger\\DbalLogger',
            'doctrine.dbal.configuration.class' => 'Doctrine\\DBAL\\Configuration',
            'doctrine.data_collector.class' => 'Doctrine\\Bundle\\DoctrineBundle\\DataCollector\\DoctrineDataCollector',
            'doctrine.dbal.connection.event_manager.class' => 'Symfony\\Bridge\\Doctrine\\ContainerAwareEventManager',
            'doctrine.dbal.connection_factory.class' => 'Doctrine\\Bundle\\DoctrineBundle\\ConnectionFactory',
            'doctrine.dbal.events.mysql_session_init.class' => 'Doctrine\\DBAL\\Event\\Listeners\\MysqlSessionInit',
            'doctrine.dbal.events.oracle_session_init.class' => 'Doctrine\\DBAL\\Event\\Listeners\\OracleSessionInit',
            'doctrine.class' => 'Doctrine\\Bundle\\DoctrineBundle\\Registry',
            'doctrine.entity_managers' => [

            ],
            'doctrine.default_entity_manager' => '',
            'doctrine.dbal.connection_factory.types' => [

            ],
            'doctrine.connections' => [
                'default' => 'doctrine.dbal.default_connection',
            ],
            'doctrine.default_connection' => 'default',
            'cmf_routing.uri_filter_regexp' => '',
            'cmf_routing.default_controller' => NULL,
            'cmf_routing.generic_controller' => NULL,
            'cmf_routing.controllers_by_type' => [

            ],
            'cmf_routing.controllers_by_class' => [

            ],
            'cmf_routing.templates_by_class' => [

            ],
            'cmf_routing.route_collection_limit' => 0,
            'cmf_routing.dynamic.limit_candidates' => 20,
            'cmf_routing.dynamic.locales' => [

            ],
            'cmf_routing.dynamic.auto_locale_pattern' => false,
            'cmf_routing.replace_symfony_router' => true,
            'presta_sitemap.generator.class' => 'Presta\\SitemapBundle\\Service\\Generator',
            'presta_sitemap.dumper.class' => 'Presta\\SitemapBundle\\Service\\Dumper',
            'presta_sitemap.routing_loader.class' => 'Presta\\SitemapBundle\\Routing\\SitemapRoutingLoader',
            'presta_sitemap.dump_command.class' => 'Presta\\SitemapBundle\\Command\\DumpSitemapsCommand',
            'presta_sitemap.dump_directory' => 'public',
            'presta_sitemap.timetolive' => '3600',
            'presta_sitemap.sitemap_file_prefix' => 'sitemap',
            'presta_sitemap.items_by_set' => 50000,
            'presta_sitemap.defaults' => [
                'lastmod' => NULL,
                'priority' => NULL,
                'changefreq' => NULL,
            ],
            'presta_sitemap.default_section' => 'default',
            'presta_sitemap.eventlistener.route_annotation.class' => 'Presta\\SitemapBundle\\EventListener\\RouteAnnotationEventListener',
            'scheb_two_factor.model_manager_name' => NULL,
            'scheb_two_factor.email.sender_email' => 'no-reply@example.com',
            'scheb_two_factor.email.sender_name' => NULL,
            'scheb_two_factor.email.template' => '@SchebTwoFactor/Authentication/form.html.twig',
            'scheb_two_factor.email.digits' => 4,
            'scheb_two_factor.google.server_name' => 'Pimcore',
            'scheb_two_factor.google.issuer' => 'Pimcore 2 Factor Authentication',
            'scheb_two_factor.google.template' => '@SchebTwoFactor/Authentication/form.html.twig',
            'scheb_two_factor.google.digits' => 6,
            'scheb_two_factor.trusted_device.enabled' => false,
            'scheb_two_factor.trusted_device.cookie_name' => 'trusted_device',
            'scheb_two_factor.trusted_device.lifetime' => 5184000,
            'scheb_two_factor.trusted_device.extend_lifetime' => false,
            'scheb_two_factor.trusted_device.cookie_secure' => false,
            'scheb_two_factor.trusted_device.cookie_same_site' => 'lax',
            'scheb_two_factor.trusted_device.cookie_domain' => NULL,
            'scheb_two_factor.security_tokens' => [
                0 => 'Pimcore\\Bundle\\AdminBundle\\Security\\Authentication\\Token\\TwoFactorRequiredToken',
            ],
            'scheb_two_factor.ip_whitelist' => [

            ],
            'pimcore.extensions.bundles.search_paths' => [
                0 => 'src',
                1 => 'vendor/pimcore/pimcore/bundles',
            ],
            'pimcore.extensions.bundles.handle_composer' => true,
            'pimcore.admin.unauthenticated_routes' => [
                0 => [
                    'route' => 'pimcore_settings_display_custom_logo',
                    'path' => false,
                    'host' => false,
                    'methods' => [

                    ],
                ],
                1 => [
                    'route' => 'pimcore_admin_login',
                    'path' => false,
                    'host' => false,
                    'methods' => [

                    ],
                ],
                2 => [
                    'route' => 'pimcore_admin_webdav',
                    'path' => false,
                    'host' => false,
                    'methods' => [

                    ],
                ],
            ],
            'pimcore.encryption.secret' => NULL,
            'pimcore.admin.session.attribute_bags' => [
                'pimcore_admin' => [
                    'storage_key' => '_pimcore_admin',
                ],
                'pimcore_documents' => [
                    'storage_key' => '_pimcore_documents',
                ],
                'pimcore_objects' => [
                    'storage_key' => '_pimcore_objects',
                ],
                'pimcore_copy' => [
                    'storage_key' => '_pimcore_copy',
                ],
                'pimcore_gridconfig' => [
                    'storage_key' => '_pimcore_gridconfig',
                ],
                'pimcore_importconfig' => [
                    'storage_key' => '_pimcore_importconfig',
                ],
            ],
            'pimcore.admin.translations.path' => '@PimcoreCoreBundle/Resources/translations',
            'pimcore.web_profiler.toolbar.excluded_routes' => [
                0 => [
                    'path' => '^/admin/asset/image-editor',
                    'route' => false,
                    'host' => false,
                    'methods' => [

                    ],
                ],
            ],
            'pimcore.response_exception_listener.render_error_document' => true,
            'pimcore.mime.extensions' => [
                'ez' => 'application/andrew-inset',
                'atom' => 'application/atom+xml',
                'jar' => 'application/java-archive',
                'hqx' => 'application/mac-binhex40',
                'cpt' => 'application/mac-compactpro',
                'mathml' => 'application/mathml+xml',
                'doc' => 'application/msword',
                'dat' => 'application/octet-stream',
                'oda' => 'application/oda',
                'ogg' => 'application/ogg',
                'pdf' => 'application/pdf',
                'ai' => 'application/ai',
                'eps' => 'application/postscript',
                'ps' => 'application/postscript',
                'rdf' => 'application/rdf+xml',
                'rss' => 'application/rss+xml',
                'smi' => 'application/smil',
                'smil' => 'application/smil',
                'gram' => 'application/srgs',
                'grxml' => 'application/srgs+xml',
                'kml' => 'application/vnd.google-earth.kml+xml',
                'kmz' => 'application/vnd.google-earth.kmz',
                'mif' => 'application/vnd.mif',
                'xul' => 'application/vnd.mozilla.xul+xml',
                'xls' => 'application/vnd.ms-excel',
                'xlb' => 'application/vnd.ms-excel',
                'xlt' => 'application/vnd.ms-excel',
                'xlam' => 'application/vnd.ms-excel.addin.macroEnabled.12',
                'xlsb' => 'application/vnd.ms-excel.sheet.binary.macroEnabled.12',
                'xlsm' => 'application/vnd.ms-excel.sheet.macroEnabled.12',
                'xltm' => 'application/vnd.ms-excel.template.macroEnabled.12',
                'docm' => 'application/vnd.ms-word.document.macroEnabled.12',
                'dotm' => 'application/vnd.ms-word.template.macroEnabled.12',
                'ppam' => 'application/vnd.ms-powerpoint.addin.macroEnabled.12',
                'pptm' => 'application/vnd.ms-powerpoint.presentation.macroEnabled.12',
                'ppsm' => 'application/vnd.ms-powerpoint.slideshow.macroEnabled.12',
                'potm' => 'application/vnd.ms-powerpoint.template.macroEnabled.12',
                'ppt' => 'application/vnd.ms-powerpoint',
                'pps' => 'application/vnd.ms-powerpoint',
                'odc' => 'application/vnd.oasis.opendocument.chart',
                'odb' => 'application/vnd.oasis.opendocument.database',
                'odf' => 'application/vnd.oasis.opendocument.formula',
                'odg' => 'application/vnd.oasis.opendocument.graphics',
                'otg' => 'application/vnd.oasis.opendocument.graphics-template',
                'odi' => 'application/vnd.oasis.opendocument.image',
                'odp' => 'application/vnd.oasis.opendocument.presentation',
                'otp' => 'application/vnd.oasis.opendocument.presentation-template',
                'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
                'ots' => 'application/vnd.oasis.opendocument.spreadsheet-template',
                'odt' => 'application/vnd.oasis.opendocument.text',
                'odm' => 'application/vnd.oasis.opendocument.text-master',
                'ott' => 'application/vnd.oasis.opendocument.text-template',
                'oth' => 'application/vnd.oasis.opendocument.text-web',
                'potx' => 'application/vnd.openxmlformats-officedocument.presentationml.template',
                'ppsx' => 'application/vnd.openxmlformats-officedocument.presentationml.slideshow',
                'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'xltx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.template',
                'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'dotx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.template',
                'vsd' => 'application/vnd.visio',
                'wbxml' => 'application/vnd.wap.wbxml',
                'wmlc' => 'application/vnd.wap.wmlc',
                'wmlsc' => 'application/vnd.wap.wmlscriptc',
                'vxml' => 'application/voicexml+xml',
                'bcpio' => 'application/x-bcpio',
                'vcd' => 'application/x-cdlink',
                'pgn' => 'application/x-chess-pgn',
                'cpio' => 'application/x-cpio',
                'csh' => 'application/x-csh',
                'dcr' => 'application/x-director',
                'dir' => 'application/x-director',
                'dxr' => 'application/x-director',
                'dxf' => 'application/x-autocad',
                'dvi' => 'application/x-dvi',
                'spl' => 'application/x-futuresplash',
                'tgz' => 'application/x-gtar',
                'gtar' => 'application/x-gtar',
                'hdf' => 'application/x-hdf',
                'js' => 'application/x-javascript',
                'skp' => 'application/x-koan',
                'skd' => 'application/x-koan',
                'skt' => 'application/x-koan',
                'skm' => 'application/x-koan',
                'latex' => 'application/x-latex',
                'nc' => 'application/x-netcdf',
                'cdf' => 'application/x-netcdf',
                'sh' => 'application/x-sh',
                'shar' => 'application/x-shar',
                'swf' => 'application/x-shockwave-flash',
                'sit' => 'application/x-stuffit',
                'sv4cpio' => 'application/x-sv4cpio',
                'sv4crc' => 'application/x-sv4crc',
                'tar' => 'application/x-tar',
                'tcl' => 'application/x-tcl',
                'tex' => 'application/x-tex',
                'texinfo' => 'application/x-texinfo',
                'texi' => 'application/x-texinfo',
                't' => 'application/x-troff',
                'tr' => 'application/x-troff',
                'roff' => 'application/x-troff',
                'man' => 'application/x-troff-man',
                'me' => 'application/x-troff-me',
                'ms' => 'application/x-troff-ms',
                'ustar' => 'application/x-ustar',
                'src' => 'application/x-wais-source',
                'xhtml' => 'application/xhtml+xml',
                'xht' => 'application/xhtml+xml',
                'xslt' => 'application/xslt+xml',
                'xml' => 'application/xml',
                'xsl' => 'application/xml',
                'dtd' => 'application/xml-dtd',
                'zip' => 'application/zip',
                'au' => 'audio/basic',
                'snd' => 'audio/basic',
                'mid' => 'audio/midi',
                'midi' => 'audio/midi',
                'kar' => 'audio/midi',
                'mpga' => 'audio/mpeg',
                'mp2' => 'audio/mpeg',
                'mp3' => 'audio/mpeg',
                'aif' => 'audio/x-aiff',
                'aiff' => 'audio/x-aiff',
                'aifc' => 'audio/x-aiff',
                'm3u' => 'audio/x-mpegurl',
                'wma' => 'audio/x-ms-wma',
                'wax' => 'audio/x-ms-wax',
                'ram' => 'audio/x-pn-realaudio',
                'ra' => 'audio/x-pn-realaudio',
                'rm' => 'application/vnd.rn-realmedia',
                'wav' => 'audio/x-wav',
                'pdb' => 'chemical/x-pdb',
                'xyz' => 'chemical/x-xyz',
                'bmp' => 'image/bmp',
                'cgm' => 'image/cgm',
                'gif' => 'image/gif',
                'ief' => 'image/ief',
                'jpeg' => 'image/jpeg',
                'jpg' => 'image/jpeg',
                'jpe' => 'image/jpeg',
                'png' => 'image/png',
                'svg' => 'image/svg+xml',
                'tiff' => 'image/tiff',
                'tif' => 'image/tiff',
                'djvu' => 'image/vnd.djvu',
                'djv' => 'image/vnd.djvu',
                'wbmp' => 'image/vnd.wap.wbmp',
                'ras' => 'image/x-cmu-raster',
                'ico' => 'image/x-icon',
                'pnm' => 'image/x-portable-anymap',
                'pbm' => 'image/x-portable-bitmap',
                'pgm' => 'image/x-portable-graymap',
                'ppm' => 'image/x-portable-pixmap',
                'rgb' => 'image/x-rgb',
                'xbm' => 'image/x-xbitmap',
                'psd' => 'image/x-photoshop',
                'psb' => 'image/psb',
                'xpm' => 'image/x-xpixmap',
                'xwd' => 'image/x-xwindowdump',
                'eml' => 'message/rfc822',
                'igs' => 'model/iges',
                'iges' => 'model/iges',
                'msh' => 'model/mesh',
                'mesh' => 'model/mesh',
                'silo' => 'model/mesh',
                'wrl' => 'model/vrml',
                'vrml' => 'model/vrml',
                'ics' => 'text/calendar',
                'ifb' => 'text/calendar',
                'css' => 'text/css',
                'csv' => 'text/csv',
                'html' => 'text/html',
                'htm' => 'text/html',
                'txt' => 'text/plain',
                'asc' => 'text/plain',
                'rtx' => 'text/richtext',
                'rtf' => 'text/rtf',
                'sgml' => 'text/sgml',
                'sgm' => 'text/sgml',
                'tsv' => 'text/tab-separated-values',
                'wml' => 'text/vnd.wap.wml',
                'wmls' => 'text/vnd.wap.wmlscript',
                'etx' => 'text/x-setext',
                'mpeg' => 'video/mpeg',
                'mpg' => 'video/mpeg',
                'mpe' => 'video/mpeg',
                'qt' => 'video/quicktime',
                'mov' => 'video/quicktime',
                'mxu' => 'video/vnd.mpegurl',
                'm4u' => 'video/vnd.mpegurl',
                'flv' => 'video/x-flv',
                'f4v' => 'video/mp4',
                'mp4' => 'video/mp4',
                'asf' => 'video/x-ms-asf',
                'asx' => 'video/x-ms-asf',
                'wmv' => 'video/x-ms-wmv',
                'wm' => 'video/x-ms-wm',
                'wmx' => 'video/x-ms-wmx',
                'avi' => 'video/x-msvideo',
                'ogv' => 'video/ogg',
                'movie' => 'video/x-sgi-movie',
                'ice' => 'x-conference/x-cooltalk',
            ],
            'pimcore.routing.defaults' => [
                'bundle' => 'AppBundle',
                'controller' => 'Default',
                'action' => 'default',
            ],
            'pimcore.routing.static.locale_params' => [

            ],
            'pimcore.cache.core.default_lifetime' => 2419200,
            'pimcore.targeting.enabled' => true,
            'pimcore.targeting.conditions' => [
                'browser' => 'Pimcore\\Targeting\\Condition\\Browser',
                'country' => 'Pimcore\\Targeting\\Condition\\Country',
                'geopoint' => 'Pimcore\\Targeting\\Condition\\GeoPoint',
                'hardwareplatform' => 'Pimcore\\Targeting\\Condition\\HardwarePlatform',
                'language' => 'Pimcore\\Targeting\\Condition\\Language',
                'operatingsystem' => 'Pimcore\\Targeting\\Condition\\OperatingSystem',
                'referringsite' => 'Pimcore\\Targeting\\Condition\\ReferringSite',
                'searchengine' => 'Pimcore\\Targeting\\Condition\\SearchEngine',
                'target_group' => 'Pimcore\\Targeting\\Condition\\TargetGroup',
                'timeonsite' => 'Pimcore\\Targeting\\Condition\\TimeOnSite',
                'url' => 'Pimcore\\Targeting\\Condition\\Url',
                'visitedpagebefore' => 'Pimcore\\Targeting\\Condition\\Piwik\\VisitedPageBefore',
                'visitedpagesbefore' => 'Pimcore\\Targeting\\Condition\\VisitedPagesBefore',
            ],
            'pimcore.workflow' => [

            ],
            'pimcore.gdpr-data-extrator.dataobjects' => [
                'classes' => [

                ],
            ],
            'pimcore.gdpr-data-extrator.assets' => [
                'types' => [

                ],
            ],
            'pimcore_admin.dataObjects.notes_events.types' => [
                0 => '',
                1 => 'content',
                2 => 'seo',
                3 => 'warning',
                4 => 'notice',
            ],
            'pimcore_admin.assets.notes_events.types' => [
                0 => '',
                1 => 'content',
                2 => 'seo',
                3 => 'warning',
                4 => 'notice',
            ],
            'pimcore_admin.documents.notes_events.types' => [
                0 => '',
                1 => 'content',
                2 => 'seo',
                3 => 'warning',
                4 => 'notice',
            ],
            'pimcore_admin.csrf_protection.excluded_routes' => [

            ],
            'pimcore_admin.admin_languages' => [

            ],
            'pimcore_admin.custom_admin_path_identifier' => NULL,
            'pimcore_admin.config' => [
                'gdpr_data_extractor' => [
                    'dataObjects' => [
                        'classes' => [

                        ],
                    ],
                    'assets' => [
                        'types' => [

                        ],
                    ],
                ],
                'objects' => [
                    'notes_events' => [
                        'types' => [
                            0 => '',
                            1 => 'content',
                            2 => 'seo',
                            3 => 'warning',
                            4 => 'notice',
                        ],
                    ],
                ],
                'assets' => [
                    'notes_events' => [
                        'types' => [
                            0 => '',
                            1 => 'content',
                            2 => 'seo',
                            3 => 'warning',
                            4 => 'notice',
                        ],
                    ],
                ],
                'documents' => [
                    'notes_events' => [
                        'types' => [
                            0 => '',
                            1 => 'content',
                            2 => 'seo',
                            3 => 'warning',
                            4 => 'notice',
                        ],
                    ],
                ],
                'admin_languages' => [

                ],
                'csrf_protection' => [
                    'excluded_routes' => [

                    ],
                ],
                'custom_admin_path_identifier' => NULL,
                'branding' => [
                    'login_screen_invert_colors' => false,
                    'color_login_screen' => NULL,
                    'color_admin_interface' => NULL,
                    'login_screen_custom_image' => NULL,
                ],
            ],
            'pimcore.service_controllers' => [
                'AppBundle\\Controller\\Api\\GarageController' => 'AppBundle\\Controller\\Api\\GarageController',
                'AppBundle\\Controller\\DefaultController' => 'AppBundle\\Controller\\DefaultController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\AssetController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\AssetController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\ClassController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\ClassController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\ClassificationstoreController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\ClassificationstoreController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectHelperController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\DataObjectHelperController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\QuantityValueController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\QuantityValueController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\VariantsController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\DataObject\\VariantsController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\DocumentController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\DocumentController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\EmailController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\EmailController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\FolderController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\FolderController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\HardlinkController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\HardlinkController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\LinkController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\LinkController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\NewsletterController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\NewsletterController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PageController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PageController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintcontainerController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintcontainerController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintpageController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintpageController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintpageControllerBase' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\PrintpageControllerBase',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\RenderletController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\RenderletController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\SnippetController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\Document\\SnippetController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\ElementController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\ElementController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\ElementControllerBase' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\ElementControllerBase',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\EmailController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\EmailController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\AdminerController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\AdminerController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\LinfoController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\LinfoController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\OpcacheController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\External\\OpcacheController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\IndexController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\IndexController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\InstallController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\InstallController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\LogController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\LogController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\LoginController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\LoginController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\MiscController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\MiscController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\NotificationController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\NotificationController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\PortalController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\PortalController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\RecyclebinController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\RecyclebinController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\RedirectsController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\RedirectsController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\SettingsController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\SettingsController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TagsController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TagsController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TargetingController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TargetingController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TranslationController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\TranslationController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\UserController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\UserController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\WorkflowController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Admin\\WorkflowController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\ExtensionManager\\ExtensionManagerController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\ExtensionManager\\ExtensionManagerController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\AdminController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\AdminController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\AssetController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\AssetController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\DataObjectController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\DataObjectController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\PimcoreUsersController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\PimcoreUsersController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\SentMailController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\GDPR\\SentMailController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\AnalyticsController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\AnalyticsController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\CustomReportController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\CustomReportController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\PiwikController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\PiwikController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\QrcodeController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\QrcodeController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\ReportsControllerBase' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\ReportsControllerBase',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\SettingsController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Reports\\SettingsController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\ClassController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\ClassController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\AssetController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\AssetController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\DataObjectController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\DataObjectController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\DocumentController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\DocumentController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\TagController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Element\\TagController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Helper' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\Helper',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\ImageController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\ImageController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\InfoController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Rest\\InfoController',
                'Pimcore\\Bundle\\AdminBundle\\Controller\\Searchadmin\\SearchController' => 'Pimcore\\Bundle\\AdminBundle\\Controller\\Searchadmin\\SearchController',
                'Pimcore\\Bundle\\CoreBundle\\Controller\\PublicServicesController' => 'Pimcore\\Bundle\\CoreBundle\\Controller\\PublicServicesController',
            ],
            'doctrine_migrations.namespace' => 'Application\\Migrations',
            'doctrine_migrations.table_name' => 'migration_versions',
            'doctrine_migrations.name' => 'Application Migrations',
            'doctrine_migrations.custom_template' => NULL,
            'doctrine_migrations.organize_migrations' => false,
            'console.command.ids' => [
                0 => 'console.command.public_alias.doctrine_cache.contains_command',
                1 => 'console.command.public_alias.doctrine_cache.delete_command',
                2 => 'console.command.public_alias.doctrine_cache.flush_command',
                3 => 'console.command.public_alias.doctrine_cache.stats_command',
                4 => 'presta_sitemap.dump_command',
                5 => 'console.command.public_alias.Pimcore\\Migrations\\Command\\ExecuteCommand',
                6 => 'console.command.public_alias.Pimcore\\Migrations\\Command\\GenerateCommand',
                7 => 'console.command.public_alias.Pimcore\\Migrations\\Command\\LatestCommand',
                8 => 'console.command.public_alias.Pimcore\\Migrations\\Command\\MarkAllDoneCommand',
                9 => 'console.command.public_alias.Pimcore\\Migrations\\Command\\MigrateCommand',
                10 => 'console.command.public_alias.Pimcore\\Migrations\\Command\\StatusCommand',
                11 => 'console.command.public_alias.Pimcore\\Migrations\\Command\\VersionCommand',
                12 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Bundle\\ListCommand',
                13 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\CacheClearCommand',
                14 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\CacheWarmingCommand',
                15 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\ClassCommand',
                16 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\CustomLayoutCommand',
                17 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\FieldCollectionCommand',
                18 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Definition\\Import\\ObjectBrickCommand',
                19 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\DeleteClassificationStoreCommand',
                20 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\DeleteUnusedLocaleDataCommand',
                21 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Document\\GeneratePagePreviews',
                22 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Document\\MigrateTagNamingStrategyCommand',
                23 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\EmailLogsCleanupCommand',
                24 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\InternalModelDaoMappingGeneratorCommand',
                25 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\InternalUnicodeCldrLanguageTerritoryGeneratorCommand',
                26 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\InternalVideoConverterCommand',
                27 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\LowQualityImagePreviewCommand',
                28 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\MysqlToolsCommand',
                29 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ResetPasswordCommand',
                30 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\RunScriptCommand',
                31 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\SearchBackendReindexCommand',
                32 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ThumbnailsClearCommand',
                33 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ThumbnailsImageCommand',
                34 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\ThumbnailsVideoCommand',
                35 => 'console.command.public_alias.Pimcore\\Bundle\\CoreBundle\\Command\\Web2PrintPdfCreationCommand',
            ],
        ];
    }
}
