<?php

class AuthenticatedTokenHandler_e3677d3 extends \Scheb\TwoFactorBundle\Security\TwoFactor\Handler\AuthenticatedTokenHandler implements \ProxyManager\Proxy\VirtualProxyInterface
{
    private $valueHolder2b092 = null;
    private $initializerc1fb4 = null;
    private static $publicPropertiesc44a5 = [
        
    ];
    public function beginTwoFactorAuthentication(\Scheb\TwoFactorBundle\Security\TwoFactor\AuthenticationContextInterface $context) : \Symfony\Component\Security\Core\Authentication\Token\TokenInterface
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'beginTwoFactorAuthentication', array('context' => $context), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return $this->valueHolder2b092->beginTwoFactorAuthentication($context);
    }
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;
        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Scheb\TwoFactorBundle\Security\TwoFactor\Handler\AuthenticatedTokenHandler $instance) {
            unset($instance->authenticationHandler, $instance->supportedTokens);
        }, $instance, 'Scheb\\TwoFactorBundle\\Security\\TwoFactor\\Handler\\AuthenticatedTokenHandler')->__invoke($instance);
        $instance->initializerc1fb4 = $initializer;
        return $instance;
    }
    public function __construct(\Scheb\TwoFactorBundle\Security\TwoFactor\Handler\AuthenticationHandlerInterface $authenticationHandler, array $supportedTokens)
    {
        static $reflection;
        if (! $this->valueHolder2b092) {
            $reflection = $reflection ?? new \ReflectionClass('Scheb\\TwoFactorBundle\\Security\\TwoFactor\\Handler\\AuthenticatedTokenHandler');
            $this->valueHolder2b092 = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Scheb\TwoFactorBundle\Security\TwoFactor\Handler\AuthenticatedTokenHandler $instance) {
            unset($instance->authenticationHandler, $instance->supportedTokens);
        }, $this, 'Scheb\\TwoFactorBundle\\Security\\TwoFactor\\Handler\\AuthenticatedTokenHandler')->__invoke($this);
        }
        $this->valueHolder2b092->__construct($authenticationHandler, $supportedTokens);
    }
    public function & __get($name)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__get', ['name' => $name], $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        if (isset(self::$publicPropertiesc44a5[$name])) {
            return $this->valueHolder2b092->$name;
        }
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            $backtrace = debug_backtrace(false);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    get_parent_class($this),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __set($name, $value)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            return $targetObject->$name = $value;
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function & () use ($targetObject, $name, $value) {
            return $targetObject->$name = $value;
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __isset($name)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__isset', array('name' => $name), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            return isset($targetObject->$name);
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();
        return $returnValue;
    }
    public function __unset($name)
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__unset', array('name' => $name), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $realInstanceReflection = new \ReflectionClass(get_parent_class($this));
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder2b092;
            unset($targetObject->$name);
            return;
        }
        $targetObject = $this->valueHolder2b092;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();
        return $returnValue;
    }
    public function __clone()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__clone', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        $this->valueHolder2b092 = clone $this->valueHolder2b092;
    }
    public function __sleep()
    {
        $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, '__sleep', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
        return array('valueHolder2b092');
    }
    public function __wakeup()
    {
        \Closure::bind(function (\Scheb\TwoFactorBundle\Security\TwoFactor\Handler\AuthenticatedTokenHandler $instance) {
            unset($instance->authenticationHandler, $instance->supportedTokens);
        }, $this, 'Scheb\\TwoFactorBundle\\Security\\TwoFactor\\Handler\\AuthenticatedTokenHandler')->__invoke($this);
    }
    public function setProxyInitializer(\Closure $initializer = null)
    {
        $this->initializerc1fb4 = $initializer;
    }
    public function getProxyInitializer()
    {
        return $this->initializerc1fb4;
    }
    public function initializeProxy() : bool
    {
        return $this->initializerc1fb4 && ($this->initializerc1fb4->__invoke($valueHolder2b092, $this, 'initializeProxy', array(), $this->initializerc1fb4) || 1) && $this->valueHolder2b092 = $valueHolder2b092;
    }
    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder2b092;
    }
    public function getWrappedValueHolderValue() : ?object
    {
        return $this->valueHolder2b092;
    }
}
